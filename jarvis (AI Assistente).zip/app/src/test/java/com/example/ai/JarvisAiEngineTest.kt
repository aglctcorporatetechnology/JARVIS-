package com.example.ai

import com.example.data.local.ChatMessageEntity
import com.google.firebase.FirebaseApp
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.net.SocketTimeoutException
import java.net.UnknownHostException

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class JarvisAiEngineTest {

    @Test
    fun `model normalization falls back to default when blank or deprecated`() {
        assertEquals("gemini-3.8-flash", JarvisGeminiModels.normalize(""))
        assertEquals("gemini-3.8-flash", JarvisGeminiModels.normalize("gemini-1.5-flash"))
        assertEquals("gemini-3.8-flash", JarvisGeminiModels.normalize("gemini-2.0-flash"))
        assertEquals("gemini-3.5-flash-lite", JarvisGeminiModels.normalize("gemini-3.5-flash-lite"))
        assertEquals("gemini-4-argon", JarvisGeminiModels.normalize("gemini-4-argon"))
        assertTrue(JarvisGeminiModels.isAvailable("gemini-3.8-flash"))
        assertFalse(JarvisGeminiModels.isAvailable("gemini-1.5-pro"))
    }

    @Test
    fun `sanitizeChatHistory enforces strict user-model alternation and strips legacy errors`() {
        val raw = listOf(
            ChatMessageEntity(role = "model", content = "Saudação órfã"),
            ChatMessageEntity(role = "user", content = "Olá"),
            ChatMessageEntity(role = "model", content = "Senhor, ocorreu um erro técnico: timeout"),
            ChatMessageEntity(role = "user", content = "Qual a capital da França?"),
            ChatMessageEntity(role = "model", content = "Paris, senhor."),
            ChatMessageEntity(role = "user", content = "Tentativa falha sem resposta")
        )

        val sanitized = sanitizeChatHistory(raw)
        assertEquals(2, sanitized.size)
        assertEquals("user", sanitized[0].role)
        assertEquals("model", sanitized[1].role)
    }

    @Test
    fun `local intent detector handles device commands and leaves general Q&A as NONE`() {
        val alarmIntent = detectLocalCommandIntent("JARVIS, criar alarme para 06:30")
        assertEquals(JarvisCommandAction.CREATE_ALARM, alarmIntent.action)
        assertEquals(6, alarmIntent.alarmHour)
        assertEquals(30, alarmIntent.alarmMinute)

        val weatherIntent = detectLocalCommandIntent("Vai chover hoje em Curitiba?")
        assertEquals(JarvisCommandAction.OPEN_WEATHER, weatherIntent.action)
        assertEquals("Curitiba", weatherIntent.queryParameter)

        val trafficIntent = detectLocalCommandIntent("Mostre o trânsito na Marginal Tietê")
        assertEquals(JarvisCommandAction.OPEN_TRAFFIC, trafficIntent.action)

        val qaIntent = detectLocalCommandIntent("Explique a teoria da relatividade geral de forma resumida")
        assertEquals(JarvisCommandAction.NONE, qaIntent.action)
    }

    @Test
    fun `mapGeminiException classifies timeout, quota, offline, billing, auth, and server errors`() = runTest {
        val timeoutEx = runCatching {
            withTimeout(1L) { delay(50L) }
        }.exceptionOrNull() as TimeoutCancellationException
        val mappedTimeout = mapGeminiException(timeoutEx, "gemini-3.8-flash")
        assertEquals(JarvisAiErrorKind.TIMEOUT, mappedTimeout.kind)
        assertTrue(mappedTimeout.retryable)

        val mappedSocketTimeout = mapGeminiException(
            SocketTimeoutException("Read timed out"),
            "gemini-3.8-flash"
        )
        assertEquals(JarvisAiErrorKind.TIMEOUT, mappedSocketTimeout.kind)

        val mappedQuota = mapGeminiException(
            IllegalStateException("429 RESOURCE_EXHAUSTED quota exceeded"),
            "gemini-3.8-flash"
        )
        assertEquals(JarvisAiErrorKind.RATE_LIMIT, mappedQuota.kind)
        assertTrue(mappedQuota.retryable)

        val mappedOffline = mapGeminiException(
            UnknownHostException("firebasevertexai.googleapis.com"),
            "gemini-3.8-flash"
        )
        assertEquals(JarvisAiErrorKind.OFFLINE, mappedOffline.kind)
        assertTrue(mappedOffline.retryable)

        val mappedBilling = mapGeminiException(
            IllegalStateException("403 Billing required for gemini-4-argon"),
            "gemini-4-argon"
        )
        assertEquals(JarvisAiErrorKind.MODEL_OR_BILLING, mappedBilling.kind)
        assertTrue(mappedBilling.message.orEmpty().contains("Blaze"))

        val mappedAppCheck = mapGeminiException(
            IllegalStateException("401 Firebase App Check token is invalid"),
            "gemini-3.8-flash"
        )
        assertEquals(JarvisAiErrorKind.AUTH_OR_CONFIG, mappedAppCheck.kind)

        val mappedServer = mapGeminiException(
            IllegalStateException("503 Service Unavailable"),
            "gemini-3.8-flash"
        )
        assertEquals(JarvisAiErrorKind.SERVER, mappedServer.kind)

        val appContext = RuntimeEnvironment.getApplication()
        val firebaseApps = FirebaseApp.getApps(appContext)
        val apiKeyResId = appContext.resources.getIdentifier("google_api_key", "string", appContext.packageName)
        val projectIdResId = appContext.resources.getIdentifier("project_id", "string", appContext.packageName)
        assertTrue("google_api_key resource missing", apiKeyResId != 0)
        assertTrue("project_id resource missing", projectIdResId != 0)
        assertEquals("gen-lang-client-0290889448", appContext.getString(projectIdResId))
        assertTrue(appContext.getString(apiKeyResId).startsWith("AIza"))
        assertTrue(firebaseApps.isEmpty() || firebaseApps.first().options.projectId == "gen-lang-client-0290889448")
    }
}
