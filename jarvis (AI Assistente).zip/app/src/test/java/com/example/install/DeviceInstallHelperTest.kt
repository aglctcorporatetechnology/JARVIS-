package com.example.install

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import androidx.test.core.app.ApplicationProvider
import com.example.ai.JarvisCommandAction
import com.example.ai.detectLocalCommandIntent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class DeviceInstallHelperTest {

    @Test
    fun `normalizeInstallDownloadUrl accepts valid urls and prefixes missing scheme`() {
        assertEquals(
            "https://example.com/jarvis.apk",
            normalizeInstallDownloadUrl("  https://example.com/jarvis.apk  ")
        )
        assertEquals(
            "https://drive.google.com/file/d/abc/view",
            normalizeInstallDownloadUrl("drive.google.com/file/d/abc/view")
        )
        assertEquals(
            "http://192.168.0.10/jarvis.apk",
            normalizeInstallDownloadUrl("http://192.168.0.10/jarvis.apk")
        )
        assertNull(normalizeInstallDownloadUrl(""))
        assertNull(normalizeInstallDownloadUrl("   "))
        assertNull(normalizeInstallDownloadUrl("texto invalido sem ponto"))
        assertNull(normalizeInstallDownloadUrl("ftp://example.com/jarvis.apk"))
    }

    @Test
    fun `generateQrMatrix encodes valid url into square bit matrix`() {
        val qr = generateQrMatrix("https://example.com/jarvis.apk", sizePx = 64)
        assertNotNull(qr)
        qr!!
        assertTrue(qr.width >= 64)
        assertEquals(qr.width, qr.height)
        assertEquals(qr.width * qr.height, qr.darkModules.size)
        assertTrue(qr.darkModules.any { it })
        assertTrue(qr.darkModules.any { !it })

        assertNull(generateQrMatrix("   ", sizePx = 64))
    }

    @Test
    fun `inspectDeviceInstallInfo reports tablet and phone form factors correctly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()

        val tabletInfo = inspectDeviceInstallInfo(context, isTabletScreen = true)
        assertEquals("Tablet Android", tabletInfo.deviceFormFactor)
        assertEquals(context.packageName, tabletInfo.packageName)
        assertTrue(tabletInfo.versionName.isNotBlank())
        assertTrue(tabletInfo.suggestedApkFileName.startsWith("JARVIS-v"))
        assertTrue(tabletInfo.suggestedApkFileName.endsWith(".apk"))

        val phoneInfo = inspectDeviceInstallInfo(context, isTabletScreen = false)
        assertEquals("Smartphone Android", phoneInfo.deviceFormFactor)
    }

    @Test
    fun `voice intent detects zero-pc install commands in Portuguese`() {
        val intent1 = detectLocalCommandIntent("JARVIS, quero instalar no tablet sem computador")
        assertEquals(JarvisCommandAction.OPEN_INSTALL, intent1.action)

        val intent2 = detectLocalCommandIntent("Como baixar no celular sem pc?")
        assertEquals(JarvisCommandAction.OPEN_INSTALL, intent2.action)

        val intent3 = detectLocalCommandIntent("Compartilhar aplicativo com meu tablet")
        assertEquals(JarvisCommandAction.OPEN_INSTALL, intent3.action)
    }

    @Test
    fun `exportInstalledApkToCache and buildShareApkIntent create FileProvider chooser`() = runTest {
        val baseContext = ApplicationProvider.getApplicationContext<Context>()
        val dummyApk = File(baseContext.cacheDir, "dummy_base.apk").apply {
            writeBytes("PK\u0003\u0004JARVIS_TEST_ARCHIVE".toByteArray())
        }
        val appInfo = ApplicationInfo(baseContext.applicationInfo).apply {
            sourceDir = dummyApk.absolutePath
            splitSourceDirs = null
        }
        val wrappedContext = object : android.content.ContextWrapper(baseContext) {
            override fun getApplicationInfo(): ApplicationInfo = appInfo
        }

        val info = inspectDeviceInstallInfo(wrappedContext, isTabletScreen = true)
        assertFalse(info.isSplitApkInstall)
        assertTrue(info.canExportUniversalApk)

        val exported = exportInstalledApkToCache(wrappedContext)
        assertTrue(exported.isSuccess)
        val exportedFile = exported.getOrThrow()
        assertTrue(exportedFile.exists())
        assertEquals(dummyApk.length(), exportedFile.length())

        val chooserIntent = buildShareApkIntent(wrappedContext, exportedFile)
        assertEquals(Intent.ACTION_CHOOSER, chooserIntent.action)
        @Suppress("DEPRECATION")
        val targetIntent = chooserIntent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
        assertNotNull(targetIntent)
        assertEquals(Intent.ACTION_SEND, targetIntent?.action)
        assertEquals("application/vnd.android.package-archive", targetIntent?.type)
        assertTrue((targetIntent?.flags ?: 0) and Intent.FLAG_GRANT_READ_URI_PERMISSION != 0)
    }
}
