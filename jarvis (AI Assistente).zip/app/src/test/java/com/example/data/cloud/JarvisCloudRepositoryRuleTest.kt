package com.example.data.cloud

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.preferences.JarvisSettings
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class JarvisCloudRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun ensureAndSyncProfile_authenticatedOwner_succeedsAndEmitsUpdates() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = JarvisCloudRepository(firestore, auth)

        val ensureResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.ensureUserProfile(
                displayName = "Tony Stark",
                email = ALICE_EMAIL,
                initialSettings = JarvisSettings()
            )
        }
        assertTrue(ensureResult.isSuccess)

        val syncResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.syncSettings(JarvisSettings(wakeWord = "SEXTA-FEIRA", languageTag = "pt-BR"))
        }
        assertTrue(syncResult.isSuccess)

        val profile = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeProfile(uid).first { it?.wakeWord == "SEXTA-FEIRA" }
        }
        assertNotNull(profile)
        assertEquals(uid, profile?.userId)
        assertEquals("SEXTA-FEIRA", profile?.wakeWord)
    }

    @Test
    fun addAndObserveMessages_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = JarvisCloudRepository(firestore, auth)
        val messageId = "msg_${UUID.randomUUID().toString().replace("-", "")}"

        val addResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.addMessage(
                role = "user",
                content = "JARVIS, como está o tempo hoje?",
                messageId = messageId
            )
        }
        assertTrue(addResult.isSuccess)

        val messages = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeMessages(uid).first { list -> list.any { it.id == messageId } }
        }
        assertTrue(messages.any { it.id == messageId && it.content.contains("tempo hoje") })
    }

    @Test
    fun upsertAndObserveAlarm_andPlaylist_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = JarvisCloudRepository(firestore, auth)
        val alarmId = "alarm_${UUID.randomUUID().toString().replace("-", "")}"
        val playlistId = "pl_${UUID.randomUUID().toString().replace("-", "")}"

        val alarmRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.upsertAlarm(
                alarmId = alarmId,
                hour = 7,
                minute = 30,
                label = "Treino Stark",
                enabled = true,
                daysOfWeekCsv = "1,2,3,4,5",
                repeatWeekly = true,
                speakJarvisGreeting = true,
                soundTitle = "Voz JARVIS",
                volume = 0.9f
            )
        }
        assertTrue(alarmRes.isSuccess)

        val alarms = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeAlarms(uid).first { list -> list.any { it.id == alarmId } }
        }
        assertTrue(alarms.any { it.id == alarmId && it.hour == 7 && it.minute == 30 })

        val plRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createPlaylist(name = "Oficina", playlistId = playlistId)
        }
        assertTrue(plRes.isSuccess)

        val playlists = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observePlaylists(uid).first { list -> list.any { it.id == playlistId } }
        }
        assertTrue(playlists.any { it.id == playlistId && it.name == "Oficina" })
    }

    @Test
    fun crossUserRead_onAlarmsAndProfile_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = JarvisCloudRepository(firestore, auth)
        val alarmId = "alarm_${UUID.randomUUID().toString().replace("-", "")}"

        val createRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.upsertAlarm(
                alarmId = alarmId,
                hour = 8,
                minute = 0,
                label = "Privado",
                enabled = true,
                daysOfWeekCsv = "",
                repeatWeekly = false,
                speakJarvisGreeting = true,
                soundTitle = "Voz JARVIS",
                volume = 0.8f
            )
        }
        assertTrue(createRes.isSuccess)

        signInTestUser(BOB_EMAIL)
        var capturedError: FirebaseFirestoreException? = null
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("users").document(aliceUid)
                    .collection("alarms").document(alarmId).get().await()
            }
        } catch (e: Exception) {
            capturedError = e.unwrapFirestoreException()
        }
        assertNotNull(capturedError)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, capturedError?.code)
    }

    @Test
    fun observeMessages_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = JarvisCloudRepository(firestore, auth)

        var caught: Exception? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeMessages("alice_unauth_test").first()
            }
        } catch (e: Exception) {
            caught = e
        }
        assertNotNull(caught)
        val firestoreException = checkNotNull(caught?.unwrapFirestoreException()) {
            "Expected nested FirebaseFirestoreException, got $caught"
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException.code)
    }

    private companion object {
        const val ALICE_EMAIL = "alice.jarvis@test.com"
        const val BOB_EMAIL = "bob.jarvis@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
