package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.alarm.AlarmScheduler
import com.example.data.local.AlarmEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class ExampleRobolectricTest {

  @Test
  fun `app name matches JARVIS`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("JARVIS", appName)
  }

  @Test
  fun `alarm scheduler computes future trigger timestamp`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val scheduler = AlarmScheduler(context)
    val alarm = AlarmEntity(
      id = 1L,
      hour = 7,
      minute = 30,
      label = "Despertar",
      enabled = true,
      daysOfWeekCsv = "1,2,3,4,5"
    )
    val nextMillis = scheduler.computeNextTriggerMillis(alarm)
    assertTrue(nextMillis > System.currentTimeMillis())
  }
}
