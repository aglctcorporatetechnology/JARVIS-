package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.example.ai.AiProviderRegistry
import com.example.ai.FirebaseGeminiProvider
import com.example.alarm.AlarmScheduler
import com.example.data.cloud.JarvisCloudRepository
import com.example.data.local.JarvisDatabase
import com.example.data.preferences.JarvisPreferencesRepository
import com.example.maps.MapsRepository
import com.example.music.MusicPlayerController
import com.example.voice.JarvisVoiceManager
import com.example.weather.WeatherRepository
import com.google.firebase.firestore.FirebaseFirestore

class AppContainer(application: Application) {
    val databaseId: String = application.getString(R.string.firestore_database_id)
    val database: JarvisDatabase = JarvisDatabase.getInstance(application)
    val preferences: JarvisPreferencesRepository = JarvisPreferencesRepository(application)
    val aiRegistry: AiProviderRegistry = AiProviderRegistry(
        defaultProvider = FirebaseGeminiProvider(application)
    )
    val weatherRepository: WeatherRepository = WeatherRepository(application)
    val mapsRepository: MapsRepository = MapsRepository()
    val alarmScheduler: AlarmScheduler = AlarmScheduler(application)
    val voiceManager: JarvisVoiceManager = JarvisVoiceManager(application)
    val musicController: MusicPlayerController = MusicPlayerController(application)

    fun createCloudRepository(): JarvisCloudRepository {
        val db = FirebaseFirestore.getInstance(databaseId)
        return JarvisCloudRepository(db)
    }
}

class JarvisApplication : Application() {

    companion object {
        const val CHANNEL_VOICE = "jarvis_voice_channel"
        const val CHANNEL_MUSIC = "jarvis_music_channel"
        const val CHANNEL_ALARM = "jarvis_alarm_channel"
    }

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        // Note: Firebase App Check is intentionally NOT initialized here;
        // it is configured with the launch Intent in MainActivity.onCreate().
        createNotificationChannels()
        container = AppContainer(this)
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_VOICE,
                    getString(R.string.voice_service_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                )
            )
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_MUSIC,
                    getString(R.string.music_service_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                )
            )
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ALARM,
                    getString(R.string.alarm_channel_name),
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    enableVibration(true)
                    setBypassDnd(true)
                }
            )
        }
    }
}
