package com.example.weather

import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import android.os.Build
import android.util.Log
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.math.roundToInt

data class HourlyForecastItem(
    val timeLabel: String,
    val temperatureC: Int,
    val rainProbability: Int,
    val conditionLabel: String
)

data class DailyForecastItem(
    val dateLabel: String,
    val minTempC: Int,
    val maxTempC: Int,
    val rainProbability: Int,
    val conditionLabel: String
)

data class WeatherReport(
    val locationName: String,
    val latitude: Double,
    val longitude: Double,
    val temperatureC: Double,
    val feelsLikeC: Double,
    val humidityPercent: Int,
    val windKmh: Double,
    val rainProbabilityPercent: Int,
    val conditionDescription: String,
    val providerUsed: String,
    val todayHourly: List<HourlyForecastItem>,
    val weeklyForecast: List<DailyForecastItem>,
    val updatedAtMs: Long = System.currentTimeMillis()
)

class WeatherRepository(private val context: Context) {

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val httpClient = OkHttpClient.Builder().build()

    private val forecastApi: OpenMeteoForecastApi = Retrofit.Builder()
        .baseUrl("https://api.open-meteo.com/")
        .client(httpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(OpenMeteoForecastApi::class.java)

    private val geocodingApi: OpenMeteoGeocodingApi = Retrofit.Builder()
        .baseUrl("https://geocoding-api.open-meteo.com/")
        .client(httpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(OpenMeteoGeocodingApi::class.java)

    private val openWeatherApi: OpenWeatherMapApi = Retrofit.Builder()
        .baseUrl("https://api.openweathermap.org/")
        .client(httpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(OpenWeatherMapApi::class.java)

    @SuppressLint("MissingPermission")
    suspend fun getCurrentDeviceCoordinates(): Pair<Double, Double>? {
        return try {
            val client = LocationServices.getFusedLocationProviderClient(context)
            val cts = CancellationTokenSource()
            suspendCancellableCoroutine { cont ->
                client.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, cts.token)
                    .addOnSuccessListener { loc ->
                        if (loc != null) {
                            cont.resume(loc.latitude to loc.longitude)
                        } else {
                            cont.resume(null)
                        }
                    }
                    .addOnFailureListener {
                        cont.resume(null)
                    }
                cont.invokeOnCancellation { cts.cancel() }
            }
        } catch (e: Exception) {
            Log.w("WeatherRepo", "Failed to read device location: ${e.message}")
            null
        }
    }

    suspend fun searchCities(query: String): List<GeocodingResultDto> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        geocodingApi.searchCity(query.trim()).results.orEmpty()
    }

    suspend fun fetchWeatherByCity(cityQuery: String, optionalOpenWeatherKey: String): WeatherReport {
        val results = searchCities(cityQuery)
        val first = results.firstOrNull()
            ?: throw IllegalArgumentException("Localidade '$cityQuery' não encontrada, senhor.")
        val label = listOfNotNull(first.name, first.admin1, first.country).joinToString(", ")
        return fetchWeather(first.latitude, first.longitude, label, optionalOpenWeatherKey)
    }

    suspend fun fetchWeather(
        latitude: Double,
        longitude: Double,
        explicitLocationName: String? = null,
        optionalOpenWeatherKey: String = ""
    ): WeatherReport = withContext(Dispatchers.IO) {
        val response = forecastApi.getForecast(latitude = latitude, longitude = longitude)
        val current = response.current
            ?: throw IllegalStateException("Dados meteorológicos indisponíveis no momento.")

        var locationLabel = explicitLocationName ?: resolveCityName(latitude, longitude)
        var temp = current.temperature2m
        var feels = current.apparentTemperature
        var humidity = current.relativeHumidity2m
        var windKmh = current.windSpeed10m
        var condition = wmoToPortuguese(current.weatherCode)
        var provider = "Open-Meteo (Tempo Real)"

        if (optionalOpenWeatherKey.isNotBlank()) {
            runCatching {
                val owm = openWeatherApi.getCurrentWeather(
                    lat = latitude,
                    lon = longitude,
                    apiKey = optionalOpenWeatherKey
                )
                owm.main?.let {
                    temp = it.temp
                    feels = it.feelsLike
                    humidity = it.humidity
                }
                owm.wind?.let { windKmh = it.speed * 3.6 }
                owm.weather?.firstOrNull()?.description?.let { desc ->
                    condition = desc.replaceFirstChar { c -> c.uppercase() }
                }
                if (!owm.name.isNullOrBlank()) {
                    locationLabel = owm.name
                }
                provider = "OpenWeatherMap + Open-Meteo"
            }.onFailure {
                Log.w("WeatherRepo", "OpenWeatherMap optional key failed, using Open-Meteo: ${it.message}")
            }
        }

        val hourlyTimes = response.hourly?.time.orEmpty()
        val hourlyTemps = response.hourly?.temperature2m.orEmpty()
        val hourlyRain = response.hourly?.precipitationProbability.orEmpty()
        val hourlyCodes = response.hourly?.weatherCode.orEmpty()

        val hourlyList = hourlyTimes.take(12).mapIndexed { idx, timeStr ->
            val hhmm = timeStr.substringAfter("T", timeStr).take(5)
            HourlyForecastItem(
                timeLabel = hhmm,
                temperatureC = hourlyTemps.getOrNull(idx)?.roundToInt() ?: temp.roundToInt(),
                rainProbability = hourlyRain.getOrNull(idx) ?: 0,
                conditionLabel = wmoToPortuguese(hourlyCodes.getOrNull(idx) ?: current.weatherCode)
            )
        }

        val dailyTimes = response.daily?.time.orEmpty()
        val dailyMax = response.daily?.temperature2mMax.orEmpty()
        val dailyMin = response.daily?.temperature2mMin.orEmpty()
        val dailyRain = response.daily?.precipitationProbabilityMax.orEmpty()
        val dailyCodes = response.daily?.weatherCode.orEmpty()

        val dailyList = dailyTimes.mapIndexed { idx, dateStr ->
            DailyForecastItem(
                dateLabel = formatDateBr(dateStr, idx),
                minTempC = dailyMin.getOrNull(idx)?.roundToInt() ?: temp.roundToInt(),
                maxTempC = dailyMax.getOrNull(idx)?.roundToInt() ?: temp.roundToInt(),
                rainProbability = dailyRain.getOrNull(idx) ?: 0,
                conditionLabel = wmoToPortuguese(dailyCodes.getOrNull(idx) ?: current.weatherCode)
            )
        }

        val rainNow = current.precipitationProbability
            ?: hourlyRain.firstOrNull()
            ?: dailyRain.firstOrNull()
            ?: 0

        WeatherReport(
            locationName = locationLabel,
            latitude = latitude,
            longitude = longitude,
            temperatureC = temp,
            feelsLikeC = feels,
            humidityPercent = humidity,
            windKmh = windKmh,
            rainProbabilityPercent = rainNow,
            conditionDescription = condition,
            providerUsed = provider,
            todayHourly = hourlyList,
            weeklyForecast = dailyList
        )
    }

    private fun resolveCityName(lat: Double, lon: Double): String {
        return try {
            @Suppress("DEPRECATION")
            val geocoder = Geocoder(context, Locale("pt", "BR"))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                String.format(Locale.US, "%.2f, %.2f", lat, lon)
            } else {
                @Suppress("DEPRECATION")
                val list = geocoder.getFromLocation(lat, lon, 1)
                val addr = list?.firstOrNull()
                listOfNotNull(addr?.subAdminArea ?: addr?.locality, addr?.adminArea)
                    .joinToString(", ")
                    .ifBlank { String.format(Locale.US, "%.2f, %.2f", lat, lon) }
            }
        } catch (_: Exception) {
            String.format(Locale.US, "%.2f, %.2f", lat, lon)
        }
    }

    private fun formatDateBr(isoDate: String, index: Int): String {
        if (index == 0) return "Hoje"
        if (index == 1) return "Amanhã"
        val parts = isoDate.split("-")
        return if (parts.size == 3) "${parts[2]}/${parts[1]}" else isoDate
    }

    private fun wmoToPortuguese(code: Int): String = when (code) {
        0 -> "Céu limpo"
        1, 2 -> "Parcialmente nublado"
        3 -> "Nublado"
        45, 48 -> "Neblina"
        51, 53, 55 -> "Garoa leve"
        61, 63 -> "Chuva moderada"
        65 -> "Chuva forte"
        71, 73, 75 -> "Neve"
        80, 81, 82 -> "Pancadas de chuva"
        95, 96, 99 -> "Tempestade"
        else -> "Tempo estável"
    }
}
