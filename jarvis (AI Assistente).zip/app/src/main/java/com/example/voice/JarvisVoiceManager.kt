package com.example.voice

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.example.data.preferences.JarvisSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

enum class VoiceEngineState {
    IDLE,
    WAKE_LISTENING,
    ACTIVE_LISTENING,
    PROCESSING,
    SPEAKING,
    ERROR
}

enum class VoiceGenderTag {
    MASCULINE,
    FEMININE,
    NEUTRAL
}

data class JarvisVoiceOption(
    val name: String,
    val displayName: String,
    val localeTag: String,
    val genderTag: VoiceGenderTag,
    val requiresNetwork: Boolean
)

class JarvisVoiceManager(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val httpClient = OkHttpClient()

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speechRecognizer: SpeechRecognizer? = null
    private var externalPlayer: MediaPlayer? = null
    private var restartJob: Job? = null

    private var currentSettings = JarvisSettings()

    private val _engineState = MutableStateFlow(VoiceEngineState.IDLE)
    val engineState: StateFlow<VoiceEngineState> = _engineState.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _availableVoices = MutableStateFlow<List<JarvisVoiceOption>>(emptyList())
    val availableVoices: StateFlow<List<JarvisVoiceOption>> = _availableVoices.asStateFlow()

    private val _statusMessage = MutableStateFlow("Sistema de voz inicializado")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _recognizedCommands = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val recognizedCommands: SharedFlow<String> = _recognizedCommands.asSharedFlow()

    private var continuousMode = false
    private var awaitingCommandAfterWake = false
    private var pendingAfterSpeakAction: (() -> Unit)? = null

    init {
        initTts()
    }

    fun updateSettings(settings: JarvisSettings) {
        currentSettings = settings
        applyTtsParameters()
    }

    private fun initTts() {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                applyTtsParameters()
                refreshAvailableVoices()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        mainHandler.post {
                            _engineState.value = VoiceEngineState.SPEAKING
                            _statusMessage.value = "JARVIS falando..."
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        mainHandler.post {
                            val afterAction = pendingAfterSpeakAction
                            pendingAfterSpeakAction = null
                            if (afterAction != null) {
                                afterAction()
                            } else if (continuousMode) {
                                startListeningInternal(awaitingCommand = false)
                            } else {
                                _engineState.value = VoiceEngineState.IDLE
                                _statusMessage.value = "Pronto para comandos"
                            }
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        mainHandler.post {
                            pendingAfterSpeakAction = null
                            _engineState.value = VoiceEngineState.IDLE
                            _statusMessage.value = "Falha na síntese de voz"
                        }
                    }
                })
            } else {
                Log.e("JarvisVoice", "TextToSpeech init failed with status $status")
                _statusMessage.value = "Motor TTS indisponível neste dispositivo"
            }
        }
    }

    fun refreshAvailableVoices() {
        val engine = tts ?: return
        val voices = runCatching { engine.voices?.toList().orEmpty() }.getOrDefault(emptyList())
        val mapped = voices
            .sortedWith(compareBy<Voice> { it.locale.language != "pt" }.thenBy { it.name })
            .map { v ->
                val lower = v.name.lowercase(Locale.ROOT)
                val gender = when {
                    lower.contains("fem") || lower.contains("female") || lower.contains("pt-br-x-ptd") ||
                        lower.contains("pt-br-x-afs") || lower.contains("sfb") || lower.contains("ana") ->
                        VoiceGenderTag.FEMININE
                    lower.contains("mal") || lower.contains("male") || lower.contains("pt-br-x-pte") ||
                        lower.contains("pt-br-x-ptc") || lower.contains("ricardo") || lower.contains("daniel") ->
                        VoiceGenderTag.MASCULINE
                    else -> VoiceGenderTag.NEUTRAL
                }
                val friendlyLoc = v.locale.toLanguageTag()
                val shortLabel = v.name
                    .removePrefix("pt-br-x-")
                    .removePrefix("pt-pt-x-")
                    .replace("-", " ")
                    .uppercase(Locale.ROOT)
                JarvisVoiceOption(
                    name = v.name,
                    displayName = "$shortLabel ($friendlyLoc)",
                    localeTag = friendlyLoc,
                    genderTag = gender,
                    requiresNetwork = v.isNetworkConnectionRequired
                )
            }
        _availableVoices.value = mapped
    }

    private fun applyTtsParameters() {
        val engine = tts ?: return
        if (!ttsReady) return
        val locale = Locale.forLanguageTag(currentSettings.languageTag)
        engine.language = locale
        engine.setSpeechRate(currentSettings.speechRate)
        engine.setPitch(currentSettings.speechPitch)
        if (currentSettings.selectedVoiceName.isNotBlank()) {
            val target = runCatching {
                engine.voices?.firstOrNull { it.name == currentSettings.selectedVoiceName }
            }.getOrNull()
            if (target != null) {
                engine.voice = target
            }
        }
    }

    fun setSystemVoiceVolume(volumeFraction: Float) {
        runCatching {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val target = (maxVol * volumeFraction.coerceIn(0f, 1f)).toInt()
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
        }
    }

    fun speak(text: String, onComplete: (() -> Unit)? = null) {
        if (text.isBlank()) return
        stopListeningInternal()

        val ext = currentSettings
        if (ext.externalTtsEnabled && ext.externalTtsEndpoint.isNotBlank() && ext.externalTtsApiKey.isNotBlank()) {
            speakWithExternalProvider(text, ext, onComplete)
            return
        }

        speakWithAndroidTts(text, onComplete)
    }

    private fun speakWithAndroidTts(text: String, onComplete: (() -> Unit)?) {
        val engine = tts
        if (engine == null || !ttsReady) {
            onComplete?.invoke()
            return
        }
        applyTtsParameters()
        pendingAfterSpeakAction = onComplete
        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, currentSettings.assistantVolume.coerceIn(0f, 1f))
        }
        val utteranceId = UUID.randomUUID().toString()
        mainHandler.post {
            _engineState.value = VoiceEngineState.SPEAKING
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        }
    }

    private fun speakWithExternalProvider(
        text: String,
        settings: JarvisSettings,
        onComplete: (() -> Unit)?
    ) {
        scope.launch(Dispatchers.IO) {
            try {
                val payload = JSONObject().apply {
                    put("text", text)
                    put("voice_id", settings.externalTtsVoiceId)
                    put("language", settings.languageTag)
                }.toString().toRequestBody("application/json".toMediaType())

                val request = Request.Builder()
                    .url(settings.externalTtsEndpoint)
                    .addHeader("Authorization", "Bearer ${settings.externalTtsApiKey}")
                    .addHeader("xi-api-key", settings.externalTtsApiKey)
                    .post(payload)
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw IllegalStateException("HTTP ${response.code}")
                    }
                    val bytes = response.body?.bytes() ?: throw IllegalStateException("Corpo vazio")
                    val tempFile = File.createTempFile("jarvis_tts_", ".mp3", context.cacheDir)
                    tempFile.writeBytes(bytes)
                    mainHandler.post {
                        playAudioFile(tempFile.absolutePath, onComplete)
                    }
                }
            } catch (e: Exception) {
                Log.w("JarvisVoice", "External TTS failed, falling back to Android TTS: ${e.message}")
                mainHandler.post {
                    _statusMessage.value = "TTS externo indisponível (${e.message}), usando voz local"
                    speakWithAndroidTts(text, onComplete)
                }
            }
        }
    }

    private fun playAudioFile(path: String, onComplete: (() -> Unit)?) {
        stopExternalAudio()
        _engineState.value = VoiceEngineState.SPEAKING
        externalPlayer = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .build()
            )
            setDataSource(path)
            val vol = currentSettings.assistantVolume.coerceIn(0f, 1f)
            setVolume(vol, vol)
            setOnCompletionListener {
                stopExternalAudio()
                onComplete?.invoke() ?: run {
                    _engineState.value = if (continuousMode) VoiceEngineState.WAKE_LISTENING else VoiceEngineState.IDLE
                }
            }
            setOnErrorListener { _, _, _ ->
                stopExternalAudio()
                onComplete?.invoke()
                true
            }
            prepare()
            start()
        }
    }

    fun playImportedAudioSample(uriString: String) {
        if (uriString.isBlank()) return
        runCatching {
            stopExternalAudio()
            externalPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(context, Uri.parse(uriString))
                val vol = currentSettings.assistantVolume.coerceIn(0f, 1f)
                setVolume(vol, vol)
                setOnCompletionListener { stopExternalAudio() }
                prepare()
                start()
            }
        }.onFailure {
            _statusMessage.value = "Não foi possível reproduzir o áudio importado: ${it.localizedMessage}"
        }
    }

    private fun stopExternalAudio() {
        runCatching {
            externalPlayer?.stop()
            externalPlayer?.release()
        }
        externalPlayer = null
    }

    fun stopSpeaking() {
        pendingAfterSpeakAction = null
        runCatching { tts?.stop() }
        stopExternalAudio()
        if (_engineState.value == VoiceEngineState.SPEAKING) {
            _engineState.value = if (continuousMode) VoiceEngineState.WAKE_LISTENING else VoiceEngineState.IDLE
            _statusMessage.value = "Fala interrompida"
        }
    }

    fun resetProcessingState() {
        if (_engineState.value == VoiceEngineState.PROCESSING) {
            if (continuousMode) {
                startListeningInternal(awaitingCommand = false)
            } else {
                _engineState.value = VoiceEngineState.IDLE
                _statusMessage.value = "Pronto para tentar novamente"
            }
        }
    }

    fun startSingleCommandListening() {
        stopSpeaking()
        continuousMode = false
        startListeningInternal(awaitingCommand = true)
    }

    fun setContinuousWakeListening(enabled: Boolean) {
        continuousMode = enabled
        if (enabled) {
            startListeningInternal(awaitingCommand = false)
        } else {
            stopListeningInternal()
            _engineState.value = VoiceEngineState.IDLE
            _statusMessage.value = "Escuta contínua desativada"
        }
    }

    private fun startListeningInternal(awaitingCommand: Boolean) {
        mainHandler.post {
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                _engineState.value = VoiceEngineState.ERROR
                _statusMessage.value = "Reconhecimento de voz indisponível neste dispositivo"
                return@post
            }
            awaitingCommandAfterWake = awaitingCommand
            restartJob?.cancel()

            runCatching {
                speechRecognizer?.destroy()
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(createRecognitionListener())
                }
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, currentSettings.languageTag)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, currentSettings.languageTag)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }
                _partialTranscript.value = ""
                _engineState.value = if (awaitingCommand) {
                    VoiceEngineState.ACTIVE_LISTENING
                } else {
                    VoiceEngineState.WAKE_LISTENING
                }
                _statusMessage.value = if (awaitingCommand) {
                    "Ouvindo comando..."
                } else {
                    "Aguardando palavra '${currentSettings.wakeWord}'..."
                }
                speechRecognizer?.startListening(intent)
            }.onFailure { err ->
                Log.e("JarvisVoice", "startListening failed", err)
                _engineState.value = VoiceEngineState.ERROR
                _statusMessage.value = "Erro no microfone: ${err.localizedMessage}"
            }
        }
    }

    fun stopListening() {
        continuousMode = false
        stopListeningInternal()
        _engineState.value = VoiceEngineState.IDLE
        _statusMessage.value = "Microfone em espera"
    }

    private fun stopListeningInternal() {
        restartJob?.cancel()
        mainHandler.post {
            _rmsLevel.value = 0f
            runCatching {
                speechRecognizer?.stopListening()
                speechRecognizer?.cancel()
                speechRecognizer?.destroy()
            }
            speechRecognizer = null
        }
    }

    private fun createRecognitionListener() = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            _statusMessage.value = if (awaitingCommandAfterWake) {
                "Pode falar, senhor..."
            } else {
                "Escuta ativa ('${currentSettings.wakeWord}')"
            }
        }

        override fun onBeginningOfSpeech() {
            // Voice activity detected; interrupt TTS immediately if JARVIS was speaking
            if (_engineState.value == VoiceEngineState.SPEAKING) {
                stopSpeaking()
            }
        }

        override fun onRmsChanged(rmsdB: Float) {
            val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            _rmsLevel.value = normalized
        }

        override fun onBufferReceived(buffer: ByteArray?) = Unit

        override fun onEndOfSpeech() {
            _rmsLevel.value = 0f
            _statusMessage.value = "Processando fala..."
        }

        override fun onError(error: Int) {
            _rmsLevel.value = 0f
            if (continuousMode && (error == SpeechRecognizer.ERROR_NO_MATCH ||
                    error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                    error == SpeechRecognizer.ERROR_CLIENT)
            ) {
                scheduleContinuousRestart(650L)
            } else if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                continuousMode = false
                _engineState.value = VoiceEngineState.ERROR
                _statusMessage.value = "Permissão de microfone necessária"
            } else {
                _engineState.value = VoiceEngineState.IDLE
                _statusMessage.value = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "Não compreendi, senhor. Tente novamente."
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Nenhuma fala detectada."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "Erro de rede no reconhecimento de voz."
                    else -> "Microfone pausado (código $error)"
                }
            }
        }

        override fun onResults(results: Bundle?) {
            _rmsLevel.value = 0f
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            val transcript = matches.firstOrNull().orEmpty().trim()
            _partialTranscript.value = transcript
            handleRecognizedText(transcript)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
            if (partial.isNotBlank()) {
                _partialTranscript.value = partial
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    private fun handleRecognizedText(transcript: String) {
        if (transcript.isBlank()) {
            if (continuousMode) scheduleContinuousRestart(500L) else _engineState.value = VoiceEngineState.IDLE
            return
        }

        val wake = currentSettings.wakeWord.trim().lowercase(Locale.ROOT)
        val lower = transcript.lowercase(Locale.ROOT)

        // Voice interruption command
        if (lower == "parar" || lower == "silêncio" || lower == "silencio" || lower == "cancelar") {
            stopSpeaking()
            if (continuousMode) scheduleContinuousRestart(600L) else _engineState.value = VoiceEngineState.IDLE
            return
        }

        if (awaitingCommandAfterWake) {
            val cleaned = stripWakeWord(transcript, wake)
            if (cleaned.isNotBlank()) {
                _engineState.value = VoiceEngineState.PROCESSING
                _recognizedCommands.tryEmit(cleaned)
            } else {
                speak("Olá, senhor. Como posso ajudá-lo?") {
                    startListeningInternal(awaitingCommand = true)
                }
            }
            return
        }

        // Continuous wake-word mode
        val containsWake = wake.isNotBlank() && (
            lower.contains(wake) ||
                (wake == "jarvis" && (lower.contains("jarves") || lower.contains("já vis") || lower.contains("jorge")))
            )

        if (containsWake) {
            val remainder = stripWakeWord(transcript, wake)
            if (remainder.length > 2) {
                _engineState.value = VoiceEngineState.PROCESSING
                _recognizedCommands.tryEmit(remainder)
            } else {
                speak("Olá, senhor. Como posso ajudá-lo?") {
                    startListeningInternal(awaitingCommand = true)
                }
            }
        } else if (continuousMode) {
            scheduleContinuousRestart(450L)
        } else {
            _engineState.value = VoiceEngineState.IDLE
        }
    }

    private fun stripWakeWord(raw: String, wakeLower: String): String {
        return raw.replace(Regex("(?i)\\b${Regex.escape(wakeLower)}\\b[,.:!?\\s]*"), "").trim()
    }

    private fun scheduleContinuousRestart(delayMs: Long) {
        restartJob?.cancel()
        restartJob = scope.launch {
            delay(delayMs)
            if (continuousMode) {
                startListeningInternal(awaitingCommand = false)
            }
        }
    }

    fun release() {
        stopListeningInternal()
        stopExternalAudio()
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        tts = null
    }
}
