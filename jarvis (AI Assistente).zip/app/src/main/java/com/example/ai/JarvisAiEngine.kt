package com.example.ai

import android.content.Context
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import com.example.data.local.ChatMessageEntity
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.APINotConfiguredException
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.ContentBlockedException
import com.google.firebase.ai.type.FirebaseAIException
import com.google.firebase.ai.type.InvalidAPIKeyException
import com.google.firebase.ai.type.InvalidStateException
import com.google.firebase.ai.type.PermissionMissingException
import com.google.firebase.ai.type.PromptBlockedException
import com.google.firebase.ai.type.QuotaExceededException
import com.google.firebase.ai.type.RequestOptions
import com.google.firebase.ai.type.RequestTimeoutException
import com.google.firebase.ai.type.ResponseStoppedException
import com.google.firebase.ai.type.ServerException
import com.google.firebase.ai.type.ServiceConnectionHandshakeFailedException
import com.google.firebase.ai.type.ServiceDisabledException
import com.google.firebase.ai.type.UnsupportedUserLocationException
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.io.IOException
import java.net.ConnectException
import java.net.NoRouteToHostException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

private const val TAG = "JarvisAiEngine"

// Timeout constants synchronized with RequestOptions (180s SDK default caused hangs after 60s cutoff)
const val AI_REQUEST_TIMEOUT_MS = 90_000L
const val AI_FIRST_CHUNK_TIMEOUT_MS = 25_000L
const val AI_UNARY_FALLBACK_TIMEOUT_MS = 65_000L
private const val MAX_ATTACHMENT_BYTES = 18 * 1024 * 1024
private const val MAX_IMAGE_DIMENSION_PX = 1600
private const val LEGACY_ERROR_PREFIX = "Senhor, ocorreu um erro técnico:"

data class GeminiModelOption(
    val id: String,
    val label: String,
    val tierHint: String,
    val requiresBilling: Boolean
)

object JarvisGeminiModels {
    const val DEFAULT_MODEL = "gemini-3.8-flash"
    const val FAST_MODEL = "gemini-3.5-flash-lite"
    const val REASONING_MODEL = "gemini-4-argon"

    val supportedModels: List<GeminiModelOption> = listOf(
        GeminiModelOption(
            id = DEFAULT_MODEL,
            label = "gemini-3.8-flash",
            tierHint = "Padrão • Sem cobrança extra",
            requiresBilling = false
        ),
        GeminiModelOption(
            id = FAST_MODEL,
            label = "gemini-3.5-flash-lite",
            tierHint = "Ultra rápido • Baixa latência",
            requiresBilling = false
        ),
        GeminiModelOption(
            id = REASONING_MODEL,
            label = "gemini-4-argon",
            tierHint = "Avançado • Requer plano Blaze",
            requiresBilling = true
        )
    )

    fun normalize(modelName: String?): String {
        val clean = modelName?.trim().orEmpty()
        return if (supportedModels.any { it.id == clean }) clean else DEFAULT_MODEL
    }

    fun isAvailable(modelName: String?): Boolean {
        val clean = modelName?.trim().orEmpty()
        return supportedModels.any { it.id == clean }
    }
}

enum class JarvisAiErrorKind {
    OFFLINE,
    TIMEOUT,
    RATE_LIMIT,
    MODEL_OR_BILLING,
    AUTH_OR_CONFIG,
    BLOCKED,
    SERVER,
    EMPTY_RESPONSE,
    UNKNOWN
}

class JarvisAiException(
    message: String,
    val kind: JarvisAiErrorKind,
    val retryable: Boolean = true,
    cause: Throwable? = null
) : IllegalStateException(message, cause)

private class StreamStallException : CancellationException("Nenhum chunk recebido dentro do limite inicial")

enum class JarvisCommandAction {
    NONE,
    OPEN_WEATHER,
    OPEN_MAPS,
    OPEN_TRAFFIC,
    OPEN_HIGHWAYS,
    OPEN_ALARMS,
    CREATE_ALARM,
    OPEN_MUSIC,
    PLAY_MUSIC,
    PAUSE_MUSIC,
    NEXT_TRACK,
    OPEN_VOICE_SETTINGS,
    OPEN_SETTINGS,
    OPEN_INSTALL
}

data class ParsedJarvisIntent(
    val action: JarvisCommandAction = JarvisCommandAction.NONE,
    val queryParameter: String = "",
    val alarmHour: Int? = null,
    val alarmMinute: Int? = null
)

interface AiProvider {
    val providerId: String
    val displayName: String
    fun streamResponse(
        modelName: String,
        history: List<ChatMessageEntity>,
        userPrompt: String,
        imageBitmap: Bitmap? = null,
        documentBytes: ByteArray? = null,
        documentMimeType: String? = null,
        contextSummary: String = ""
    ): Flow<String>

    suspend fun detectCommandIntent(
        modelName: String,
        userUtterance: String
    ): ParsedJarvisIntent
}

class FirebaseGeminiProvider(
    private val context: Context? = null
) : AiProvider {
    override val providerId: String = "firebase_gemini"
    override val displayName: String = "Google Gemini (Firebase AI Logic)"

    private val systemPromptText = """
        Você é o JARVIS, um assistente pessoal de inteligência artificial altamente sofisticado, educado, preciso e estratégico.
        Diretrizes obrigatórias:
        1. Comunique-se exclusivamente em português brasileiro natural (a menos que o usuário peça outro idioma).
        2. Trate o usuário sempre como "senhor" de forma elegante, confiante e objetiva.
        3. Você pode responder perguntas gerais, explicar assuntos complexos com clareza, fazer cálculos precisos, resumir textos, analisar imagens e documentos enviados e auxiliar em tarefas diárias.
        4. Quando receber dados de contexto do sistema (clima atual, localização, trânsito, alarmes, música), utilize-os diretamente na resposta sem inventar números que não foram fornecidos.
        5. Seja conciso em respostas de voz quando apropriado, mas detalhado quando o senhor solicitar explicações ou análises.
    """.trimIndent()

    private val modelCache = mutableMapOf<String, GenerativeModel>()

    private fun getOrCreateModel(modelName: String): GenerativeModel {
        val normalized = JarvisGeminiModels.normalize(modelName)
        return synchronized(modelCache) {
            modelCache.getOrPut(normalized) {
                Firebase.ai.generativeModel(
                    modelName = normalized,
                    systemInstruction = content { text(systemPromptText) },
                    requestOptions = RequestOptions(AI_REQUEST_TIMEOUT_MS)
                )
            }
        }
    }

    override fun streamResponse(
        modelName: String,
        history: List<ChatMessageEntity>,
        userPrompt: String,
        imageBitmap: Bitmap?,
        documentBytes: ByteArray?,
        documentMimeType: String?,
        contextSummary: String
    ): Flow<String> = flow {
        val activeContext = context?.applicationContext
        if (activeContext != null && !isNetworkAvailable(activeContext)) {
            throw JarvisAiException(
                message = "Sem conexão com a internet, senhor. Verifique seu Wi-Fi ou dados móveis e toque em Tentar novamente.",
                kind = JarvisAiErrorKind.OFFLINE
            )
        }

        if (activeContext != null && !isFirebaseConfigured(activeContext)) {
            throw JarvisAiException(
                message = "Configuração do Firebase AI Logic incompleta neste aparelho, senhor. Verifique o google-services.json e App Check.",
                kind = JarvisAiErrorKind.AUTH_OR_CONFIG,
                retryable = false
            )
        }

        if (documentBytes != null && documentBytes.size > MAX_ATTACHMENT_BYTES) {
            throw JarvisAiException(
                message = "O documento anexado excede o limite de 18 MB suportado pela API Gemini, senhor.",
                kind = JarvisAiErrorKind.UNKNOWN,
                retryable = false
            )
        }

        val selectedModel = JarvisGeminiModels.normalize(modelName)
        if (selectedModel != modelName.trim() && modelName.isNotBlank()) {
            Log.w(TAG, "Modelo '$modelName' indisponível; normalizado para '$selectedModel'.")
        }

        val sanitizedHistory = sanitizeChatHistory(history)
        val fullPrompt = if (contextSummary.isNotBlank()) {
            "[Contexto em tempo real do sistema]\n$contextSummary\n\n[Solicitação do senhor]\n$userPrompt"
        } else {
            userPrompt
        }

        val scaledBitmap = imageBitmap?.let { downscaleBitmapIfNeeded(it) }
        val isMultimodal = scaledBitmap != null || (documentBytes != null && documentMimeType != null)
        val multimodalInput = if (isMultimodal) {
            content("user") {
                if (scaledBitmap != null) image(scaledBitmap)
                if (documentBytes != null && documentMimeType != null) {
                    inlineData(documentBytes, documentMimeType)
                }
                text(fullPrompt)
            }
        } else {
            null
        }

        var currentModelName = selectedModel
        var emittedText = ""

        try {
            emittedText = executeModelWithFallback(
                modelName = currentModelName,
                history = sanitizedHistory,
                fullPrompt = fullPrompt,
                multimodalInput = multimodalInput,
                onChunk = { accumulated -> emit(accumulated) }
            )
        } catch (primaryError: CancellationException) {
            throw primaryError
        } catch (primaryError: Throwable) {
            // If user selected Blaze-only model (gemini-4-argon) and backend rejected billing/model availability,
            // fall back once to free-tier default gemini-3.8-flash.
            val canFallbackModel = currentModelName != JarvisGeminiModels.DEFAULT_MODEL &&
                isModelUnavailableOrBillingError(primaryError)
            if (!canFallbackModel) {
                throw mapGeminiException(primaryError, currentModelName)
            }
            Log.w(TAG, "Modelo '$currentModelName' indisponível/requer Blaze; tentando fallback '${JarvisGeminiModels.DEFAULT_MODEL}'.", primaryError)
            currentModelName = JarvisGeminiModels.DEFAULT_MODEL
            try {
                emittedText = executeModelWithFallback(
                    modelName = currentModelName,
                    history = sanitizedHistory,
                    fullPrompt = fullPrompt,
                    multimodalInput = multimodalInput,
                    onChunk = { accumulated -> emit(accumulated) }
                )
            } catch (fallbackError: CancellationException) {
                throw fallbackError
            } catch (fallbackError: Throwable) {
                throw mapGeminiException(fallbackError, currentModelName)
            }
        }

        if (emittedText.isBlank()) {
            throw JarvisAiException(
                message = "O Google Gemini ($currentModelName) não retornou conteúdo para esta solicitação, senhor.",
                kind = JarvisAiErrorKind.EMPTY_RESPONSE
            )
        }
    }

    private suspend fun executeModelWithFallback(
        modelName: String,
        history: List<Content>,
        fullPrompt: String,
        multimodalInput: Content?,
        onChunk: suspend (String) -> Unit
    ): String {
        val model = getOrCreateModel(modelName)
        val accumulated = StringBuilder()

        val streamError: Throwable? = try {
            withTimeout(AI_REQUEST_TIMEOUT_MS) {
                coroutineScope {
                    val streamJob = launch {
                        val flowToCollect = if (multimodalInput != null) {
                            model.generateContentStream(multimodalInput)
                        } else {
                            model.startChat(history = history).sendMessageStream(fullPrompt)
                        }
                        flowToCollect.collect { chunk ->
                            val piece = chunk.text.orEmpty()
                            if (piece.isNotEmpty()) {
                                accumulated.append(piece)
                                onChunk(accumulated.toString())
                            }
                        }
                    }

                    val watchdogJob = launch {
                        delay(AI_FIRST_CHUNK_TIMEOUT_MS)
                        if (accumulated.isEmpty() && streamJob.isActive) {
                            Log.w(TAG, "Streaming ($modelName) sem resposta após ${AI_FIRST_CHUNK_TIMEOUT_MS}ms; alternando para chamada direta.")
                            streamJob.cancel(StreamStallException())
                        }
                    }

                    try {
                        streamJob.join()
                    } finally {
                        watchdogJob.cancel()
                    }
                }
            }
            null
        } catch (e: TimeoutCancellationException) {
            e
        } catch (e: CancellationException) {
            if (e is StreamStallException || findCause<StreamStallException>(e) != null) {
                e
            } else {
                throw e
            }
        } catch (e: Throwable) {
            e
        }

        // If streaming succeeded and returned content, we are done.
        if (streamError == null && accumulated.isNotBlank()) {
            return accumulated.toString()
        }

        // If streaming failed after already emitting partial text, fail transparently or surface error.
        if (accumulated.isNotEmpty() && streamError != null) {
            throw streamError
        }

        // Non-retryable client/policy errors should not be masked with a second call.
        if (streamError != null && !shouldAttemptUnaryFallback(streamError)) {
            throw streamError
        }

        Log.i(TAG, "Executando fallback unário (generateContent/sendMessage) no modelo '$modelName'...")
        val unaryResponse = withTimeout(AI_UNARY_FALLBACK_TIMEOUT_MS) {
            if (multimodalInput != null) {
                model.generateContent(multimodalInput)
            } else {
                model.startChat(history = history).sendMessage(fullPrompt)
            }
        }

        val text = unaryResponse.text.orEmpty()
        if (text.isNotBlank()) {
            onChunk(text)
        }
        return text
    }

    override suspend fun detectCommandIntent(
        modelName: String,
        userUtterance: String
    ): ParsedJarvisIntent {
        // Deterministic local Portuguese parser avoids burning an extra Gemini network round-trip
        // and quota before every user prompt.
        return detectLocalCommandIntent(userUtterance)
    }

    private fun isFirebaseConfigured(ctx: Context): Boolean {
        return runCatching {
            val app = FirebaseApp.getApps(ctx).firstOrNull() ?: FirebaseApp.initializeApp(ctx)
            val opts = app?.options
            opts != null && opts.apiKey.isNotBlank() && !opts.projectId.isNullOrBlank()
        }.getOrDefault(false)
    }
}

fun isNetworkAvailable(context: Context): Boolean {
    return runCatching {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return true
        val activeNetwork = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return false
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }.getOrDefault(true)
}

fun sanitizeChatHistory(
    history: List<ChatMessageEntity>,
    maxMessages: Int = 14
): List<Content> {
    val cleaned = history
        .asSequence()
        .filter { msg ->
            msg.content.isNotBlank() &&
                !msg.content.trim().startsWith(LEGACY_ERROR_PREFIX)
        }
        .toList()
        .takeLast(maxMessages)

    if (cleaned.isEmpty()) return emptyList()

    // Normalize alternating turns: must start with "user" and strictly alternate user/model
    val normalized = mutableListOf<Pair<String, String>>()
    for (msg in cleaned) {
        val role = if (msg.role == "model") "model" else "user"
        val text = msg.content.trim()
        if (normalized.isEmpty()) {
            if (role == "user") {
                normalized.add(role to text)
            }
        } else {
            val lastRole = normalized.last().first
            if (lastRole == role) {
                // Replace consecutive same-role entry with the latest turn to preserve alternation
                normalized[normalized.lastIndex] = role to text
            } else {
                normalized.add(role to text)
            }
        }
    }

    // History passed to startChat() should end on "model" because sendMessage* adds the new "user" turn.
    if (normalized.lastOrNull()?.first == "user") {
        normalized.removeAt(normalized.lastIndex)
    }

    return normalized.map { (role, text) ->
        content(role) { text(text) }
    }
}

fun detectLocalCommandIntent(userUtterance: String): ParsedJarvisIntent {
    val raw = userUtterance.trim()
    if (raw.isBlank()) return ParsedJarvisIntent()
    val lower = raw.lowercase(Locale("pt", "BR"))

    // 1. Alarm creation & management
    val isAlarmMention = lower.contains("alarme") || lower.contains("despertador") ||
        lower.contains("me acorde") || lower.contains("acordar às") || lower.contains("acordar as")
    if (isAlarmMention) {
        val timeMatch = Regex("(?:às|as|para|pra)?\\s*(\\d{1,2})(?::|h)(\\d{2})?\\b").find(lower)
        if (timeMatch != null && (lower.contains("cri") || lower.contains("defin") ||
                lower.contains("coloc") || lower.contains("acord") || lower.contains("para"))
        ) {
            val hour = timeMatch.groupValues[1].toIntOrNull()?.coerceIn(0, 23)
            val min = timeMatch.groupValues[2].toIntOrNull()?.coerceIn(0, 59) ?: 0
            if (hour != null) {
                return ParsedJarvisIntent(
                    action = JarvisCommandAction.CREATE_ALARM,
                    alarmHour = hour,
                    alarmMinute = min
                )
            }
        }
        if (lower.contains("abrir") || lower.contains("ver") || lower.contains("mostr") || lower.length < 40) {
            return ParsedJarvisIntent(action = JarvisCommandAction.OPEN_ALARMS)
        }
    }

    // 2. Music controls
    if ((lower.contains("pausar") || lower.contains("parar")) && lower.contains("músic") ||
        lower.contains("pausar música") || lower.contains("pausar musica")
    ) {
        return ParsedJarvisIntent(action = JarvisCommandAction.PAUSE_MUSIC)
    }
    if (lower.contains("próxima música") || lower.contains("proxima musica") || lower.contains("próxima faixa")) {
        return ParsedJarvisIntent(action = JarvisCommandAction.NEXT_TRACK)
    }
    if (lower.contains("tocar música") || lower.contains("tocar musica") || lower.startsWith("toque ")) {
        val trackQuery = raw.replace(Regex("(?i).*?(?:tocar música|tocar musica|toque)\\s*"), "").trim()
        return ParsedJarvisIntent(action = JarvisCommandAction.PLAY_MUSIC, queryParameter = trackQuery)
    }
    if (lower.contains("abrir música") || lower.contains("abrir musica") || lower.contains("minhas músicas")) {
        return ParsedJarvisIntent(action = JarvisCommandAction.OPEN_MUSIC)
    }

    // 3. Weather commands / live forecast queries
    val weatherKeywords = listOf("vai chover", "previsão do tempo", "previsao do tempo", "como está o tempo", "como esta o tempo", "clima em", "clima de", "temperatura atual", "clima hoje", "tempo amanhã")
    if (weatherKeywords.any { lower.contains(it) } ||
        ((lower.startsWith("clima") || lower.startsWith("jarvis, clima")) && lower.length < 50)
    ) {
        val city = extractLocationSuffix(raw)
        return ParsedJarvisIntent(action = JarvisCommandAction.OPEN_WEATHER, queryParameter = city)
    }

    // 4. Traffic & Highways
    if (lower.contains("mostre o trânsito") || lower.contains("mostre o transito") ||
        lower.contains("como está o trânsito") || lower.contains("como esta o transito") ||
        lower.contains("trânsito agora") || lower.contains("abrir trânsito")
    ) {
        return ParsedJarvisIntent(
            action = JarvisCommandAction.OPEN_TRAFFIC,
            queryParameter = extractLocationSuffix(raw)
        )
    }
    if (lower.contains("como está a rodovia") || lower.contains("como esta a rodovia") ||
        lower.contains("mostre a rodovia") || lower.contains("abrir rodovias")
    ) {
        return ParsedJarvisIntent(
            action = JarvisCommandAction.OPEN_HIGHWAYS,
            queryParameter = extractLocationSuffix(raw)
        )
    }

    // 5. Maps & routing commands
    if (lower.contains("caminho mais rápido") || lower.contains("caminho mais rapido") ||
        lower.contains("rota para") || lower.contains("como chegar em") ||
        lower.contains("como chegar a") || lower.contains("abrir mapa")
    ) {
        return ParsedJarvisIntent(
            action = JarvisCommandAction.OPEN_MAPS,
            queryParameter = extractLocationSuffix(raw)
        )
    }

    // 6. Voice, Settings & Install without PC navigation
    if (lower.contains("instalar no tablet") || lower.contains("instalar no celular") ||
        lower.contains("baixar no tablet") || lower.contains("baixar no celular") ||
        lower.contains("sem computador") || lower.contains("sem pc") ||
        lower.contains("compartilhar aplicativo") || lower.contains("instalar o jarvis")
    ) {
        return ParsedJarvisIntent(action = JarvisCommandAction.OPEN_INSTALL)
    }
    if (lower.contains("voz do jarvis") || lower.contains("configurar voz") || lower.contains("trocar voz")) {
        return ParsedJarvisIntent(action = JarvisCommandAction.OPEN_VOICE_SETTINGS)
    }
    if (lower.contains("abrir configurações") || lower.contains("abrir configuracoes") || lower.contains("abrir ajustes")) {
        return ParsedJarvisIntent(action = JarvisCommandAction.OPEN_SETTINGS)
    }

    return ParsedJarvisIntent(action = JarvisCommandAction.NONE)
}

private fun extractLocationSuffix(raw: String): String {
    val match = Regex("(?i)\\b(?:em|para|na|no|até|ate)\\s+([\\p{L}0-9\\s\\-]{2,40})[?.!]*$").find(raw.trim())
    return match?.groupValues?.getOrNull(1)?.trim().orEmpty()
}

private fun downscaleBitmapIfNeeded(bitmap: Bitmap): Bitmap {
    val maxDim = max(bitmap.width, bitmap.height)
    if (maxDim <= MAX_IMAGE_DIMENSION_PX) return bitmap
    val scale = MAX_IMAGE_DIMENSION_PX.toFloat() / maxDim.toFloat()
    val targetW = (bitmap.width * scale).roundToInt().coerceAtLeast(1)
    val targetH = (bitmap.height * scale).roundToInt().coerceAtLeast(1)
    return Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
}

private fun shouldAttemptUnaryFallback(error: Throwable): Boolean {
    if (error is TimeoutCancellationException || error is StreamStallException) return true
    if (findCause<StreamStallException>(error) != null) return true
    if (error is PromptBlockedException || error is ContentBlockedException) return false
    if (error is InvalidAPIKeyException || error is APINotConfiguredException) return false
    if (error is QuotaExceededException) return false
    val msg = error.message.orEmpty().lowercase(Locale.ROOT)
    if (msg.contains("app check") || msg.contains("403") || msg.contains("401") || msg.contains("429")) {
        return false
    }
    return true
}

private fun isModelUnavailableOrBillingError(error: Throwable): Boolean {
    if (error is ServiceDisabledException || error is PermissionMissingException) {
        val msg = error.message.orEmpty().lowercase(Locale.ROOT)
        if (msg.contains("app check")) return false
        return true
    }
    val msg = generateSequence(error) { it.cause }
        .mapNotNull { it.message }
        .joinToString(" ")
        .lowercase(Locale.ROOT)
    return (msg.contains("billing") || msg.contains("blaze") || msg.contains("not found") ||
        msg.contains("is not supported") || msg.contains("model")) &&
        !msg.contains("app check")
}

fun mapGeminiException(throwable: Throwable, modelName: String): JarvisAiException {
    if (throwable is JarvisAiException) return throwable

    val chainMessages = generateSequence(throwable) { it.cause }
        .mapNotNull { it.message }
        .joinToString(" | ")
    val lower = chainMessages.lowercase(Locale.ROOT)

    return when {
        throwable is TimeoutCancellationException ||
            findCause<TimeoutCancellationException>(throwable) != null ||
            throwable is RequestTimeoutException ||
            findCause<RequestTimeoutException>(throwable) != null ||
            findCause<SocketTimeoutException>(throwable) != null -> JarvisAiException(
            message = "Tempo limite excedido ao consultar o Gemini ($modelName), senhor. Verifique sua conexão e tente novamente.",
            kind = JarvisAiErrorKind.TIMEOUT,
            cause = throwable
        )

        throwable is QuotaExceededException ||
            findCause<QuotaExceededException>(throwable) != null ||
            lower.contains("429") ||
            lower.contains("quota") ||
            lower.contains("resource_exhausted") ||
            lower.contains("rate limit") -> JarvisAiException(
            message = "Limite de requisições da API Gemini atingido temporariamente (429). Aguarde alguns segundos e tente novamente, senhor.",
            kind = JarvisAiErrorKind.RATE_LIMIT,
            cause = throwable
        )

        findCause<UnknownHostException>(throwable) != null ||
            findCause<ConnectException>(throwable) != null ||
            findCause<NoRouteToHostException>(throwable) != null ||
            throwable is ServiceConnectionHandshakeFailedException ||
            findCause<ServiceConnectionHandshakeFailedException>(throwable) != null ||
            findCause<IOException>(throwable) != null -> JarvisAiException(
            message = "Não foi possível conectar aos servidores do Google Gemini, senhor. Verifique sua internet e tente novamente.",
            kind = JarvisAiErrorKind.OFFLINE,
            cause = throwable
        )

        throwable is InvalidAPIKeyException ||
            throwable is APINotConfiguredException ||
            lower.contains("app check") ||
            lower.contains("unauthenticated") ||
            lower.contains("401") -> JarvisAiException(
            message = "Falha de autenticação/App Check ao acessar o Firebase AI Logic ($modelName), senhor. Detalhe: ${throwable.localizedMessage ?: "verifique google-services.json e App Check"}.",
            kind = JarvisAiErrorKind.AUTH_OR_CONFIG,
            cause = throwable
        )

        throwable is ServiceDisabledException ||
            throwable is PermissionMissingException ||
            throwable is UnsupportedUserLocationException ||
            lower.contains("403") ||
            lower.contains("404") ||
            lower.contains("billing") -> JarvisAiException(
            message = if (modelName == JarvisGeminiModels.REASONING_MODEL) {
                "O modelo $modelName exige faturamento ativo (plano Blaze) ou está indisponível. Selecione '$${JarvisGeminiModels.DEFAULT_MODEL}' em Configurações e tente novamente, senhor."
                    .replace("$$", "")
            } else {
                "Serviço ou modelo Gemini ($modelName) indisponível ou bloqueado pela API (detalhe: ${throwable.localizedMessage ?: "HTTP 403/404"})."
            },
            kind = JarvisAiErrorKind.MODEL_OR_BILLING,
            cause = throwable
        )

        throwable is PromptBlockedException ||
            throwable is ContentBlockedException ||
            throwable is ResponseStoppedException -> JarvisAiException(
            message = "A solicitação ou resposta foi interrompida pelas políticas de segurança do Gemini, senhor. Reformule sua pergunta.",
            kind = JarvisAiErrorKind.BLOCKED,
            retryable = false,
            cause = throwable
        )

        throwable is ServerException ||
            throwable is InvalidStateException ||
            lower.contains("500") ||
            lower.contains("503") -> JarvisAiException(
            message = "Os servidores do Google Gemini retornaram um erro temporário, senhor. Toque em Tentar novamente.",
            kind = JarvisAiErrorKind.SERVER,
            cause = throwable
        )

        else -> JarvisAiException(
            message = "Falha na comunicação com o Google Gemini ($modelName): ${throwable.localizedMessage ?: "erro inesperado"}.",
            kind = JarvisAiErrorKind.UNKNOWN,
            cause = throwable
        )
    }
}

private inline fun <reified T : Throwable> findCause(throwable: Throwable): T? {
    return generateSequence(throwable) { it.cause }
        .filterIsInstance<T>()
        .firstOrNull()
}

class AiProviderRegistry(
    private val defaultProvider: AiProvider = FirebaseGeminiProvider()
) {
    private val providers = mutableMapOf(
        defaultProvider.providerId to defaultProvider
    )

    fun registerProvider(provider: AiProvider) {
        providers[provider.providerId] = provider
    }

    fun getActiveProvider(providerId: String = defaultProvider.providerId): AiProvider {
        return providers[providerId] ?: defaultProvider
    }

    fun availableProviders(): List<AiProvider> = providers.values.toList()
}
