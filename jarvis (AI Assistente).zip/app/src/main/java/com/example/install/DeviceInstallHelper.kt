package com.example.install

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

data class DeviceInstallInfo(
    val deviceModel: String,
    val deviceFormFactor: String,
    val androidVersion: String,
    val abiArchitecture: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val apkSizeMb: Double,
    val isSplitApkInstall: Boolean,
    val canExportUniversalApk: Boolean,
    val suggestedApkFileName: String
)

data class QrMatrixData(
    val width: Int,
    val height: Int,
    val darkModules: BooleanArray
)

fun inspectDeviceInstallInfo(
    context: Context,
    isTabletScreen: Boolean
): DeviceInstallInfo {
    val pkgManager = context.packageManager
    val pkgInfo = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pkgManager.getPackageInfo(
                context.packageName,
                PackageManager.PackageInfoFlags.of(0L)
            )
        } else {
            @Suppress("DEPRECATION")
            pkgManager.getPackageInfo(context.packageName, 0)
        }
    }.getOrNull()

    val appInfo = context.applicationInfo
    val sourceFile = appInfo.sourceDir?.let { File(it) }
    val sizeBytes = if (sourceFile != null && sourceFile.exists()) sourceFile.length() else 0L
    val sizeMb = sizeBytes.toDouble() / (1024.0 * 1024.0)
    val splitDirs = appInfo.splitSourceDirs
    val isSplit = !splitDirs.isNullOrEmpty()
    val canExport = sourceFile != null && sourceFile.exists() && sourceFile.canRead() && !isSplit

    val manufacturer = Build.MANUFACTURER.orEmpty().trim()
        .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
    val model = Build.MODEL.orEmpty().trim()
    val fullDeviceName = if (model.startsWith(manufacturer, ignoreCase = true)) {
        model
    } else {
        "$manufacturer $model".trim()
    }.ifBlank { "Dispositivo Android" }

    val versionName = pkgInfo?.versionName?.ifBlank { "1.0" } ?: "1.0"
    val versionCode = pkgInfo?.let { PackageInfoCompat.getLongVersionCode(it) } ?: 1L
    val sanitizedVersion = versionName.replace(Regex("[^a-zA-Z0-9._-]"), "_")

    return DeviceInstallInfo(
        deviceModel = fullDeviceName,
        deviceFormFactor = if (isTabletScreen) "Tablet Android" else "Smartphone Android",
        androidVersion = "Android ${Build.VERSION.RELEASE ?: "?"} (API ${Build.VERSION.SDK_INT})",
        abiArchitecture = Build.SUPPORTED_ABIS.firstOrNull().orEmpty().ifBlank { "arm64-v8a" },
        packageName = context.packageName,
        versionName = versionName,
        versionCode = versionCode,
        apkSizeMb = sizeMb,
        isSplitApkInstall = isSplit,
        canExportUniversalApk = canExport,
        suggestedApkFileName = "JARVIS-v$sanitizedVersion.apk"
    )
}

suspend fun exportInstalledApkToCache(context: Context): Result<File> = withContext(Dispatchers.IO) {
    runCatching {
        val appInfo = context.applicationInfo
        if (!appInfo.splitSourceDirs.isNullOrEmpty()) {
            throw IllegalStateException(
                "Este aparelho recebeu pacotes divididos (AAB). Use o link de download ou QR Code para instalar no outro aparelho."
            )
        }
        val sourcePath = appInfo.sourceDir
            ?: throw IllegalStateException("Arquivo APK instalado não localizado neste dispositivo.")
        val sourceFile = File(sourcePath)
        if (!sourceFile.exists() || !sourceFile.canRead()) {
            throw IllegalStateException("O sistema não permitiu leitura do pacote instalado.")
        }

        val info = inspectDeviceInstallInfo(context, isTabletScreen = false)
        val exportDir = File(context.cacheDir, "apk_export")
        if (!exportDir.exists()) exportDir.mkdirs()
        exportDir.listFiles()?.forEach { old -> old.delete() }

        val destFile = File(exportDir, info.suggestedApkFileName)
        sourceFile.inputStream().use { input ->
            destFile.outputStream().use { output ->
                input.copyTo(output, bufferSize = 64 * 1024)
            }
        }
        destFile
    }
}

fun buildShareApkIntent(context: Context, apkFile: File): Intent {
    val contentUri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        apkFile
    )
    val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "application/vnd.android.package-archive"
        putExtra(Intent.EXTRA_STREAM, contentUri)
        putExtra(Intent.EXTRA_SUBJECT, "Instalador JARVIS Android (Sem PC)")
        putExtra(
            Intent.EXTRA_TEXT,
            "Abra o arquivo anexo no seu Celular ou Tablet Android para instalar o JARVIS sem precisar de computador."
        )
        clipData = ClipData.newRawUri("JARVIS APK", contentUri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    return Intent.createChooser(shareIntent, "Enviar JARVIS para Celular ou Tablet").apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}

suspend fun saveInstalledApkToUri(context: Context, destinationUri: Uri): Result<Long> =
    withContext(Dispatchers.IO) {
        runCatching {
            val appInfo = context.applicationInfo
            if (!appInfo.splitSourceDirs.isNullOrEmpty()) {
                throw IllegalStateException(
                    "Instalação via pacotes divididos (AAB): use o link web ou QR Code para baixar o instalador completo."
                )
            }
            val sourcePath = appInfo.sourceDir
                ?: throw IllegalStateException("Pacote base instalado indisponível.")
            val sourceFile = File(sourcePath)
            if (!sourceFile.exists() || !sourceFile.canRead()) {
                throw IllegalStateException("Não foi possível ler o pacote instalado.")
            }

            val outputStream = context.contentResolver.openOutputStream(destinationUri)
                ?: throw IllegalStateException("Não foi possível gravar no destino selecionado.")

            var totalBytes = 0L
            sourceFile.inputStream().use { input ->
                outputStream.use { output ->
                    totalBytes = input.copyTo(output, bufferSize = 64 * 1024)
                }
            }
            totalBytes
        }
    }

fun normalizeInstallDownloadUrl(rawUrl: String): String? {
    val trimmed = rawUrl.trim()
    if (trimmed.isBlank() || trimmed.contains(' ')) return null
    val hasExplicitScheme = trimmed.contains("://")
    val withScheme = when {
        trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true) -> trimmed
        hasExplicitScheme -> return null
        trimmed.contains('.') -> "https://$trimmed"
        else -> return null
    }
    val parsed = runCatching { Uri.parse(withScheme) }.getOrNull() ?: return null
    val scheme = parsed.scheme?.lowercase(Locale.ROOT)
    val host = parsed.host.orEmpty()
    return if (host.isNotBlank() && (scheme == "https" || scheme == "http")) {
        withScheme
    } else {
        null
    }
}

fun openExternalDownloadUrl(context: Context, rawUrl: String): Result<Unit> {
    val validUrl = normalizeInstallDownloadUrl(rawUrl)
        ?: return Result.failure(
            IllegalArgumentException("Informe um link válido (https://...) para baixar o aplicativo no navegador.")
        )
    return runCatching {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(validUrl)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}

fun openSecurityInstallSettings(context: Context): Result<Unit> {
    return runCatching {
        val securityIntent = Intent(Settings.ACTION_SECURITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(securityIntent)
    }.recoverCatching {
        val appDetails = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${context.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(appDetails)
    }
}

fun generateQrMatrix(content: String, sizePx: Int = 64): QrMatrixData? {
    val clean = content.trim()
    if (clean.isBlank()) return null
    return runCatching {
        val hints = mapOf(
            EncodeHintType.MARGIN to 1
        )
        val bitMatrix = QRCodeWriter().encode(clean, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
        val w = bitMatrix.width
        val h = bitMatrix.height
        val dark = BooleanArray(w * h)
        for (y in 0 until h) {
            val offset = y * w
            for (x in 0 until w) {
                dark[offset + x] = bitMatrix.get(x, y)
            }
        }
        QrMatrixData(width = w, height = h, darkModules = dark)
    }.getOrNull()
}
