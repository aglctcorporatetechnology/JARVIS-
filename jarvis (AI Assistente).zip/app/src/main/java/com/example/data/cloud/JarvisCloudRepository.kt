package com.example.data.cloud

import android.content.Context
import com.example.R
import com.example.data.preferences.JarvisSettings
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class JarvisCloudRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("O usuário precisa estar conectado com a conta Google antes de acessar o Firestore.")
    }

    fun observeProfile(userId: String): Flow<CloudUserProfile?> = flow {
        val docRef = db.collection("users").document(userId)
        emitAll(
            docRef.snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            CloudUserProfile::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else {
                        null
                    }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, docRef.path, auth)
                    }
                    throw error
                }
        )
    }

    suspend fun ensureUserProfile(
        displayName: String?,
        email: String?,
        initialSettings: JarvisSettings
    ): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        return try {
            val snapshot = docRef.get().await()
            if (!snapshot.exists()) {
                val payload = mutableMapOf<String, Any>(
                    "userId" to uid,
                    "wakeWord" to initialSettings.wakeWord.trim().ifBlank { "JARVIS" }.take(40),
                    "languageTag" to initialSettings.languageTag.ifBlank { "pt-BR" }.take(20),
                    "speechRate" to initialSettings.speechRate.toDouble().coerceIn(0.5, 2.0),
                    "speechPitch" to initialSettings.speechPitch.toDouble().coerceIn(0.5, 1.5),
                    "assistantVolume" to initialSettings.assistantVolume.toDouble().coerceIn(0.0, 1.0),
                    "geminiModelName" to initialSettings.geminiModelName.take(80),
                    "hudGlowIntensity" to initialSettings.hudGlowIntensity.toDouble().coerceIn(0.2, 1.0),
                    "globeAnimationEnabled" to initialSettings.globeAnimationEnabled,
                    "defaultSnoozeMinutes" to initialSettings.defaultSnoozeMinutes.coerceIn(1, 30),
                    "alarmVolume" to initialSettings.alarmVolume.toDouble().coerceIn(0.0, 1.0),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (!displayName.isNullOrBlank()) {
                    payload["displayName"] = displayName.trim().take(120)
                }
                if (!email.isNullOrBlank()) {
                    payload["email"] = email.trim().take(160)
                }
                docRef.set(payload).await()
            } else {
                val updates = mutableMapOf<String, Any>(
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (!displayName.isNullOrBlank()) {
                    updates["displayName"] = displayName.trim().take(120)
                }
                if (!email.isNullOrBlank()) {
                    updates["email"] = email.trim().take(160)
                }
                docRef.update(updates).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun syncSettings(settings: JarvisSettings): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        val updates = mapOf<String, Any>(
            "wakeWord" to settings.wakeWord.trim().ifBlank { "JARVIS" }.take(40),
            "languageTag" to settings.languageTag.ifBlank { "pt-BR" }.take(20),
            "speechRate" to settings.speechRate.toDouble().coerceIn(0.5, 2.0),
            "speechPitch" to settings.speechPitch.toDouble().coerceIn(0.5, 1.5),
            "assistantVolume" to settings.assistantVolume.toDouble().coerceIn(0.0, 1.0),
            "geminiModelName" to settings.geminiModelName.take(80),
            "hudGlowIntensity" to settings.hudGlowIntensity.toDouble().coerceIn(0.2, 1.0),
            "globeAnimationEnabled" to settings.globeAnimationEnabled,
            "defaultSnoozeMinutes" to settings.defaultSnoozeMinutes.coerceIn(1, 30),
            "alarmVolume" to settings.alarmVolume.toDouble().coerceIn(0.0, 1.0),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            val snap = docRef.get().await()
            if (snap.exists()) {
                docRef.update(updates).await()
            } else {
                val createPayload = updates + mapOf(
                    "userId" to uid,
                    "createdAt" to FieldValue.serverTimestamp()
                )
                docRef.set(createPayload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    fun observeMessages(userId: String, sessionId: String = "default"): Flow<List<CloudChatMessage>> = flow {
        val path = "users/$userId/messages"
        val query = db.collection("users").document(userId).collection("messages")
            .whereEqualTo("sessionId", sessionId)
            .orderBy("createdAt", Query.Direction.ASCENDING)
        emitAll(
            query.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        CloudChatMessage::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path, auth)
                    }
                    throw error
                }
        )
    }

    suspend fun addMessage(
        role: String,
        content: String,
        attachmentName: String? = null,
        sessionId: String = "default",
        messageId: String? = null
    ): Result<String> {
        val uid = requireUserId()
        val cleanContent = content.trim().take(20000)
        if (cleanContent.isEmpty()) return Result.failure(IllegalArgumentException("Mensagem vazia"))
        val colRef = db.collection("users").document(uid).collection("messages")
        val docRef = if (messageId.isNullOrBlank()) colRef.document() else colRef.document(messageId)
        val payload = buildMap<String, Any> {
            put("userId", uid)
            put("sessionId", sessionId.take(64))
            put("role", if (role == "model") "model" else "user")
            put("content", cleanContent)
            if (!attachmentName.isNullOrBlank()) {
                put("attachmentName", attachmentName.take(200))
            }
            put("createdAt", FieldValue.serverTimestamp())
        }
        return try {
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun clearMessages(sessionId: String = "default"): Result<Unit> {
        val uid = requireUserId()
        val colRef = db.collection("users").document(uid).collection("messages")
        return try {
            val docs = colRef.whereEqualTo("sessionId", sessionId).get().await()
            for (chunk in docs.documents.chunked(400)) {
                val batch = db.batch()
                chunk.forEach { batch.delete(it.reference) }
                batch.commit().await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, colRef.path, auth)
            Result.failure(e)
        }
    }

    fun observeAlarms(userId: String): Flow<List<CloudAlarm>> = flow {
        val path = "users/$userId/alarms"
        val query = db.collection("users").document(userId).collection("alarms")
            .orderBy("hour", Query.Direction.ASCENDING)
        emitAll(
            query.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        CloudAlarm::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedWith(compareBy({ it.hour }, { it.minute }))
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path, auth)
                    }
                    throw error
                }
        )
    }

    suspend fun upsertAlarm(
        alarmId: String? = null,
        hour: Int,
        minute: Int,
        label: String,
        enabled: Boolean,
        daysOfWeekCsv: String,
        repeatWeekly: Boolean,
        speakJarvisGreeting: Boolean,
        soundTitle: String,
        volume: Float
    ): Result<String> {
        val uid = requireUserId()
        val colRef = db.collection("users").document(uid).collection("alarms")
        val docRef = if (alarmId.isNullOrBlank()) colRef.document() else colRef.document(alarmId)
        val cleanLabel = label.trim().ifBlank { "Alarme JARVIS" }.take(120)
        val cleanSoundTitle = soundTitle.trim().ifBlank { "Voz JARVIS" }.take(160)
        return try {
            val existing = if (!alarmId.isNullOrBlank()) docRef.get().await() else null
            if (existing != null && existing.exists()) {
                val updates = mapOf<String, Any>(
                    "hour" to hour.coerceIn(0, 23),
                    "minute" to minute.coerceIn(0, 59),
                    "label" to cleanLabel,
                    "enabled" to enabled,
                    "daysOfWeekCsv" to daysOfWeekCsv.take(32),
                    "repeatWeekly" to repeatWeekly,
                    "speakJarvisGreeting" to speakJarvisGreeting,
                    "soundTitle" to cleanSoundTitle,
                    "volume" to volume.toDouble().coerceIn(0.0, 1.0),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
            } else {
                val createPayload = mapOf<String, Any>(
                    "userId" to uid,
                    "hour" to hour.coerceIn(0, 23),
                    "minute" to minute.coerceIn(0, 59),
                    "label" to cleanLabel,
                    "enabled" to enabled,
                    "daysOfWeekCsv" to daysOfWeekCsv.take(32),
                    "repeatWeekly" to repeatWeekly,
                    "speakJarvisGreeting" to speakJarvisGreeting,
                    "soundTitle" to cleanSoundTitle,
                    "volume" to volume.toDouble().coerceIn(0.0, 1.0),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(createPayload).await()
            }
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun deleteAlarm(alarmId: String): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("alarms").document(alarmId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path, auth)
            Result.failure(e)
        }
    }

    fun observePlaylists(userId: String): Flow<List<CloudPlaylist>> = flow {
        val path = "users/$userId/playlists"
        val query = db.collection("users").document(userId).collection("playlists")
            .orderBy("createdAt", Query.Direction.DESCENDING)
        emitAll(
            query.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        CloudPlaylist::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path, auth)
                    }
                    throw error
                }
        )
    }

    suspend fun createPlaylist(name: String, playlistId: String? = null): Result<String> {
        val uid = requireUserId()
        val cleanName = name.trim().take(100)
        if (cleanName.isEmpty()) return Result.failure(IllegalArgumentException("Nome da playlist vazio"))
        val colRef = db.collection("users").document(uid).collection("playlists")
        val docRef = if (playlistId.isNullOrBlank()) colRef.document() else colRef.document(playlistId)
        val payload = mapOf<String, Any>(
            "userId" to uid,
            "name" to cleanName,
            "createdAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun deletePlaylist(playlistId: String): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("playlists").document(playlistId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path, auth)
            Result.failure(e)
        }
    }
}
