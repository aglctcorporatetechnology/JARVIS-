package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.jarvisDataStore: DataStore<Preferences> by preferencesDataStore(name = "jarvis_settings")

data class JarvisSettings(
    val wakeWord: String = "JARVIS",
    val languageTag: String = "pt-BR",
    val selectedVoiceName: String = "",
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 0.94f,
    val assistantVolume: Float = 0.9f,
    val importedAudioUri: String = "",
    val importedAudioName: String = "",
    val externalTtsEnabled: Boolean = false,
    val externalTtsEndpoint: String = "",
    val externalTtsApiKey: String = "",
    val externalTtsVoiceId: String = "",
    val geminiModelName: String = "gemini-3.8-flash",
    val weatherApiKey: String = "",
    val mapsTrafficApiKey: String = "",
    val continuousVoiceEnabled: Boolean = false,
    val hudGlowIntensity: Float = 0.85f,
    val globeAnimationEnabled: Boolean = true,
    val defaultSnoozeMinutes: Int = 10,
    val alarmVolume: Float = 0.95f,
    val installDownloadUrl: String = ""
)

class JarvisPreferencesRepository(private val context: Context) {

    private object Keys {
        val WAKE_WORD = stringPreferencesKey("wake_word")
        val LANGUAGE_TAG = stringPreferencesKey("language_tag")
        val SELECTED_VOICE_NAME = stringPreferencesKey("selected_voice_name")
        val SPEECH_RATE = floatPreferencesKey("speech_rate")
        val SPEECH_PITCH = floatPreferencesKey("speech_pitch")
        val ASSISTANT_VOLUME = floatPreferencesKey("assistant_volume")
        val IMPORTED_AUDIO_URI = stringPreferencesKey("imported_audio_uri")
        val IMPORTED_AUDIO_NAME = stringPreferencesKey("imported_audio_name")
        val EXTERNAL_TTS_ENABLED = booleanPreferencesKey("external_tts_enabled")
        val EXTERNAL_TTS_ENDPOINT = stringPreferencesKey("external_tts_endpoint")
        val EXTERNAL_TTS_API_KEY = stringPreferencesKey("external_tts_api_key")
        val EXTERNAL_TTS_VOICE_ID = stringPreferencesKey("external_tts_voice_id")
        val GEMINI_MODEL_NAME = stringPreferencesKey("gemini_model_name")
        val WEATHER_API_KEY = stringPreferencesKey("weather_api_key")
        val MAPS_TRAFFIC_API_KEY = stringPreferencesKey("maps_traffic_api_key")
        val CONTINUOUS_VOICE_ENABLED = booleanPreferencesKey("continuous_voice_enabled")
        val HUD_GLOW_INTENSITY = floatPreferencesKey("hud_glow_intensity")
        val GLOBE_ANIMATION_ENABLED = booleanPreferencesKey("globe_animation_enabled")
        val DEFAULT_SNOOZE_MINUTES = intPreferencesKey("default_snooze_minutes")
        val ALARM_VOLUME = floatPreferencesKey("alarm_volume")
        val INSTALL_DOWNLOAD_URL = stringPreferencesKey("install_download_url")
    }

    val settings: Flow<JarvisSettings> = context.jarvisDataStore.data.map { prefs ->
        JarvisSettings(
            wakeWord = prefs[Keys.WAKE_WORD] ?: "JARVIS",
            languageTag = prefs[Keys.LANGUAGE_TAG] ?: "pt-BR",
            selectedVoiceName = prefs[Keys.SELECTED_VOICE_NAME] ?: "",
            speechRate = prefs[Keys.SPEECH_RATE] ?: 1.0f,
            speechPitch = prefs[Keys.SPEECH_PITCH] ?: 0.94f,
            assistantVolume = prefs[Keys.ASSISTANT_VOLUME] ?: 0.9f,
            importedAudioUri = prefs[Keys.IMPORTED_AUDIO_URI] ?: "",
            importedAudioName = prefs[Keys.IMPORTED_AUDIO_NAME] ?: "",
            externalTtsEnabled = prefs[Keys.EXTERNAL_TTS_ENABLED] ?: false,
            externalTtsEndpoint = prefs[Keys.EXTERNAL_TTS_ENDPOINT] ?: "",
            externalTtsApiKey = prefs[Keys.EXTERNAL_TTS_API_KEY] ?: "",
            externalTtsVoiceId = prefs[Keys.EXTERNAL_TTS_VOICE_ID] ?: "",
            geminiModelName = prefs[Keys.GEMINI_MODEL_NAME] ?: "gemini-3.8-flash",
            weatherApiKey = prefs[Keys.WEATHER_API_KEY] ?: "",
            mapsTrafficApiKey = prefs[Keys.MAPS_TRAFFIC_API_KEY] ?: "",
            continuousVoiceEnabled = prefs[Keys.CONTINUOUS_VOICE_ENABLED] ?: false,
            hudGlowIntensity = prefs[Keys.HUD_GLOW_INTENSITY] ?: 0.85f,
            globeAnimationEnabled = prefs[Keys.GLOBE_ANIMATION_ENABLED] ?: true,
            defaultSnoozeMinutes = prefs[Keys.DEFAULT_SNOOZE_MINUTES] ?: 10,
            alarmVolume = prefs[Keys.ALARM_VOLUME] ?: 0.95f,
            installDownloadUrl = prefs[Keys.INSTALL_DOWNLOAD_URL] ?: ""
        )
    }

    suspend fun updateWakeWord(wakeWord: String) {
        context.jarvisDataStore.edit { it[Keys.WAKE_WORD] = wakeWord.trim().ifBlank { "JARVIS" } }
    }

    suspend fun updateLanguageTag(tag: String) {
        context.jarvisDataStore.edit { it[Keys.LANGUAGE_TAG] = tag }
    }

    suspend fun updateSelectedVoiceName(name: String) {
        context.jarvisDataStore.edit { it[Keys.SELECTED_VOICE_NAME] = name }
    }

    suspend fun updateSpeechRate(rate: Float) {
        context.jarvisDataStore.edit { it[Keys.SPEECH_RATE] = rate.coerceIn(0.5f, 2.0f) }
    }

    suspend fun updateSpeechPitch(pitch: Float) {
        context.jarvisDataStore.edit { it[Keys.SPEECH_PITCH] = pitch.coerceIn(0.5f, 1.5f) }
    }

    suspend fun updateAssistantVolume(volume: Float) {
        context.jarvisDataStore.edit { it[Keys.ASSISTANT_VOLUME] = volume.coerceIn(0f, 1f) }
    }

    suspend fun updateImportedAudio(uri: String, name: String) {
        context.jarvisDataStore.edit {
            it[Keys.IMPORTED_AUDIO_URI] = uri
            it[Keys.IMPORTED_AUDIO_NAME] = name
        }
    }

    suspend fun updateExternalTtsConfig(
        enabled: Boolean,
        endpoint: String,
        apiKey: String,
        voiceId: String
    ) {
        context.jarvisDataStore.edit {
            it[Keys.EXTERNAL_TTS_ENABLED] = enabled
            it[Keys.EXTERNAL_TTS_ENDPOINT] = endpoint.trim()
            it[Keys.EXTERNAL_TTS_API_KEY] = apiKey.trim()
            it[Keys.EXTERNAL_TTS_VOICE_ID] = voiceId.trim()
        }
    }

    suspend fun updateGeminiModel(modelName: String) {
        context.jarvisDataStore.edit { it[Keys.GEMINI_MODEL_NAME] = modelName }
    }

    suspend fun updateApiKeys(weatherApiKey: String, mapsTrafficApiKey: String) {
        context.jarvisDataStore.edit {
            it[Keys.WEATHER_API_KEY] = weatherApiKey.trim()
            it[Keys.MAPS_TRAFFIC_API_KEY] = mapsTrafficApiKey.trim()
        }
    }

    suspend fun updateContinuousVoice(enabled: Boolean) {
        context.jarvisDataStore.edit { it[Keys.CONTINUOUS_VOICE_ENABLED] = enabled }
    }

    suspend fun updateVisualSettings(glowIntensity: Float, globeEnabled: Boolean) {
        context.jarvisDataStore.edit {
            it[Keys.HUD_GLOW_INTENSITY] = glowIntensity.coerceIn(0.2f, 1.0f)
            it[Keys.GLOBE_ANIMATION_ENABLED] = globeEnabled
        }
    }

    suspend fun updateAlarmDefaults(snoozeMinutes: Int, alarmVolume: Float) {
        context.jarvisDataStore.edit {
            it[Keys.DEFAULT_SNOOZE_MINUTES] = snoozeMinutes.coerceIn(1, 30)
            it[Keys.ALARM_VOLUME] = alarmVolume.coerceIn(0f, 1f)
        }
    }

    suspend fun updateInstallDownloadUrl(url: String) {
        context.jarvisDataStore.edit {
            it[Keys.INSTALL_DOWNLOAD_URL] = url.trim()
        }
    }

    suspend fun applyCloudProfile(
        wakeWord: String,
        languageTag: String,
        speechRate: Float,
        speechPitch: Float,
        assistantVolume: Float,
        geminiModelName: String,
        hudGlowIntensity: Float,
        globeAnimationEnabled: Boolean,
        defaultSnoozeMinutes: Int,
        alarmVolume: Float
    ) {
        context.jarvisDataStore.edit {
            it[Keys.WAKE_WORD] = wakeWord.trim().ifBlank { "JARVIS" }
            it[Keys.LANGUAGE_TAG] = languageTag.ifBlank { "pt-BR" }
            it[Keys.SPEECH_RATE] = speechRate.coerceIn(0.5f, 2.0f)
            it[Keys.SPEECH_PITCH] = speechPitch.coerceIn(0.5f, 1.5f)
            it[Keys.ASSISTANT_VOLUME] = assistantVolume.coerceIn(0f, 1f)
            it[Keys.GEMINI_MODEL_NAME] = geminiModelName.ifBlank { "gemini-3.8-flash" }
            it[Keys.HUD_GLOW_INTENSITY] = hudGlowIntensity.coerceIn(0.2f, 1.0f)
            it[Keys.GLOBE_ANIMATION_ENABLED] = globeAnimationEnabled
            it[Keys.DEFAULT_SNOOZE_MINUTES] = defaultSnoozeMinutes.coerceIn(1, 30)
            it[Keys.ALARM_VOLUME] = alarmVolume.coerceIn(0f, 1f)
        }
    }
}
