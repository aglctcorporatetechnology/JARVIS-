package com.example.data.cloud

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class CloudUserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String? = null,
    val email: String? = null,
    val wakeWord: String = "JARVIS",
    val languageTag: String = "pt-BR",
    val speechRate: Double = 1.0,
    val speechPitch: Double = 0.94,
    val assistantVolume: Double = 0.9,
    val geminiModelName: String = "gemini-3.8-flash",
    val hudGlowIntensity: Double = 0.85,
    val globeAnimationEnabled: Boolean = true,
    val defaultSnoozeMinutes: Int = 10,
    val alarmVolume: Double = 0.95,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CloudChatMessage(
    @DocumentId val id: String = "",
    val userId: String = "",
    val sessionId: String = "default",
    val role: String = "user",
    val content: String = "",
    val attachmentName: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CloudAlarm(
    @DocumentId val id: String = "",
    val userId: String = "",
    val hour: Int = 7,
    val minute: Int = 0,
    val label: String = "Alarme JARVIS",
    val enabled: Boolean = true,
    val daysOfWeekCsv: String = "",
    val repeatWeekly: Boolean = true,
    val speakJarvisGreeting: Boolean = true,
    val soundTitle: String = "Toque Padrão + Voz JARVIS",
    val volume: Double = 0.95,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CloudPlaylist(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)
