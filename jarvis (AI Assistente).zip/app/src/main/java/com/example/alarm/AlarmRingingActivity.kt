package com.example.alarm

import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AlarmOff
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.JarvisApplication
import com.example.ui.components.JarvisCircularCore
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.JarvisTheme
import com.example.ui.theme.ObsidianPanel
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextGoldPrimary
import com.example.ui.theme.TextGoldSecondary
import com.example.voice.VoiceEngineState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AlarmRingingActivity : ComponentActivity() {

    private var tts: TextToSpeech? = null
    private var mediaPlayer: MediaPlayer? = null
    private var isSpeakingGreeting by mutableStateOf(true)
    private var snoozeMinutes = 10

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON
        )

        val alarmId = intent.getLongExtra(AlarmReceiver.EXTRA_ALARM_ID, -1L)
        val label = intent.getStringExtra(AlarmReceiver.EXTRA_ALARM_LABEL) ?: "Despertador JARVIS"
        val speakGreeting = intent.getBooleanExtra(AlarmReceiver.EXTRA_SPEAK_GREETING, true)
        val soundUri = intent.getStringExtra(AlarmReceiver.EXTRA_SOUND_URI) ?: ""
        val volume = intent.getFloatExtra(AlarmReceiver.EXTRA_VOLUME, 0.95f)
        val currentTimeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

        val app = application as JarvisApplication
        CoroutineScope(Dispatchers.Main).launch {
            val settings = app.container.preferences.settings.first()
            snoozeMinutes = settings.defaultSnoozeMinutes
            if (speakGreeting) {
                startJarvisGreetingThenMusic(settings.languageTag, settings.selectedVoiceName, settings.speechRate, settings.speechPitch, soundUri, volume)
            } else {
                isSpeakingGreeting = false
                startAlarmMusic(soundUri, volume)
            }
        }

        setContent {
            JarvisTheme {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(ObsidianPanel, PitchBlack)
                            )
                        )
                        .safeDrawingPadding()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        Text(
                            text = "PROTOCOLO DESPERTAR",
                            style = MaterialTheme.typography.labelLarge,
                            color = JarvisGold
                        )
                        Text(
                            text = currentTimeStr,
                            style = MaterialTheme.typography.displayLarge,
                            color = JarvisGoldBright
                        )
                        JarvisCircularCore(
                            state = if (isSpeakingGreeting) VoiceEngineState.SPEAKING else VoiceEngineState.ACTIVE_LISTENING,
                            rmsLevel = 0.65f,
                            glowIntensity = 1f,
                            onClick = {},
                            modifier = Modifier.size(210.dp)
                        )
                        Text(
                            text = label,
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextGoldPrimary,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Bom dia, senhor. Está na hora de acordar.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = TextGoldSecondary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    stopAudio()
                                    AlarmScheduler(this@AlarmRingingActivity).scheduleSnooze(
                                        alarmId, label, speakGreeting, soundUri, volume, snoozeMinutes
                                    )
                                    clearAlarmNotification(alarmId)
                                    finish()
                                },
                                border = BorderStroke(1.dp, JarvisGold),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(56.dp)
                                    .testTag("alarm_snooze_button")
                            ) {
                                Icon(Icons.Default.Snooze, contentDescription = "Soneca", tint = JarvisGold)
                                Text("  Soneca ${snoozeMinutes}m", color = JarvisGold)
                            }
                            Button(
                                onClick = {
                                    stopAudio()
                                    clearAlarmNotification(alarmId)
                                    finish()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = JarvisGold, contentColor = PitchBlack),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(56.dp)
                                    .testTag("alarm_dismiss_button")
                            ) {
                                Icon(Icons.Default.AlarmOff, contentDescription = "Desligar")
                                Text("  Desligar")
                            }
                        }
                    }
                }
            }
        }
    }

    private fun startJarvisGreetingThenMusic(
        languageTag: String,
        voiceName: String,
        rate: Float,
        pitch: Float,
        soundUri: String,
        volume: Float
    ) {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts ?: return@TextToSpeech
                engine.language = Locale.forLanguageTag(languageTag)
                engine.setSpeechRate(rate)
                engine.setPitch(pitch)
                if (voiceName.isNotBlank()) {
                    runCatching { engine.voices?.firstOrNull { it.name == voiceName } }
                        .getOrNull()?.let { engine.voice = it }
                }
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        runOnUiThread {
                            isSpeakingGreeting = false
                            startAlarmMusic(soundUri, volume)
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        runOnUiThread {
                            isSpeakingGreeting = false
                            startAlarmMusic(soundUri, volume)
                        }
                    }
                })
                val params = Bundle().apply {
                    putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.coerceIn(0.2f, 1f))
                }
                engine.speak(
                    "Bom dia, senhor. Está na hora de acordar.",
                    TextToSpeech.QUEUE_FLUSH,
                    params,
                    "jarvis_alarm_wake"
                )
            } else {
                isSpeakingGreeting = false
                startAlarmMusic(soundUri, volume)
            }
        }
    }

    private fun startAlarmMusic(soundUriString: String, volume: Float) {
        runCatching {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, (max * volume).toInt().coerceAtLeast(1), 0)

            val uri = if (soundUriString.isNotBlank()) {
                Uri.parse(soundUriString)
            } else {
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            }

            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(this@AlarmRingingActivity, uri)
                isLooping = true
                setVolume(volume, volume)
                prepare()
                start()
            }
        }.onFailure {
            // Fallback to default alarm ringtone if custom URI is no longer readable
            if (soundUriString.isNotBlank()) {
                startAlarmMusic("", volume)
            }
        }
    }

    private fun clearAlarmNotification(alarmId: Long) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(5200 + alarmId.toInt())
    }

    private fun stopAudio() {
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        tts = null
        runCatching {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        }
        mediaPlayer = null
    }

    override fun onDestroy() {
        stopAudio()
        super.onDestroy()
    }
}
