package com.example.alarm

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.example.JarvisApplication
import com.example.R
import com.example.data.local.JarvisDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_ALARM_ID = "extra_alarm_id"
        const val EXTRA_ALARM_LABEL = "extra_alarm_label"
        const val EXTRA_SPEAK_GREETING = "extra_speak_greeting"
        const val EXTRA_SOUND_URI = "extra_sound_uri"
        const val EXTRA_VOLUME = "extra_volume"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val alarmId = intent.getLongExtra(EXTRA_ALARM_ID, -1L)
        val label = intent.getStringExtra(EXTRA_ALARM_LABEL) ?: "Despertador JARVIS"
        val speakGreeting = intent.getBooleanExtra(EXTRA_SPEAK_GREETING, true)
        val soundUri = intent.getStringExtra(EXTRA_SOUND_URI) ?: ""
        val volume = intent.getFloatExtra(EXTRA_VOLUME, 0.95f)

        val ringIntent = Intent(context, AlarmRingingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_ALARM_ID, alarmId)
            putExtra(EXTRA_ALARM_LABEL, label)
            putExtra(EXTRA_SPEAK_GREETING, speakGreeting)
            putExtra(EXTRA_SOUND_URI, soundUri)
            putExtra(EXTRA_VOLUME, volume)
        }

        val fullScreenPending = PendingIntent.getActivity(
            context,
            alarmId.toInt(),
            ringIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(context, JarvisApplication.CHANNEL_ALARM)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("JARVIS — Despertador")
            .setContentText("Bom dia, senhor. Está na hora de acordar.")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setFullScreenIntent(fullScreenPending, true)
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(5200 + alarmId.toInt(), notif)

        runCatching { context.startActivity(ringIntent) }

        if (alarmId > 0) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val dao = JarvisDatabase.getInstance(context).alarmDao()
                    val alarm = dao.getAlarmById(alarmId)
                    if (alarm != null) {
                        if (alarm.repeatWeekly || alarm.daysOfWeekCsv.isNotBlank()) {
                            AlarmScheduler(context).scheduleAlarm(alarm)
                        } else {
                            dao.updateAlarm(alarm.copy(enabled = false))
                        }
                    }
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
