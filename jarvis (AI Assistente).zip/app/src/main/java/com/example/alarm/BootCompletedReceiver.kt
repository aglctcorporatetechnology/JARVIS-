package com.example.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.JarvisDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val alarms = JarvisDatabase.getInstance(context).alarmDao().getEnabledAlarms()
                val scheduler = AlarmScheduler(context)
                alarms.forEach { scheduler.scheduleAlarm(it) }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
