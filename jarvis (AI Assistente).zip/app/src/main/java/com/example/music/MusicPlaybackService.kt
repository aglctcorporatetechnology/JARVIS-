package com.example.music

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.JarvisApplication
import com.example.MainActivity
import com.example.R

class MusicPlaybackService : Service() {

    companion object {
        private const val ACTION_PLAY_PAUSE = "com.example.music.PLAY_PAUSE"
        private const val ACTION_NEXT = "com.example.music.NEXT"
        private const val ACTION_STOP = "com.example.music.STOP"
        private const val EXTRA_TITLE = "extra_title"
        private const val EXTRA_PLAYING = "extra_playing"
        private const val NOTIFICATION_ID = 4202

        fun startOrUpdate(context: Context, title: String, isPlaying: Boolean) {
            val intent = Intent(context, MusicPlaybackService::class.java).apply {
                putExtra(EXTRA_TITLE, title)
                putExtra(EXTRA_PLAYING, isPlaying)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val controller = (application as JarvisApplication).container.musicController
        when (intent?.action) {
            ACTION_PLAY_PAUSE -> controller.togglePlayPause()
            ACTION_NEXT -> controller.nextTrack()
            ACTION_STOP -> {
                controller.pause()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }

        val title = intent?.getStringExtra(EXTRA_TITLE)
            ?: controller.state.value.currentTrack?.title
            ?: "Reprodutor JARVIS"
        val playing = intent?.getBooleanExtra(EXTRA_PLAYING, controller.state.value.isPlaying)
            ?: controller.state.value.isPlaying

        val notif = buildNotification(title, playing)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notif,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(NOTIFICATION_ID, notif)
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(title: String, isPlaying: Boolean): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val toggleIntent = PendingIntent.getService(
            this, 1, Intent(this, MusicPlaybackService::class.java).setAction(ACTION_PLAY_PAUSE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val nextIntent = PendingIntent.getService(
            this, 2, Intent(this, MusicPlaybackService::class.java).setAction(ACTION_NEXT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 3, Intent(this, MusicPlaybackService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, JarvisApplication.CHANNEL_MUSIC)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("JARVIS Áudio")
            .setContentText(title)
            .setOngoing(isPlaying)
            .setContentIntent(openIntent)
            .addAction(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (isPlaying) "Pausar" else "Tocar",
                toggleIntent
            )
            .addAction(android.R.drawable.ic_media_next, "Próxima", nextIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Fechar", stopIntent)
            .build()
    }
}
