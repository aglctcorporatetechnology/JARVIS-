package com.example.music

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import com.example.data.local.MusicTrackEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class PlaybackUiState(
    val currentTrack: MusicTrackEntity? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val volume: Float = 0.85f,
    val shuffleEnabled: Boolean = false,
    val repeatEnabled: Boolean = false,
    val errorMessage: String? = null
)

class MusicPlayerController(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null

    private var queue: List<MusicTrackEntity> = emptyList()
    private var currentIndex: Int = -1

    private val _state = MutableStateFlow(PlaybackUiState())
    val state: StateFlow<PlaybackUiState> = _state.asStateFlow()

    fun updateQueue(tracks: List<MusicTrackEntity>) {
        queue = tracks
        val cur = _state.value.currentTrack
        if (cur != null) {
            currentIndex = queue.indexOfFirst { it.id == cur.id }
        }
    }

    fun extractTrackMetadata(uri: Uri): MusicTrackEntity {
        val retriever = MediaMetadataRetriever()
        var title = queryDisplayName(uri) ?: "Faixa de Áudio"
        var artist = "Artista Desconhecido"
        var duration = 0L

        runCatching {
            retriever.setDataSource(context, uri)
            val metaTitle = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            val metaArtist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
            val metaDur = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            if (!metaTitle.isNullOrBlank()) title = metaTitle
            if (!metaArtist.isNullOrBlank()) artist = metaArtist
            duration = metaDur?.toLongOrNull() ?: 0L
        }.also {
            runCatching { retriever.release() }
        }

        return MusicTrackEntity(
            uriString = uri.toString(),
            title = title,
            artist = artist,
            durationMs = duration
        )
    }

    private fun queryDisplayName(uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        cursor.getString(0)?.substringBeforeLast(".")
                    } else null
                }
        }.getOrNull()
    }

    fun playTrack(track: MusicTrackEntity, tracksList: List<MusicTrackEntity> = queue) {
        if (tracksList.isNotEmpty()) queue = tracksList
        currentIndex = queue.indexOfFirst { it.id == track.id }
        startMediaPlayer(track)
    }

    fun playFirstOrResume() {
        val cur = _state.value.currentTrack
        if (cur != null) {
            if (!_state.value.isPlaying) togglePlayPause()
        } else if (queue.isNotEmpty()) {
            playTrack(queue.first(), queue)
        }
    }

    private fun startMediaPlayer(track: MusicTrackEntity) {
        releasePlayerOnly()
        try {
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(context, Uri.parse(track.uriString))
                val v = _state.value.volume
                setVolume(v, v)
                setOnPreparedListener { mp ->
                    mp.start()
                    _state.value = _state.value.copy(
                        currentTrack = track,
                        isPlaying = true,
                        durationMs = mp.duration.toLong().coerceAtLeast(track.durationMs),
                        positionMs = 0L,
                        errorMessage = null
                    )
                    MusicPlaybackService.startOrUpdate(context, track.title, true)
                    startProgressTicker()
                }
                setOnCompletionListener {
                    if (_state.value.repeatEnabled) {
                        startMediaPlayer(track)
                    } else {
                        nextTrack()
                    }
                }
                setOnErrorListener { _, what, extra ->
                    Log.e("MusicController", "MediaPlayer error $what/$extra")
                    _state.value = _state.value.copy(
                        isPlaying = false,
                        errorMessage = "Não foi possível reproduzir '${track.title}'."
                    )
                    true
                }
                prepareAsync()
            }
            mediaPlayer = player
        } catch (e: Exception) {
            Log.e("MusicController", "Failed to play track", e)
            _state.value = _state.value.copy(
                isPlaying = false,
                errorMessage = e.localizedMessage ?: "Erro ao abrir arquivo de áudio."
            )
        }
    }

    fun togglePlayPause() {
        val player = mediaPlayer
        if (player == null) {
            if (queue.isNotEmpty()) playTrack(queue.first(), queue)
            return
        }
        runCatching {
            if (player.isPlaying) {
                player.pause()
                _state.value = _state.value.copy(isPlaying = false)
                _state.value.currentTrack?.let {
                    MusicPlaybackService.startOrUpdate(context, it.title, false)
                }
            } else {
                player.start()
                _state.value = _state.value.copy(isPlaying = true)
                _state.value.currentTrack?.let {
                    MusicPlaybackService.startOrUpdate(context, it.title, true)
                }
                startProgressTicker()
            }
        }
    }

    fun pause() {
        runCatching {
            if (mediaPlayer?.isPlaying == true) {
                mediaPlayer?.pause()
                _state.value = _state.value.copy(isPlaying = false)
            }
        }
    }

    fun nextTrack() {
        if (queue.isEmpty()) return
        val nextIdx = if (_state.value.shuffleEnabled && queue.size > 1) {
            queue.indices.filter { it != currentIndex }.random()
        } else {
            (currentIndex + 1) % queue.size
        }
        playTrack(queue[nextIdx], queue)
    }

    fun previousTrack() {
        if (queue.isEmpty()) return
        val prevIdx = if (currentIndex - 1 < 0) queue.lastIndex else currentIndex - 1
        playTrack(queue[prevIdx], queue)
    }

    fun seekTo(positionMs: Long) {
        runCatching {
            mediaPlayer?.seekTo(positionMs.toInt())
            _state.value = _state.value.copy(positionMs = positionMs)
        }
    }

    fun setVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        _state.value = _state.value.copy(volume = clamped)
        runCatching {
            mediaPlayer?.setVolume(clamped, clamped)
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * clamped).toInt(), 0)
        }
    }

    fun toggleShuffle() {
        _state.value = _state.value.copy(shuffleEnabled = !_state.value.shuffleEnabled)
    }

    fun toggleRepeat() {
        _state.value = _state.value.copy(repeatEnabled = !_state.value.repeatEnabled)
    }

    fun openExternalMusicApp(packageName: String): Boolean {
        return runCatching {
            val launch = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                true
            } else {
                false
            }
        }.getOrDefault(false)
    }

    private fun startProgressTicker() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (_state.value.isPlaying) {
                val pos = runCatching { mediaPlayer?.currentPosition?.toLong() }.getOrNull() ?: break
                _state.value = _state.value.copy(positionMs = pos)
                delay(400L)
            }
        }
    }

    private fun releasePlayerOnly() {
        progressJob?.cancel()
        runCatching {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        }
        mediaPlayer = null
    }

    fun release() {
        releasePlayerOnly()
    }
}
