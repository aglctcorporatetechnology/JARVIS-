package com.example.maps

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

@JsonClass(generateAdapter = true)
data class NominatimPlaceDto(
    @Json(name = "display_name") val displayName: String,
    val lat: String,
    val lon: String,
    val type: String? = null,
    @Json(name = "class") val placeClass: String? = null
)

interface NominatimApi {
    @Headers("User-Agent: JARVIS-Android-Assistant/1.0")
    @GET("search")
    suspend fun searchPlaces(
        @Query("q") query: String,
        @Query("format") format: String = "jsonv2",
        @Query("limit") limit: Int = 6,
        @Query("accept-language") acceptLanguage: String = "pt-BR"
    ): List<NominatimPlaceDto>
}

@JsonClass(generateAdapter = true)
data class OsrmRouteResponse(
    val code: String,
    val routes: List<OsrmRouteDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class OsrmRouteDto(
    val distance: Double,
    val duration: Double,
    val geometry: OsrmGeometryDto? = null,
    val legs: List<OsrmLegDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class OsrmGeometryDto(
    val coordinates: List<List<Double>> = emptyList()
)

@JsonClass(generateAdapter = true)
data class OsrmLegDto(
    val summary: String? = null,
    val steps: List<OsrmStepDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class OsrmStepDto(
    val name: String? = null,
    val ref: String? = null,
    val distance: Double = 0.0,
    val duration: Double = 0.0
)

interface OsrmRoutingApi {
    @GET("route/v1/driving/{coordinates}")
    suspend fun getDrivingRoutes(
        @Path("coordinates", encoded = true) coordinates: String,
        @Query("alternatives") alternatives: Boolean = true,
        @Query("overview") overview: String = "simplified",
        @Query("geometries") geometries: String = "geojson",
        @Query("steps") steps: Boolean = true
    ): OsrmRouteResponse
}

interface GoogleRoutesApi {
    @POST("directions/v2:computeRoutes")
    suspend fun computeTrafficRoute(
        @Header("X-Goog-Api-Key") apiKey: String,
        @Header("X-Goog-FieldMask") fieldMask: String = "routes.duration,routes.distanceMeters,routes.travelAdvisory.speedReadingIntervals",
        @Body body: RequestBody
    ): ResponseBody
}
