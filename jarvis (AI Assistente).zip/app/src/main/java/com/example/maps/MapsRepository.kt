package com.example.maps

import android.util.Log
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.Locale

data class GeoPoint(
    val latitude: Double,
    val longitude: Double,
    val label: String = ""
)

data class RouteOption(
    val index: Int,
    val summary: String,
    val distanceKm: Double,
    val durationMinutes: Int,
    val highwayNames: List<String>,
    val coordinates: List<GeoPoint>,
    val trafficStatus: String,
    val hasLiveTrafficData: Boolean
)

data class PlaceSearchResult(
    val displayName: String,
    val latitude: Double,
    val longitude: Double,
    val category: String
)

class MapsRepository {

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val httpClient = OkHttpClient.Builder().build()

    private val nominatimApi: NominatimApi = Retrofit.Builder()
        .baseUrl("https://nominatim.openstreetmap.org/")
        .client(httpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(NominatimApi::class.java)

    private val osrmApi: OsrmRoutingApi = Retrofit.Builder()
        .baseUrl("https://router.project-osrm.org/")
        .client(httpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(OsrmRoutingApi::class.java)

    private val googleRoutesApi: GoogleRoutesApi = Retrofit.Builder()
        .baseUrl("https://routes.googleapis.com/")
        .client(httpClient)
        .build()
        .create(GoogleRoutesApi::class.java)

    suspend fun searchPlaces(query: String): List<PlaceSearchResult> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        nominatimApi.searchPlaces(query.trim()).mapNotNull { dto ->
            val lat = dto.lat.toDoubleOrNull() ?: return@mapNotNull null
            val lon = dto.lon.toDoubleOrNull() ?: return@mapNotNull null
            PlaceSearchResult(
                displayName = dto.displayName,
                latitude = lat,
                longitude = lon,
                category = dto.type ?: dto.placeClass ?: "local"
            )
        }
    }

    suspend fun calculateRoutes(
        origin: GeoPoint,
        destination: GeoPoint,
        googleTrafficApiKey: String = ""
    ): List<RouteOption> = withContext(Dispatchers.IO) {
        val coordPath = String.format(
            Locale.US,
            "%.6f,%.6f;%.6f,%.6f",
            origin.longitude,
            origin.latitude,
            destination.longitude,
            destination.latitude
        )
        val osrm = osrmApi.getDrivingRoutes(coordinates = coordPath)
        if (osrm.code != "Ok" || osrm.routes.isEmpty()) {
            throw IllegalStateException("Não foi possível traçar a rota entre os pontos selecionados.")
        }

        var liveTrafficDurationMin: Int? = null
        var liveTrafficStatus: String? = null

        if (googleTrafficApiKey.isNotBlank()) {
            runCatching {
                val payload = JSONObject().apply {
                    put("origin", JSONObject().put("location", JSONObject().put("latLng", JSONObject().apply {
                        put("latitude", origin.latitude)
                        put("longitude", origin.longitude)
                    })))
                    put("destination", JSONObject().put("location", JSONObject().put("latLng", JSONObject().apply {
                        put("latitude", destination.latitude)
                        put("longitude", destination.longitude)
                    })))
                    put("travelMode", "DRIVE")
                    put("routingPreference", "TRAFFIC_AWARE")
                    put("extraComputations", org.json.JSONArray().put("TRAFFIC_ON_POLYLINE"))
                }
                val body = payload.toString().toRequestBody("application/json".toMediaType())
                val rawResp = googleRoutesApi.computeTrafficRoute(googleTrafficApiKey, body = body).string()
                val json = JSONObject(rawResp)
                val firstRoute = json.optJSONArray("routes")?.optJSONObject(0)
                if (firstRoute != null) {
                    val durStr = firstRoute.optString("duration", "")
                    val seconds = durStr.removeSuffix("s").toIntOrNull()
                    if (seconds != null) {
                        liveTrafficDurationMin = (seconds / 60).coerceAtLeast(1)
                    }
                    val intervals = firstRoute.optJSONObject("travelAdvisory")
                        ?.optJSONArray("speedReadingIntervals")
                    var jamCount = 0
                    var slowCount = 0
                    if (intervals != null) {
                        for (i in 0 until intervals.length()) {
                            when (intervals.optJSONObject(i)?.optString("speed")) {
                                "TRAFFIC_JAM" -> jamCount++
                                "SLOW" -> slowCount++
                            }
                        }
                    }
                    liveTrafficStatus = when {
                        jamCount > 0 -> "Congestionamento intenso detectado ($jamCount trechos críticos)"
                        slowCount > 0 -> "Trânsito moderado com lentidão em $slowCount trechos"
                        else -> "Fluxo livre em tempo real (Google Traffic)"
                    }
                }
            }.onFailure {
                Log.w("MapsRepo", "Google Routes traffic lookup failed: ${it.message}")
            }
        }

        osrm.routes.mapIndexed { idx, dto ->
            val highways = dto.legs.flatMap { leg ->
                leg.steps.mapNotNull { step ->
                    val ref = step.ref?.trim().orEmpty()
                    val name = step.name?.trim().orEmpty()
                    when {
                        ref.isNotBlank() -> "$ref${if (name.isNotBlank()) " ($name)" else ""}"
                        name.contains("Rodovia", ignoreCase = true) ||
                            name.contains("BR-", ignoreCase = true) ||
                            name.contains("SP-", ignoreCase = true) ||
                            name.contains("Marginal", ignoreCase = true) -> name
                        else -> null
                    }
                }
            }.distinct().take(6)

            val points = dto.geometry?.coordinates.orEmpty().mapNotNull { pair ->
                if (pair.size >= 2) GeoPoint(latitude = pair[1], longitude = pair[0]) else null
            }

            val baseDurationMin = (dto.duration / 60.0).toInt().coerceAtLeast(1)
            val useLive = idx == 0 && liveTrafficDurationMin != null

            RouteOption(
                index = idx,
                summary = dto.legs.firstOrNull()?.summary?.takeIf { it.isNotBlank() }
                    ?: if (idx == 0) "Rota Principal" else "Rota Alternativa ${idx}",
                distanceKm = dto.distance / 1000.0,
                durationMinutes = if (useLive) liveTrafficDurationMin!! else baseDurationMin,
                highwayNames = highways,
                coordinates = points,
                trafficStatus = if (idx == 0 && liveTrafficStatus != null) {
                    liveTrafficStatus!!
                } else {
                    "Trânsito em tempo real requer chave Google Routes API nas Configurações (rota base OSRM ativa)"
                },
                hasLiveTrafficData = idx == 0 && liveTrafficStatus != null
            )
        }
    }
}
