package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.preferences.JarvisSettings
import com.example.ui.components.HudPanelCard
import com.example.ui.components.HudScreenTopBar
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.HoloEmerald
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextGoldPrimary
import com.example.ui.theme.TextGoldSecondary
import com.example.voice.JarvisVoiceOption
import com.example.voice.VoiceGenderTag
import kotlin.math.roundToInt

@Composable
fun JarvisVoiceScreen(
    settings: JarvisSettings,
    availableVoices: List<JarvisVoiceOption>,
    voiceStatusMessage: String,
    onBack: () -> Unit,
    onUpdateWakeWord: (String) -> Unit,
    onToggleContinuousVoice: (Boolean) -> Unit,
    onUpdateLanguage: (String) -> Unit,
    onSelectVoice: (String) -> Unit,
    onUpdateRate: (Float) -> Unit,
    onUpdatePitch: (Float) -> Unit,
    onUpdateVolume: (Float) -> Unit,
    onTestSample: () -> Unit,
    onImportAudio: (String, String) -> Unit,
    onPlayImportedAudio: (String) -> Unit,
    onSaveExternalTts: (Boolean, String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var wakeWordInput by remember(settings.wakeWord) { mutableStateOf(settings.wakeWord) }
    var genderFilter by remember { mutableStateOf<VoiceGenderTag?>(null) }
    var extEnabled by remember(settings.externalTtsEnabled) { mutableStateOf(settings.externalTtsEnabled) }
    var extEndpoint by remember(settings.externalTtsEndpoint) { mutableStateOf(settings.externalTtsEndpoint) }
    var extApiKey by remember(settings.externalTtsApiKey) { mutableStateOf(settings.externalTtsApiKey) }
    var extVoiceId by remember(settings.externalTtsVoiceId) { mutableStateOf(settings.externalTtsVoiceId) }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants[Manifest.permission.RECORD_AUDIO] == true) {
            onToggleContinuousVoice(true)
        }
    }

    val audioImporter = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            val name = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "Áudio importado"
            onImportAudio(uri.toString(), name)
        }
    }

    val filteredVoices = remember(availableVoices, genderFilter) {
        if (genderFilter == null) availableVoices
        else availableVoices.filter { it.genderTag == genderFilter }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PitchBlack)
    ) {
        HudScreenTopBar(
            title = "Voz do JARVIS",
            subtitle = voiceStatusMessage,
            onBack = onBack
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Wake word & continuous listening
            item {
                HudPanelCard {
                    Text("ATIVAÇÃO POR VOZ & ESCUTA CONTÍNUA", style = MaterialTheme.typography.labelLarge, color = JarvisGoldBright)
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = wakeWordInput,
                            onValueChange = { wakeWordInput = it },
                            label = { Text("Palavra de ativação") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = JarvisGoldBright,
                                unfocusedBorderColor = JarvisGoldBorder,
                                focusedTextColor = TextGoldPrimary,
                                unfocusedTextColor = TextGoldPrimary
                            ),
                            modifier = Modifier.weight(1f).testTag("wake_word_input")
                        )
                        Button(
                            onClick = { onUpdateWakeWord(wakeWordInput) },
                            colors = ButtonDefaults.buttonColors(containerColor = JarvisGold, contentColor = PitchBlack),
                            modifier = Modifier.testTag("save_wake_word_button")
                        ) {
                            Text("Salvar")
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Conversação sem tocar na tela", style = MaterialTheme.typography.titleMedium, color = TextGoldPrimary)
                            Text(
                                "Serviço em primeiro plano (microfone). Ao ouvir '${settings.wakeWord}', responde: \"Olá, senhor. Como posso ajudá-lo?\"",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextGoldSecondary
                            )
                        }
                        Switch(
                            checked = settings.continuousVoiceEnabled,
                            onCheckedChange = { enable ->
                                if (enable) {
                                    val hasMic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                                    val hasNotif = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                                        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
                                    if (hasMic && hasNotif) {
                                        onToggleContinuousVoice(true)
                                    } else {
                                        val perms = buildList {
                                            add(Manifest.permission.RECORD_AUDIO)
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                                add(Manifest.permission.POST_NOTIFICATIONS)
                                            }
                                        }.toTypedArray()
                                        micPermissionLauncher.launch(perms)
                                    }
                                } else {
                                    onToggleContinuousVoice(false)
                                }
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = PitchBlack, checkedTrackColor = JarvisGold),
                            modifier = Modifier.testTag("continuous_voice_switch")
                        )
                    }
                }
            }

            // Language & Acoustics
            item {
                HudPanelCard {
                    Text("IDIOMA, VELOCIDADE, TONALIDADE & VOLUME", style = MaterialTheme.typography.labelLarge, color = JarvisGoldBright)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("pt-BR" to "Português (BR)", "en-US" to "English", "es-ES" to "Español").forEach { (tag, label) ->
                            FilterChip(
                                selected = settings.languageTag == tag,
                                onClick = { onUpdateLanguage(tag) },
                                label = { Text(label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = JarvisGold,
                                    selectedLabelColor = PitchBlack
                                )
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Text("Velocidade da fala: ${String.format("%.2fx", settings.speechRate)}", style = MaterialTheme.typography.bodyMedium, color = TextGoldPrimary)
                    Slider(
                        value = settings.speechRate,
                        onValueChange = onUpdateRate,
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(thumbColor = JarvisGoldBright, activeTrackColor = JarvisGold)
                    )

                    Text("Tonalidade (Pitch): ${String.format("%.2f", settings.speechPitch)}", style = MaterialTheme.typography.bodyMedium, color = TextGoldPrimary)
                    Slider(
                        value = settings.speechPitch,
                        onValueChange = onUpdatePitch,
                        valueRange = 0.5f..1.5f,
                        colors = SliderDefaults.colors(thumbColor = JarvisGoldBright, activeTrackColor = JarvisGold)
                    )

                    Text("Volume do assistente: ${(settings.assistantVolume * 100).roundToInt()}%", style = MaterialTheme.typography.bodyMedium, color = TextGoldPrimary)
                    Slider(
                        value = settings.assistantVolume,
                        onValueChange = onUpdateVolume,
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = JarvisGoldBright, activeTrackColor = JarvisGold)
                    )

                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = onTestSample,
                        colors = ButtonDefaults.buttonColors(containerColor = JarvisGold, contentColor = PitchBlack),
                        modifier = Modifier.fillMaxWidth().testTag("test_voice_sample_button")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Ouvir Amostra da Voz")
                    }
                }
            }

            // Imported Audio & External TTS
            item {
                HudPanelCard {
                    Text("ÁUDIO PERSONALIZADO & PROVEDOR TTS EXTERNO", style = MaterialTheme.typography.labelLarge, color = JarvisGoldBright)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Importe arquivos de áudio compatíveis para toques/efeitos ou configure um provedor externo autorizado (nunca utilize clonagem de voz sem autorização).",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextGoldSecondary
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { audioImporter.launch(arrayOf("audio/*")) },
                            border = BorderStroke(1.dp, JarvisGoldBorder),
                            modifier = Modifier.weight(1f).testTag("import_voice_audio_button")
                        ) {
                            Icon(Icons.Default.AudioFile, contentDescription = null, tint = JarvisGoldBright)
                            Spacer(Modifier.width(6.dp))
                            Text("Importar Áudio", color = JarvisGoldBright)
                        }
                        if (settings.importedAudioUri.isNotBlank()) {
                            OutlinedButton(
                                onClick = { onPlayImportedAudio(settings.importedAudioUri) },
                                border = BorderStroke(1.dp, HoloCyan),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Tocar: ${settings.importedAudioName}", color = HoloCyan, maxLines = 1)
                            }
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Ativar Provedor TTS Externo", style = MaterialTheme.typography.titleMedium, color = TextGoldPrimary)
                        Switch(
                            checked = extEnabled,
                            onCheckedChange = { extEnabled = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = PitchBlack, checkedTrackColor = JarvisGold)
                        )
                    }
                    if (extEnabled) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = extEndpoint,
                            onValueChange = { extEndpoint = it },
                            label = { Text("Endpoint HTTP (ex: https://api.elevenlabs.io/v1/text-to-speech/{id})") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = extApiKey,
                            onValueChange = { extApiKey = it },
                            label = { Text("Chave de API do Provedor TTS") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = extVoiceId,
                            onValueChange = { extVoiceId = it },
                            label = { Text("Voice ID / Voz Personalizada") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { onSaveExternalTts(extEnabled, extEndpoint, extApiKey, extVoiceId) },
                        border = BorderStroke(1.dp, JarvisGold),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Salvar Configuração de TTS Externo", color = JarvisGoldBright)
                    }
                }
            }

            // Local System Voices List
            item {
                Text("VOZES DISPONÍVEIS NO DISPOSITIVO", style = MaterialTheme.typography.labelLarge, color = JarvisGold)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = genderFilter == null,
                        onClick = { genderFilter = null },
                        label = { Text("Todas (${availableVoices.size})") }
                    )
                    FilterChip(
                        selected = genderFilter == VoiceGenderTag.MASCULINE,
                        onClick = { genderFilter = VoiceGenderTag.MASCULINE },
                        label = { Text("Masculinas") }
                    )
                    FilterChip(
                        selected = genderFilter == VoiceGenderTag.FEMININE,
                        onClick = { genderFilter = VoiceGenderTag.FEMININE },
                        label = { Text("Femininas") }
                    )
                }
            }

            items(filteredVoices, key = { it.name }) { voice ->
                val selected = settings.selectedVoiceName == voice.name
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ObsidianCard, RoundedCornerShape(12.dp))
                        .clickable { onSelectVoice(voice.name) }
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = if (selected) JarvisGoldBright else TextGoldSecondary)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(voice.displayName, style = MaterialTheme.typography.titleMedium, color = TextGoldPrimary)
                            Text(
                                "${voice.genderTag.name} • ${if (voice.requiresNetwork) "Rede" else "Offline"}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextGoldSecondary
                            )
                        }
                    }
                    if (selected) {
                        Icon(Icons.Default.CheckCircle, contentDescription = "Selecionada", tint = HoloEmerald)
                    }
                }
            }
        }
    }
}
