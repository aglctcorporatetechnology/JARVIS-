package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Obsidian & Pitch Black Surfaces
val PitchBlack = Color(0xFF030407)
val ObsidianVoid = Color(0xFF070A10)
val ObsidianPanel = Color(0xFF0D121C)
val ObsidianCard = Color(0xFF131A27)
val ObsidianElevated = Color(0xFF1A2233)

// Holographic Metallic Gold Palette
val JarvisGoldBright = Color(0xFFFFD86B)
val JarvisGold = Color(0xFFFFB81C)
val JarvisAmber = Color(0xFFE58E00)
val JarvisGoldDim = Color(0xFF9C6D14)
val JarvisGoldSubtle = Color(0x33FFB81C)
val JarvisGoldBorder = Color(0x66FFB81C)

// Text Colors
val TextGoldPrimary = Color(0xFFF6E7C1)
val TextGoldSecondary = Color(0xFFB5A27A)
val TextMuted = Color(0xFF7D7463)

// Tactical Telemetry Accents
val HoloCyan = Color(0xFF38E8FF)
val HoloEmerald = Color(0xFF2CE69B)
val HoloCrimson = Color(0xFFFF4D6D)
val HoloWarning = Color(0xFFFF9F1C)
