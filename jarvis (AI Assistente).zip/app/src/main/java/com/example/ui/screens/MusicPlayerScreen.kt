package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.MusicTrackEntity
import com.example.data.local.PlaylistWithTracks
import com.example.music.PlaybackUiState
import com.example.ui.components.HudPanelCard
import com.example.ui.components.HudScreenTopBar
import com.example.ui.theme.HoloCrimson
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianPanel
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextGoldPrimary
import com.example.ui.theme.TextGoldSecondary
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun MusicPlayerScreen(
    playbackState: PlaybackUiState,
    tracks: List<MusicTrackEntity>,
    playlists: List<PlaylistWithTracks>,
    onBack: () -> Unit,
    onImportTracks: (List<Uri>) -> Unit,
    onPlayTrack: (MusicTrackEntity, List<MusicTrackEntity>) -> Unit,
    onTogglePlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onVolumeChange: (Float) -> Unit,
    onToggleShuffle: () -> Unit,
    onToggleRepeat: () -> Unit,
    onDeleteTrack: (MusicTrackEntity) -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onAddTrackToPlaylist: (Long, Long) -> Unit,
    onDeletePlaylist: (Long) -> Unit,
    onSetAsAlarm: (MusicTrackEntity) -> Unit,
    onOpenExternalApp: (String) -> Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showPlaylistsTab by remember { mutableStateOf(false) }
    var showCreatePlaylistDialog by remember { mutableStateOf(false) }
    var trackForPlaylistDialog by remember { mutableStateOf<MusicTrackEntity?>(null) }

    val audioPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        uris.forEach { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        onImportTracks(uris)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PitchBlack)
    ) {
        HudScreenTopBar(
            title = "Músicas & Áudio",
            subtitle = "REPRODUTOR INTEGRADO • LISTAS DE REPRODUÇÃO",
            onBack = onBack,
            trailingAction = {
                IconButton(
                    onClick = { audioPicker.launch(arrayOf("audio/*")) },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("import_music_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Adicionar músicas", tint = JarvisGoldBright)
                }
            }
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Player Deck
            item {
                HudPanelCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = playbackState.currentTrack?.title ?: "Nenhuma faixa em reprodução",
                        style = MaterialTheme.typography.titleLarge,
                        color = JarvisGoldBright,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = playbackState.currentTrack?.artist ?: "Adicione músicas do dispositivo para iniciar",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextGoldSecondary
                    )
                    Spacer(Modifier.height(10.dp))

                    val dur = playbackState.durationMs.coerceAtLeast(1L)
                    Slider(
                        value = playbackState.positionMs.toFloat().coerceIn(0f, dur.toFloat()),
                        onValueChange = { onSeek(it.toLong()) },
                        valueRange = 0f..dur.toFloat(),
                        colors = SliderDefaults.colors(thumbColor = JarvisGoldBright, activeTrackColor = JarvisGold)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(formatDuration(playbackState.positionMs), style = MaterialTheme.typography.labelSmall, color = TextGoldSecondary)
                        Text(formatDuration(playbackState.durationMs), style = MaterialTheme.typography.labelSmall, color = TextGoldSecondary)
                    }

                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onToggleShuffle) {
                            Icon(Icons.Default.Shuffle, contentDescription = "Aleatório", tint = if (playbackState.shuffleEnabled) HoloCyan else TextGoldSecondary)
                        }
                        IconButton(onClick = onPrevious, modifier = Modifier.minimumInteractiveComponentSize()) {
                            Icon(Icons.Default.SkipPrevious, contentDescription = "Faixa anterior", tint = JarvisGoldBright, modifier = Modifier.size(32.dp))
                        }
                        IconButton(
                            onClick = onTogglePlayPause,
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(JarvisGold)
                                .testTag("music_play_pause_button")
                        ) {
                            Icon(
                                imageVector = if (playbackState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (playbackState.isPlaying) "Pausar" else "Reproduzir",
                                tint = PitchBlack,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        IconButton(onClick = onNext, modifier = Modifier.minimumInteractiveComponentSize()) {
                            Icon(Icons.Default.SkipNext, contentDescription = "Próxima faixa", tint = JarvisGoldBright, modifier = Modifier.size(32.dp))
                        }
                        IconButton(onClick = onToggleRepeat) {
                            Icon(Icons.Default.Repeat, contentDescription = "Repetir", tint = if (playbackState.repeatEnabled) HoloCyan else TextGoldSecondary)
                        }
                    }

                    Spacer(Modifier.height(6.dp))
                    Text("Volume de reprodução: ${(playbackState.volume * 100).roundToInt()}%", style = MaterialTheme.typography.labelSmall, color = TextGoldSecondary)
                    Slider(
                        value = playbackState.volume,
                        onValueChange = onVolumeChange,
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = JarvisGoldBright, activeTrackColor = JarvisGold)
                    )
                }
            }

            // Library vs Playlists Switch
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !showPlaylistsTab,
                        onClick = { showPlaylistsTab = false },
                        label = { Text("Biblioteca (${tracks.size})") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = JarvisGold, selectedLabelColor = PitchBlack)
                    )
                    FilterChip(
                        selected = showPlaylistsTab,
                        onClick = { showPlaylistsTab = true },
                        label = { Text("Listas (${playlists.size})") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = JarvisGold, selectedLabelColor = PitchBlack)
                    )
                }
            }

            if (!showPlaylistsTab) {
                if (tracks.isEmpty()) {
                    item {
                        HudPanelCard(modifier = Modifier.fillMaxWidth()) {
                            Text("Biblioteca Vazia", style = MaterialTheme.typography.titleMedium, color = JarvisGoldBright)
                            Spacer(Modifier.height(4.dp))
                            Text("Importe arquivos MP3, WAV, M4A ou FLAC do seu aparelho com segurança.", style = MaterialTheme.typography.bodyMedium, color = TextGoldSecondary)
                            Spacer(Modifier.height(10.dp))
                            Button(
                                onClick = { audioPicker.launch(arrayOf("audio/*")) },
                                colors = ButtonDefaults.buttonColors(containerColor = JarvisGold, contentColor = PitchBlack)
                            ) {
                                Icon(Icons.Default.LibraryMusic, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("Selecionar Músicas do Dispositivo")
                            }
                        }
                    }
                } else {
                    items(tracks, key = { it.id }) { track ->
                        val isCurrent = playbackState.currentTrack?.id == track.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (isCurrent) ObsidianPanel else ObsidianCard, RoundedCornerShape(12.dp))
                                .clickable { onPlayTrack(track, tracks) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(track.title, style = MaterialTheme.typography.titleMedium, color = if (isCurrent) JarvisGoldBright else TextGoldPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${track.artist} • ${formatDuration(track.durationMs)}", style = MaterialTheme.typography.labelSmall, color = TextGoldSecondary)
                            }
                            IconButton(onClick = { onSetAsAlarm(track) }) {
                                Icon(Icons.Default.Alarm, contentDescription = "Usar no despertador", tint = HoloCyan)
                            }
                            if (playlists.isNotEmpty()) {
                                IconButton(onClick = { trackForPlaylistDialog = track }) {
                                    Icon(Icons.Default.PlaylistAdd, contentDescription = "Adicionar à lista", tint = JarvisGoldBright)
                                }
                            }
                            IconButton(onClick = { onDeleteTrack(track) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Remover faixa", tint = HoloCrimson)
                            }
                        }
                    }
                }
            } else {
                item {
                    OutlinedButton(
                        onClick = { showCreatePlaylistDialog = true },
                        border = BorderStroke(1.dp, JarvisGold),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Criar Nova Lista de Reprodução", color = JarvisGoldBright)
                    }
                }
                items(playlists, key = { it.playlist.id }) { item ->
                    HudPanelCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.playlist.name, style = MaterialTheme.typography.titleMedium, color = JarvisGoldBright)
                                Text("${item.tracks.size} faixa(s)", style = MaterialTheme.typography.labelSmall, color = TextGoldSecondary)
                            }
                            if (item.tracks.isNotEmpty()) {
                                IconButton(onClick = { onPlayTrack(item.tracks.first(), item.tracks) }) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Tocar lista", tint = JarvisGoldBright)
                                }
                            }
                            IconButton(onClick = { onDeletePlaylist(item.playlist.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Excluir lista", tint = HoloCrimson)
                            }
                        }
                    }
                }
            }

            // External music services integration
            item {
                HudPanelCard {
                    Text("SERVIÇOS EXTERNOS DE MÚSICA", style = MaterialTheme.typography.labelLarge, color = JarvisGoldBright)
                    Spacer(Modifier.height(6.dp))
                    Text("Abra serviços compatíveis instalados no aparelho:", style = MaterialTheme.typography.labelSmall, color = TextGoldSecondary)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { onOpenExternalApp("com.spotify.music") },
                            border = BorderStroke(1.dp, JarvisGoldBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Spotify", color = TextGoldPrimary)
                        }
                        OutlinedButton(
                            onClick = { onOpenExternalApp("com.google.android.apps.youtube.music") },
                            border = BorderStroke(1.dp, JarvisGoldBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("YT Music", color = TextGoldPrimary)
                        }
                    }
                }
            }
        }
    }

    if (showCreatePlaylistDialog) {
        var plName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreatePlaylistDialog = false },
            containerColor = ObsidianPanel,
            title = { Text("Nova Lista de Reprodução", color = JarvisGoldBright) },
            text = {
                OutlinedTextField(
                    value = plName,
                    onValueChange = { plName = it },
                    label = { Text("Nome da lista") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCreatePlaylist(plName)
                        showCreatePlaylistDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = JarvisGold, contentColor = PitchBlack)
                ) { Text("Criar") }
            },
            dismissButton = {
                TextButton(onClick = { showCreatePlaylistDialog = false }) { Text("Cancelar", color = TextGoldSecondary) }
            }
        )
    }

    trackForPlaylistDialog?.let { targetTrack ->
        AlertDialog(
            onDismissRequest = { trackForPlaylistDialog = null },
            containerColor = ObsidianPanel,
            title = { Text("Adicionar à Lista", color = JarvisGoldBright) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    playlists.forEach { pl ->
                        OutlinedButton(
                            onClick = {
                                onAddTrackToPlaylist(pl.playlist.id, targetTrack.id)
                                trackForPlaylistDialog = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(pl.playlist.name, color = TextGoldPrimary)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { trackForPlaylistDialog = null }) { Text("Fechar", color = TextGoldSecondary) }
            }
        )
    }
}

private fun formatDuration(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val min = totalSec / 60L
    val sec = totalSec % 60L
    return String.format(Locale.getDefault(), "%02d:%02d", min, sec)
}
