package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val JarvisColorScheme = darkColorScheme(
    primary = JarvisGold,
    onPrimary = PitchBlack,
    primaryContainer = ObsidianElevated,
    onPrimaryContainer = JarvisGoldBright,
    secondary = JarvisAmber,
    onSecondary = PitchBlack,
    secondaryContainer = ObsidianCard,
    onSecondaryContainer = TextGoldPrimary,
    tertiary = HoloCyan,
    onTertiary = PitchBlack,
    background = PitchBlack,
    onBackground = TextGoldPrimary,
    surface = ObsidianVoid,
    onSurface = TextGoldPrimary,
    surfaceVariant = ObsidianPanel,
    onSurfaceVariant = TextGoldSecondary,
    outline = JarvisGoldBorder,
    outlineVariant = JarvisGoldSubtle,
    error = HoloCrimson,
    onError = PitchBlack
)

val JarvisShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun JarvisTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = JarvisColorScheme,
        typography = JarvisTypography,
        shapes = JarvisShapes,
        content = content
    )
}
