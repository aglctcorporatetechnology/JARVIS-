package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.alarm.AlarmScheduler
import com.example.data.preferences.JarvisSettings
import com.example.ui.components.HudPanelCard
import com.example.ui.components.HudScreenTopBar
import com.example.ui.components.HudStatusPill
import com.example.ui.theme.HoloCrimson
import com.example.ui.theme.HoloEmerald
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextGoldPrimary
import com.example.ui.theme.TextGoldSecondary
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    settings: JarvisSettings,
    messageCount: Int,
    userDisplayName: String?,
    userEmail: String?,
    cloudSyncError: String?,
    onBack: () -> Unit,
    onOpenVoiceScreen: () -> Unit,
    onOpenInstallScreen: () -> Unit = {},
    onSelectGeminiModel: (String) -> Unit,
    onSaveApiKeys: (String, String) -> Unit,
    onUpdateVisuals: (Float, Boolean) -> Unit,
    onUpdateAlarmDefaults: (Int, Float) -> Unit,
    onClearHistory: () -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var weatherKey by remember(settings.weatherApiKey) { mutableStateOf(settings.weatherApiKey) }
    var mapsKey by remember(settings.mapsTrafficApiKey) { mutableStateOf(settings.mapsTrafficApiKey) }
    var glow by remember(settings.hudGlowIntensity) { mutableFloatStateOf(settings.hudGlowIntensity) }
    var globeAnim by remember(settings.globeAnimationEnabled) { mutableStateOf(settings.globeAnimationEnabled) }
    var snoozeMin by remember(settings.defaultSnoozeMinutes) { mutableIntStateOf(settings.defaultSnoozeMinutes) }
    var alarmVol by remember(settings.alarmVolume) { mutableFloatStateOf(settings.alarmVolume) }

    val hasMic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    val hasLoc = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val hasNotif = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    val hasExactAlarm = AlarmScheduler(context).canScheduleExactAlarms()

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {}

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PitchBlack)
    ) {
        HudScreenTopBar(
            title = "Configurações",
            subtitle = "CENTRAL DE CONTROLE, APIS, PERMISSÕES & HUD",
            onBack = onBack
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Google Account & Multi-Device Cloud Sync
            item {
                HudPanelCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CONTA GOOGLE & NUVEM",
                            style = MaterialTheme.typography.labelLarge,
                            color = JarvisGoldBright
                        )
                        HudStatusPill(
                            label = if (cloudSyncError == null) "SINCRONIZADO" else "ATENÇÃO",
                            color = if (cloudSyncError == null) HoloEmerald else HoloCrimson
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "Perfil Google",
                            tint = JarvisGoldBright,
                            modifier = Modifier.size(38.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = userDisplayName?.takeIf { it.isNotBlank() } ?: "Usuário Google Conectado",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextGoldPrimary
                            )
                            Text(
                                text = userEmail?.takeIf { it.isNotBlank() } ?: "Sincronização ativa entre aparelhos Android",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextGoldSecondary
                            )
                        }
                    }
                    if (!cloudSyncError.isNullOrBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Aviso de sincronização: $cloudSyncError",
                            style = MaterialTheme.typography.labelSmall,
                            color = HoloCrimson
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "Conversas, voz, preferências do HUD, alarmes e playlists ficam salvos na sua conta Google para uso em qualquer dispositivo Android.",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextGoldSecondary
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = onSignOut,
                        border = BorderStroke(1.dp, HoloCrimson),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_google_sign_out_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = "Sair da Conta Google",
                            tint = HoloCrimson,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("Sair da Conta Google", color = HoloCrimson)
                    }
                }
            }

            // Voice & Wake Word shortcut
            item {
                HudPanelCard {
                    Text("VOZ, PALAVRA DE ATIVAÇÃO & IDIOMA", style = MaterialTheme.typography.labelLarge, color = JarvisGoldBright)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Palavra atual: '${settings.wakeWord}' • Idioma: ${settings.languageTag} • Volume: ${(settings.assistantVolume * 100).roundToInt()}%",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextGoldSecondary
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = onOpenVoiceScreen,
                        colors = ButtonDefaults.buttonColors(containerColor = JarvisGold, contentColor = PitchBlack),
                        modifier = Modifier.fillMaxWidth().testTag("settings_open_voice_button")
                    ) {
                        Text("Abrir Central Voz do JARVIS")
                    }
                }
            }

            // Install on Phone & Tablet without PC
            item {
                HudPanelCard {
                    Text("BAIXAR E INSTALAR NO TABLET & CELULAR", style = MaterialTheme.typography.labelLarge, color = JarvisGoldBright)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Transfira o aplicativo para outro celular ou tablet Android sem computador via Quick Share, Bluetooth, pasta Downloads ou QR Code.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextGoldSecondary
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = onOpenInstallScreen,
                        colors = ButtonDefaults.buttonColors(containerColor = JarvisGold, contentColor = PitchBlack),
                        modifier = Modifier.fillMaxWidth().testTag("settings_open_install_button")
                    ) {
                        Text("Instalar em Outro Android (Sem PC)")
                    }
                }
            }

            // AI Engine & Model Selection
            item {
                val activeModel = com.example.ai.JarvisGeminiModels.normalize(settings.geminiModelName)
                HudPanelCard {
                    Text("INTELIGÊNCIA ARTIFICIAL (GEMINI)", style = MaterialTheme.typography.labelLarge, color = JarvisGoldBright)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        com.example.ai.JarvisGeminiModels.supportedModels.forEach { modelOption ->
                            FilterChip(
                                selected = activeModel == modelOption.id,
                                onClick = { onSelectGeminiModel(modelOption.id) },
                                label = {
                                    Text(
                                        text = if (modelOption.requiresBilling) "${modelOption.label} (Blaze)" else modelOption.label,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = JarvisGold, selectedLabelColor = PitchBlack)
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    val selectedInfo = com.example.ai.JarvisGeminiModels.supportedModels.firstOrNull { it.id == activeModel }
                    if (selectedInfo != null) {
                        Text(
                            text = "Modelo ativo: ${selectedInfo.label} (${selectedInfo.tierHint})",
                            style = MaterialTheme.typography.labelSmall,
                            color = JarvisGoldBright
                        )
                        Spacer(Modifier.height(4.dp))
                    }
                    Text(
                        "Conectado via Firebase AI Logic + App Check (timeout 90s com fallback automático; gemini-3.8-flash e gemini-3.5-flash-lite não exigem plano pago).",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextGoldSecondary
                    )
                }
            }

            // API Configuration
            item {
                HudPanelCard {
                    Text("CONFIGURAÇÃO DAS APIS EXTERNAS", style = MaterialTheme.typography.labelLarge, color = JarvisGoldBright)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Clima (Open-Meteo) e Rotas (OSRM/Nominatim) funcionam sem chave. Informe chaves opcionais abaixo para provedores extras:",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextGoldSecondary
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = weatherKey,
                        onValueChange = { weatherKey = it },
                        label = { Text("OpenWeatherMap API Key (opcional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("settings_weather_key_input")
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = mapsKey,
                        onValueChange = { mapsKey = it },
                        label = { Text("Google Routes / Traffic API Key (opcional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("settings_maps_key_input")
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { onSaveApiKeys(weatherKey, mapsKey) },
                        colors = ButtonDefaults.buttonColors(containerColor = JarvisGold, contentColor = PitchBlack),
                        modifier = Modifier.fillMaxWidth().testTag("settings_save_apis_button")
                    ) {
                        Text("Salvar Chaves Localmente")
                    }
                }
            }

            // Visual Personalization
            item {
                HudPanelCard {
                    Text("PERSONALIZAÇÃO VISUAL DO HUD", style = MaterialTheme.typography.labelLarge, color = JarvisGoldBright)
                    Spacer(Modifier.height(8.dp))
                    Text("Intensidade luminosa dourada: ${(glow * 100).roundToInt()}%", color = TextGoldPrimary)
                    Slider(
                        value = glow,
                        onValueChange = {
                            glow = it
                            onUpdateVisuals(glow, globeAnim)
                        },
                        valueRange = 0.2f..1.0f
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Animação do Globo Holográfico", color = TextGoldPrimary)
                        Switch(
                            checked = globeAnim,
                            onCheckedChange = {
                                globeAnim = it
                                onUpdateVisuals(glow, globeAnim)
                            }
                        )
                    }
                }
            }

            // Permissions
            item {
                HudPanelCard {
                    Text("PERMISSÕES DO SISTEMA ANDROID", style = MaterialTheme.typography.labelLarge, color = JarvisGoldBright)
                    Spacer(Modifier.height(8.dp))
                    PermissionStatusRow("Microfone (RECORD_AUDIO)", hasMic)
                    PermissionStatusRow("Localização (GPS)", hasLoc)
                    PermissionStatusRow("Notificações", hasNotif)
                    PermissionStatusRow("Alarmes Exatos", hasExactAlarm)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val perms = buildList {
                                    add(Manifest.permission.RECORD_AUDIO)
                                    add(Manifest.permission.ACCESS_COARSE_LOCATION)
                                    add(Manifest.permission.ACCESS_FINE_LOCATION)
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        add(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                }.toTypedArray()
                                permLauncher.launch(perms)
                            },
                            border = BorderStroke(1.dp, JarvisGoldBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Solicitar Permissões", color = JarvisGoldBright)
                        }
                        OutlinedButton(
                            onClick = {
                                runCatching {
                                    context.startActivity(
                                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                            data = Uri.parse("package:${context.packageName}")
                                        }
                                    )
                                }
                            },
                            border = BorderStroke(1.dp, JarvisGoldBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Ajustes Android", color = TextGoldPrimary)
                        }
                    }
                }
            }

            // Alarm Defaults & History
            item {
                HudPanelCard {
                    Text("DESPERTADOR & HISTÓRICO", style = MaterialTheme.typography.labelLarge, color = JarvisGoldBright)
                    Spacer(Modifier.height(8.dp))
                    Text("Soneca padrão: $snoozeMin min", color = TextGoldPrimary)
                    Slider(
                        value = snoozeMin.toFloat(),
                        onValueChange = {
                            snoozeMin = it.roundToInt()
                            onUpdateAlarmDefaults(snoozeMin, alarmVol)
                        },
                        valueRange = 1f..30f
                    )
                    Text("Volume padrão do despertador: ${(alarmVol * 100).roundToInt()}%", color = TextGoldPrimary)
                    Slider(
                        value = alarmVol,
                        onValueChange = {
                            alarmVol = it
                            onUpdateAlarmDefaults(snoozeMin, alarmVol)
                        },
                        valueRange = 0.2f..1f
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Mensagens salvas: $messageCount", color = TextGoldSecondary)
                        OutlinedButton(
                            onClick = onClearHistory,
                            border = BorderStroke(1.dp, HoloCrimson)
                        ) {
                            Text("Limpar Histórico", color = HoloCrimson)
                        }
                    }
                }
            }

            // Integration Status Summary
            item {
                HudPanelCard {
                    Text("GERENCIAMENTO DE INTEGRAÇÕES", style = MaterialTheme.typography.labelLarge, color = JarvisGoldBright)
                    Spacer(Modifier.height(8.dp))
                    PermissionStatusRow("Conta Google & Cloud Firestore", cloudSyncError == null)
                    PermissionStatusRow("Firebase AI Logic (Gemini)", true)
                    PermissionStatusRow("Reconhecimento & Síntese de Voz", true)
                    PermissionStatusRow("Clima (Open-Meteo)", true)
                    PermissionStatusRow("Mapas & Rotas (OSRM/Nominatim)", true)
                    PermissionStatusRow("Trânsito Google Routes API", settings.mapsTrafficApiKey.isNotBlank())
                    PermissionStatusRow("TTS Externo Personalizado", settings.externalTtsEnabled && settings.externalTtsApiKey.isNotBlank())
                }
            }
        }
    }
}

@Composable
private fun PermissionStatusRow(label: String, granted: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = TextGoldPrimary)
        HudStatusPill(
            label = if (granted) "ATIVO" else "PENDENTE",
            color = if (granted) HoloEmerald else HoloCrimson
        )
    }
}
