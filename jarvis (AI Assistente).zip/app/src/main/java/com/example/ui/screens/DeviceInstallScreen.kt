package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TabletAndroid
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.preferences.JarvisSettings
import com.example.install.DeviceInstallInfo
import com.example.install.buildShareApkIntent
import com.example.install.exportInstalledApkToCache
import com.example.install.generateQrMatrix
import com.example.install.inspectDeviceInstallInfo
import com.example.install.normalizeInstallDownloadUrl
import com.example.install.openExternalDownloadUrl
import com.example.install.openSecurityInstallSettings
import com.example.install.saveInstalledApkToUri
import com.example.ui.components.HudPanelCard
import com.example.ui.components.HudScreenTopBar
import com.example.ui.components.HudStatusPill
import com.example.ui.theme.HoloCrimson
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.HoloEmerald
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianPanel
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextGoldPrimary
import com.example.ui.theme.TextGoldSecondary
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun DeviceInstallScreen(
    settings: JarvisSettings,
    userEmail: String?,
    onBack: () -> Unit,
    onSaveDownloadUrl: (String) -> Unit,
    onNotify: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var urlInput by remember(settings.installDownloadUrl) { mutableStateOf(settings.installDownloadUrl) }
    var isWorking by remember { mutableStateOf(false) }

    val normalizedUrl = remember(urlInput) { normalizeInstallDownloadUrl(urlInput) }
    val qrMatrix = remember(normalizedUrl) { normalizedUrl?.let { generateQrMatrix(it, sizePx = 64) } }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(PitchBlack)
    ) {
        val isTabletExpanded = maxWidth >= 760.dp
        val deviceInfo = remember(context, isTabletExpanded) {
            inspectDeviceInstallInfo(context, isTabletExpanded)
        }

        val saveApkLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
        ) { destinationUri: Uri? ->
            if (destinationUri != null) {
                scope.launch {
                    isWorking = true
                    val result = saveInstalledApkToUri(context, destinationUri)
                    isWorking = false
                    result.onSuccess { bytes ->
                        val mb = String.format(Locale.getDefault(), "%.1f MB", bytes.toDouble() / (1024.0 * 1024.0))
                        onNotify("Instalador salvo ($mb), senhor. Toque no arquivo no gerenciador do Android para instalar.")
                    }.onFailure { err ->
                        onNotify(err.localizedMessage ?: "Falha ao salvar instalador no aparelho.")
                    }
                }
            }
        }

        val handleShareApk: () -> Unit = {
            scope.launch {
                isWorking = true
                val result = exportInstalledApkToCache(context)
                isWorking = false
                result.onSuccess { apkFile ->
                    runCatching {
                        context.startActivity(buildShareApkIntent(context, apkFile))
                    }.onFailure { err ->
                        onNotify("Não foi possível abrir o compartilhamento Android: ${err.localizedMessage}")
                    }
                }.onFailure { err ->
                    onNotify(err.localizedMessage ?: "Não foi possível preparar o APK para envio.")
                }
            }
        }

        val handleOpenBrowser: () -> Unit = {
            val valid = normalizeInstallDownloadUrl(urlInput)
            if (valid == null) {
                onNotify("Informe um link válido (ex.: https://...) do arquivo APK ou loja para abrir no navegador.")
            } else {
                onSaveDownloadUrl(valid)
                openExternalDownloadUrl(context, valid).onFailure { err ->
                    onNotify(err.localizedMessage ?: "Nenhum navegador disponível neste aparelho.")
                }
            }
        }

        val handleCopyUrl: () -> Unit = {
            val valid = normalizeInstallDownloadUrl(urlInput)
            if (valid == null) {
                onNotify("Informe um link válido antes de copiar, senhor.")
            } else {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                cm?.setPrimaryClip(ClipData.newPlainText("Link de Instalação JARVIS", valid))
                onNotify("Link copiado para a área de transferência.")
            }
        }

        Column(modifier = Modifier.fillMaxSize()) {
            HudScreenTopBar(
                title = "Instalar Sem PC",
                subtitle = "CELULAR, TABLET ANDROID • QUICK SHARE & QR CODE",
                onBack = onBack
            )

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                if (isTabletExpanded) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                DeviceDiagnosticsCard(deviceInfo, userEmail)
                                DirectTransferNoPcCard(
                                    info = deviceInfo,
                                    isWorking = isWorking,
                                    onShareApk = handleShareApk,
                                    onSaveApkToDownloads = {
                                        saveApkLauncher.launch(deviceInfo.suggestedApkFileName)
                                    }
                                )
                            }
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                BrowserDownloadAndQrCard(
                                    urlInput = urlInput,
                                    normalizedUrl = normalizedUrl,
                                    qrMatrix = qrMatrix,
                                    onUrlChange = { urlInput = it },
                                    onSaveUrl = {
                                        val valid = normalizeInstallDownloadUrl(urlInput)
                                        if (valid != null) {
                                            onSaveDownloadUrl(valid)
                                            onNotify("Link de instalação salvo, senhor.")
                                        } else {
                                            onNotify("Informe um endereço HTTPS válido.")
                                        }
                                    },
                                    onOpenBrowser = handleOpenBrowser,
                                    onCopyUrl = handleCopyUrl
                                )
                                NoPcInstallStepsCard(
                                    onOpenSecuritySettings = {
                                        openSecurityInstallSettings(context).onFailure {
                                            onNotify("Abra Configurações > Segurança no aparelho.")
                                        }
                                    }
                                )
                            }
                        }
                    }
                } else {
                    item { DeviceDiagnosticsCard(deviceInfo, userEmail) }
                    item {
                        DirectTransferNoPcCard(
                            info = deviceInfo,
                            isWorking = isWorking,
                            onShareApk = handleShareApk,
                            onSaveApkToDownloads = {
                                saveApkLauncher.launch(deviceInfo.suggestedApkFileName)
                            }
                        )
                    }
                    item {
                        BrowserDownloadAndQrCard(
                            urlInput = urlInput,
                            normalizedUrl = normalizedUrl,
                            qrMatrix = qrMatrix,
                            onUrlChange = { urlInput = it },
                            onSaveUrl = {
                                val valid = normalizeInstallDownloadUrl(urlInput)
                                if (valid != null) {
                                    onSaveDownloadUrl(valid)
                                    onNotify("Link de instalação salvo, senhor.")
                                } else {
                                    onNotify("Informe um endereço HTTPS válido.")
                                }
                            },
                            onOpenBrowser = handleOpenBrowser,
                            onCopyUrl = handleCopyUrl
                        )
                    }
                    item {
                        NoPcInstallStepsCard(
                            onOpenSecuritySettings = {
                                openSecurityInstallSettings(context).onFailure {
                                    onNotify("Abra Configurações > Segurança no aparelho.")
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceDiagnosticsCard(
    info: DeviceInstallInfo,
    userEmail: String?
) {
    HudPanelCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.TabletAndroid,
                    contentDescription = "Aparelho Android",
                    tint = JarvisGoldBright,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "ESTE APARELHO ANDROID",
                    style = MaterialTheme.typography.labelLarge,
                    color = JarvisGoldBright
                )
            }
            HudStatusPill(
                label = if (info.canExportUniversalApk) "APK PRONTO" else "SPLIT AAB",
                color = if (info.canExportUniversalApk) HoloEmerald else JarvisGold
            )
        }
        Spacer(Modifier.height(10.dp))
        DiagnosticLine("Modelo", "${info.deviceModel} (${info.deviceFormFactor})")
        DiagnosticLine("Sistema", "${info.androidVersion} • ${info.abiArchitecture}")
        DiagnosticLine("Versão JARVIS", "v${info.versionName} (build ${info.versionCode})")
        if (info.apkSizeMb > 0.1) {
            DiagnosticLine(
                "Tamanho do pacote",
                String.format(Locale.getDefault(), "%.1f MB", info.apkSizeMb)
            )
        }
        DiagnosticLine(
            "Conta sincronizada",
            userEmail?.takeIf { it.isNotBlank() } ?: "Conectada via Google"
        )
    }
}

@Composable
private fun DiagnosticLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = TextGoldSecondary)
        Text(value, style = MaterialTheme.typography.bodySmall, color = TextGoldPrimary)
    }
}

@Composable
private fun DirectTransferNoPcCard(
    info: DeviceInstallInfo,
    isWorking: Boolean,
    onShareApk: () -> Unit,
    onSaveApkToDownloads: () -> Unit
) {
    HudPanelCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.InstallMobile,
                contentDescription = "Enviar APK sem computador",
                tint = JarvisGoldBright,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = "ENVIAR PARA CELULAR OU TABLET (SEM PC)",
                style = MaterialTheme.typography.labelLarge,
                color = JarvisGoldBright
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text = if (info.canExportUniversalApk) {
                "Envie o instalador oficial já instalado neste dispositivo diretamente para seu Tablet ou outro Celular Android usando Quick Share, Bluetooth, WhatsApp ou Google Drive — ou salve uma cópia na pasta Downloads."
            } else {
                "Este dispositivo recebeu uma instalação em pacotes divididos (AAB). Para instalar em outro celular ou tablet sem computador, utilize o cartão de Link / QR Code."
            },
            style = MaterialTheme.typography.bodySmall,
            color = TextGoldSecondary
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onShareApk,
            enabled = info.canExportUniversalApk && !isWorking,
            colors = ButtonDefaults.buttonColors(
                containerColor = JarvisGold,
                contentColor = PitchBlack
            ),
            modifier = Modifier
                .fillMaxWidth()
                .minimumInteractiveComponentSize()
                .testTag("install_share_apk_button")
        ) {
            if (isWorking) {
                CircularProgressIndicator(
                    color = PitchBlack,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(18.dp)
                )
            } else {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(8.dp))
            Text("Enviar APK via Quick Share / Bluetooth")
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = onSaveApkToDownloads,
            enabled = info.canExportUniversalApk && !isWorking,
            border = BorderStroke(1.dp, JarvisGoldBorder),
            modifier = Modifier
                .fillMaxWidth()
                .minimumInteractiveComponentSize()
                .testTag("install_save_apk_button")
        ) {
            Icon(Icons.Default.Download, contentDescription = null, tint = JarvisGoldBright, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Salvar Cópia na Pasta Downloads", color = JarvisGoldBright)
        }
    }
}

@Composable
private fun BrowserDownloadAndQrCard(
    urlInput: String,
    normalizedUrl: String?,
    qrMatrix: com.example.install.QrMatrixData?,
    onUrlChange: (String) -> Unit,
    onSaveUrl: () -> Unit,
    onOpenBrowser: () -> Unit,
    onCopyUrl: () -> Unit
) {
    HudPanelCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.QrCode2,
                contentDescription = "QR Code e navegador",
                tint = JarvisGoldBright,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = "BAIXAR VIA NAVEGADOR & QR CODE",
                style = MaterialTheme.typography.labelLarge,
                color = JarvisGoldBright
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = "Cole o link do seu APK (Google Drive, GitHub Releases, Firebase App Distribution ou Play Store). Escaneie o QR Code com a câmera do Tablet ou Celular para baixar e instalar sem computador.",
            style = MaterialTheme.typography.bodySmall,
            color = TextGoldSecondary
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = urlInput,
            onValueChange = onUrlChange,
            label = { Text("Link HTTPS do instalador ou loja") },
            placeholder = { Text("https://...", color = TextGoldSecondary) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = JarvisGoldBright,
                unfocusedBorderColor = JarvisGoldBorder,
                focusedTextColor = TextGoldPrimary,
                unfocusedTextColor = TextGoldPrimary,
                focusedContainerColor = ObsidianCard,
                unfocusedContainerColor = ObsidianCard
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("install_url_input")
        )
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onOpenBrowser,
                colors = ButtonDefaults.buttonColors(
                    containerColor = JarvisGold,
                    contentColor = PitchBlack
                ),
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
                    .testTag("install_open_browser_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Baixar no Navegador", maxLines = 1)
            }
            OutlinedButton(
                onClick = onSaveUrl,
                border = BorderStroke(1.dp, JarvisGoldBorder),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("install_save_url_button")
            ) {
                Text("Salvar", color = JarvisGoldBright)
            }
            OutlinedButton(
                onClick = onCopyUrl,
                border = BorderStroke(1.dp, JarvisGoldBorder),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("install_copy_url_button")
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = "Copiar link", tint = HoloCyan, modifier = Modifier.size(16.dp))
            }
        }

        if (qrMatrix != null && normalizedUrl != null) {
            Spacer(Modifier.height(14.dp))
            Surface(
                color = ObsidianPanel,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, JarvisGoldBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "ESCANEIE NO OUTRO CELULAR OU TABLET",
                        style = MaterialTheme.typography.labelSmall,
                        color = HoloCyan
                    )
                    Spacer(Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .size(184.dp)
                            .background(Color.White, RoundedCornerShape(12.dp))
                            .padding(10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("install_qr_canvas")
                        ) {
                            val cellW = size.width / qrMatrix.width.toFloat()
                            val cellH = size.height / qrMatrix.height.toFloat()
                            for (y in 0 until qrMatrix.height) {
                                val rowOffset = y * qrMatrix.width
                                for (x in 0 until qrMatrix.width) {
                                    if (qrMatrix.darkModules[rowOffset + x]) {
                                        drawRect(
                                            color = Color.Black,
                                            topLeft = Offset(x * cellW, y * cellH),
                                            size = Size(cellW + 0.5f, cellH + 0.5f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = normalizedUrl,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextGoldSecondary,
                        maxLines = 2
                    )
                }
            }
        }
    }
}

@Composable
private fun NoPcInstallStepsCard(
    onOpenSecuritySettings: () -> Unit
) {
    HudPanelCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Guia sem computador",
                tint = HoloEmerald,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = "COMO INSTALAR NO TABLET E CELULAR SEM PC",
                style = MaterialTheme.typography.labelLarge,
                color = JarvisGoldBright
            )
        }
        Spacer(Modifier.height(10.dp))
        StepRow("1", "Toque em 'Enviar APK via Quick Share / Bluetooth' ou abra o link no navegador do Tablet ou Celular.")
        StepRow("2", "No aparelho receptor, toque no arquivo JARVIS.apk recebido ou baixado na pasta Downloads.")
        StepRow("3", "Se o Android pedir autorização para o navegador ou gerenciador de arquivos, ative 'Permitir desta fonte'.")
        StepRow("4", "Conclua a instalação e entre com sua mesma Conta Google para restaurar histórico, voz e alarmes.")
        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = onOpenSecuritySettings,
            border = BorderStroke(1.dp, JarvisGoldBorder),
            modifier = Modifier
                .fillMaxWidth()
                .minimumInteractiveComponentSize()
                .testTag("install_security_settings_button")
        ) {
            Icon(Icons.Default.Security, contentDescription = null, tint = JarvisGoldBright, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Abrir Ajustes de Segurança do Android", color = JarvisGoldBright)
        }
    }
}

@Composable
private fun StepRow(stepNumber: String, description: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Surface(
            color = ObsidianCard,
            shape = RoundedCornerShape(6.dp),
            border = BorderStroke(1.dp, JarvisGoldBorder)
        ) {
            Text(
                text = stepNumber,
                style = MaterialTheme.typography.labelMedium,
                color = JarvisGoldBright,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }
        Text(
            text = description,
            style = MaterialTheme.typography.bodySmall,
            color = TextGoldPrimary,
            modifier = Modifier.weight(1f)
        )
    }
}
