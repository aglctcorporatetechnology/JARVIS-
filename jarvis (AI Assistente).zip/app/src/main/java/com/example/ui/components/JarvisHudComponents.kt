package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.maps.GeoPoint
import com.example.maps.RouteOption
import com.example.ui.theme.HoloCrimson
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.HoloEmerald
import com.example.ui.theme.JarvisAmber
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.JarvisGoldDim
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianPanel
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextGoldPrimary
import com.example.ui.theme.TextGoldSecondary
import com.example.voice.VoiceEngineState
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun JarvisCircularCore(
    state: VoiceEngineState,
    rmsLevel: Float,
    glowIntensity: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "jarvis_core")
    val outerAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    VoiceEngineState.PROCESSING -> 3600
                    VoiceEngineState.SPEAKING, VoiceEngineState.ACTIVE_LISTENING -> 5200
                    else -> 12000
                },
                easing = LinearEasing
            )
        ),
        label = "outer_angle"
    )
    val innerAngle by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (state == VoiceEngineState.PROCESSING) 2600 else 9000,
                easing = LinearEasing
            )
        ),
        label = "inner_angle"
    )
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val coreAccent = when (state) {
        VoiceEngineState.ACTIVE_LISTENING -> HoloCyan
        VoiceEngineState.WAKE_LISTENING -> JarvisGoldBright
        VoiceEngineState.SPEAKING -> JarvisGoldBright
        VoiceEngineState.PROCESSING -> JarvisAmber
        VoiceEngineState.ERROR -> HoloCrimson
        VoiceEngineState.IDLE -> JarvisGold
    }

    val effectivePulse = pulse + (rmsLevel * 0.16f)

    Box(
        modifier = modifier
            .clip(CircleShape)
            .minimumInteractiveComponentSize()
            .clickable(onClick = onClick)
            .testTag("jarvis_central_core"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxR = size.minDimension / 2f

            // Ambient radial holographic glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        coreAccent.copy(alpha = 0.28f * glowIntensity),
                        JarvisGold.copy(alpha = 0.10f * glowIntensity),
                        Color.Transparent
                    ),
                    center = center,
                    radius = maxR * effectivePulse
                ),
                radius = maxR,
                center = center
            )

            // Outer segmented tech ring
            rotate(degrees = outerAngle, pivot = center) {
                val r1 = maxR * 0.90f
                val arcRect = Size(r1 * 2f, r1 * 2f)
                val topLeft = Offset(center.x - r1, center.y - r1)
                for (i in 0 until 4) {
                    drawArc(
                        color = JarvisGold.copy(alpha = 0.78f),
                        startAngle = i * 90f + 8f,
                        sweepAngle = 68f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcRect,
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                // 36 HUD calibration ticks
                for (t in 0 until 36) {
                    val rad = (t * 10.0) * PI / 180.0
                    val innerTick = maxR * if (t % 3 == 0) 0.77f else 0.81f
                    val outerTick = maxR * 0.85f
                    drawLine(
                        color = JarvisGoldBright.copy(alpha = if (t % 3 == 0) 0.85f else 0.35f),
                        start = Offset(
                            center.x + (innerTick * cos(rad)).toFloat(),
                            center.y + (innerTick * sin(rad)).toFloat()
                        ),
                        end = Offset(
                            center.x + (outerTick * cos(rad)).toFloat(),
                            center.y + (outerTick * sin(rad)).toFloat()
                        ),
                        strokeWidth = if (t % 3 == 0) 2.dp.toPx() else 1.dp.toPx()
                    )
                }
            }

            // Counter-rotating inner holographic ring
            rotate(degrees = innerAngle, pivot = center) {
                val r2 = maxR * 0.67f
                val arcRect = Size(r2 * 2f, r2 * 2f)
                val topLeft = Offset(center.x - r2, center.y - r2)
                for (i in 0 until 6) {
                    drawArc(
                        color = coreAccent.copy(alpha = 0.88f),
                        startAngle = i * 60f + 6f,
                        sweepAngle = 40f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcRect,
                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Butt)
                    )
                }
            }

            // Dynamic voice reactive ring
            val r3 = maxR * (0.48f + rmsLevel * 0.08f)
            drawCircle(
                color = coreAccent.copy(alpha = 0.9f),
                radius = r3,
                center = center,
                style = Stroke(width = 2.5.dp.toPx())
            )

            // Inner glowing reactor nucleus
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        JarvisGoldBright.copy(alpha = 0.85f),
                        coreAccent.copy(alpha = 0.45f),
                        ObsidianPanel.copy(alpha = 0.95f)
                    ),
                    center = center,
                    radius = maxR * 0.38f * effectivePulse
                ),
                radius = maxR * 0.38f,
                center = center
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = if (state == VoiceEngineState.SPEAKING) Icons.Default.GraphicEq else Icons.Default.Mic,
                contentDescription = "Núcleo de Voz JARVIS",
                tint = PitchBlack,
                modifier = Modifier.size(30.dp)
            )
            Text(
                text = "J.A.R.V.I.S",
                style = MaterialTheme.typography.labelLarge,
                color = PitchBlack,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun HolographicGlobeCanvas(
    animate: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "holo_globe")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(16000, easing = LinearEasing)
        ),
        label = "globe_phase"
    )
    val effectivePhase = if (animate) phase else 0.7f

    Canvas(modifier = modifier) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = size.minDimension * 0.38f

        // Outer orbital ring
        drawCircle(
            color = JarvisGold.copy(alpha = 0.25f),
            radius = radius * 1.24f,
            center = center,
            style = Stroke(width = 1.dp.toPx())
        )

        // Globe silhouette & glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    JarvisGold.copy(alpha = 0.14f),
                    Color.Transparent
                ),
                center = center,
                radius = radius * 1.1f
            ),
            radius = radius * 1.1f,
            center = center
        )

        drawCircle(
            color = JarvisGoldBright.copy(alpha = 0.6f),
            radius = radius,
            center = center,
            style = Stroke(width = 1.6.dp.toPx())
        )

        // Parallels (latitude rings)
        for (latIdx in -2..2) {
            val latFraction = latIdx / 3f
            val y = center.y + radius * latFraction
            val halfW = radius * kotlin.math.sqrt((1f - latFraction * latFraction).coerceAtLeast(0f))
            drawLine(
                color = JarvisGold.copy(alpha = 0.35f),
                start = Offset(center.x - halfW, y),
                end = Offset(center.x + halfW, y),
                strokeWidth = 1.dp.toPx()
            )
        }

        // Rotating Meridians (3D wireframe projection)
        for (m in 0 until 6) {
            val angle = effectivePhase + (m * PI / 6.0).toFloat()
            val scaleX = cos(angle)
            val path = Path()
            val steps = 28
            for (s in 0..steps) {
                val theta = -PI / 2.0 + (PI * s / steps)
                val x = center.x + (radius * cos(theta) * scaleX).toFloat()
                val y = center.y + (radius * sin(theta)).toFloat()
                if (s == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(
                path = path,
                color = JarvisGoldBright.copy(alpha = 0.32f + 0.25f * kotlin.math.abs(scaleX)),
                style = Stroke(width = 1.1.dp.toPx())
            )
        }

        // Tactical waypoint pings
        val pingAngle = effectivePhase * 1.3f
        val pingX = center.x + radius * 0.45f * cos(pingAngle)
        val pingY = center.y - radius * 0.22f * sin(pingAngle)
        drawCircle(color = HoloCyan, radius = 3.5.dp.toPx(), center = Offset(pingX, pingY))
        drawCircle(
            color = HoloCyan.copy(alpha = 0.35f),
            radius = 8.dp.toPx(),
            center = Offset(pingX, pingY),
            style = Stroke(width = 1.dp.toPx())
        )
    }
}

@Composable
fun HudPanelCard(
    modifier: Modifier = Modifier,
    accentColor: Color = JarvisGoldBorder,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier,
        color = ObsidianPanel.copy(alpha = 0.92f),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, accentColor),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun HudScreenTopBar(
    title: String,
    subtitle: String,
    onBack: (() -> Unit)? = null,
    trailingAction: (@Composable () -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .border(1.dp, JarvisGoldBorder, CircleShape)
                    .background(ObsidianCard, CircleShape)
                    .testTag("hud_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Voltar",
                    tint = JarvisGoldBright
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.headlineMedium,
                color = JarvisGoldBright,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelMedium,
                color = TextGoldSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (trailingAction != null) {
            trailingAction()
        }
    }
}

@Composable
fun HudStatusPill(
    label: String,
    color: Color = HoloEmerald,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(ObsidianCard)
            .border(1.dp, color.copy(alpha = 0.55f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextGoldPrimary
        )
    }
}

@Composable
fun InteractiveRouteMapCanvas(
    origin: GeoPoint?,
    destination: GeoPoint?,
    routes: List<RouteOption>,
    selectedRouteIndex: Int,
    modifier: Modifier = Modifier
) {
    var panOffset by remember { mutableFloatStateOf(0f) }
    var panOffsetY by remember { mutableFloatStateOf(0f) }

    Canvas(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(ObsidianCard)
            .border(1.dp, JarvisGoldBorder, RoundedCornerShape(16.dp))
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    panOffset += dragAmount.x
                    panOffsetY += dragAmount.y
                }
            }
    ) {
        // Tactical HUD grid lines
        val step = 36.dp.toPx()
        var x = (panOffset % step)
        while (x < size.width) {
            drawLine(
                color = JarvisGoldDim.copy(alpha = 0.18f),
                start = Offset(x, 0f),
                end = Offset(x, size.height),
                strokeWidth = 1.dp.toPx()
            )
            x += step
        }
        var y = (panOffsetY % step)
        while (y < size.height) {
            drawLine(
                color = JarvisGoldDim.copy(alpha = 0.18f),
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 1.dp.toPx()
            )
            y += step
        }

        val allPoints = buildList {
            if (origin != null) add(origin)
            if (destination != null) add(destination)
            routes.forEach { addAll(it.coordinates) }
        }

        if (allPoints.isEmpty()) {
            // Draw idle radar crosshair
            val c = Offset(size.width / 2f, size.height / 2f)
            drawCircle(
                color = JarvisGold.copy(alpha = 0.35f),
                radius = size.minDimension * 0.3f,
                center = c,
                style = Stroke(1.5.dp.toPx())
            )
            drawCircle(
                color = JarvisGold.copy(alpha = 0.2f),
                radius = size.minDimension * 0.16f,
                center = c,
                style = Stroke(1.dp.toPx())
            )
            drawCircle(color = JarvisGoldBright, radius = 4.dp.toPx(), center = c)
            return@Canvas
        }

        val minLat = allPoints.minOf { it.latitude }
        val maxLat = allPoints.maxOf { it.latitude }
        val minLon = allPoints.minOf { it.longitude }
        val maxLon = allPoints.maxOf { it.longitude }

        val latSpan = (maxLat - minLat).coerceAtLeast(0.01)
        val lonSpan = (maxLon - minLon).coerceAtLeast(0.01)
        val pad = 32.dp.toPx()
        val drawW = (size.width - pad * 2).coerceAtLeast(20f)
        val drawH = (size.height - pad * 2).coerceAtLeast(20f)

        fun project(p: GeoPoint): Offset {
            val nx = ((p.longitude - minLon) / lonSpan).toFloat()
            val ny = 1f - ((p.latitude - minLat) / latSpan).toFloat()
            return Offset(
                x = pad + nx * drawW + panOffset * 0.2f,
                y = pad + ny * drawH + panOffsetY * 0.2f
            )
        }

        // Draw alternative routes first, then selected route on top
        routes.forEachIndexed { idx, route ->
            if (route.coordinates.size >= 2 && idx != selectedRouteIndex) {
                val path = Path()
                route.coordinates.forEachIndexed { pIdx, gp ->
                    val pt = project(gp)
                    if (pIdx == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
                }
                drawPath(
                    path = path,
                    color = JarvisGoldDim.copy(alpha = 0.5f),
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }

        routes.getOrNull(selectedRouteIndex)?.let { selected ->
            if (selected.coordinates.size >= 2) {
                val path = Path()
                selected.coordinates.forEachIndexed { pIdx, gp ->
                    val pt = project(gp)
                    if (pIdx == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
                }
                drawPath(
                    path = path,
                    color = HoloCyan,
                    style = Stroke(width = 4.5.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }

        origin?.let { o ->
            val p = project(o)
            drawCircle(color = HoloEmerald.copy(alpha = 0.3f), radius = 12.dp.toPx(), center = p)
            drawCircle(color = HoloEmerald, radius = 5.5.dp.toPx(), center = p)
        }

        destination?.let { d ->
            val p = project(d)
            drawCircle(color = JarvisGoldBright.copy(alpha = 0.3f), radius = 14.dp.toPx(), center = p)
            drawCircle(color = JarvisGoldBright, radius = 6.dp.toPx(), center = p)
        }
    }
}
