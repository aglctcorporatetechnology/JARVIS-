package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.AlarmEntity
import com.example.data.preferences.JarvisSettings
import com.example.music.PlaybackUiState
import com.example.ui.AiUiState
import com.example.ui.WeatherUiState
import com.example.ui.components.HolographicGlobeCanvas
import com.example.ui.components.HudPanelCard
import com.example.ui.components.HudStatusPill
import com.example.ui.components.JarvisCircularCore
import com.example.ui.theme.HoloCrimson
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.HoloEmerald
import com.example.ui.theme.JarvisAmber
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianPanel
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextGoldPrimary
import com.example.ui.theme.TextGoldSecondary
import com.example.voice.VoiceEngineState
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class QuickModuleTile(
    val title: String,
    val icon: ImageVector,
    val tag: String,
    val onClick: () -> Unit
)

@Composable
fun HudHomeScreen(
    settings: JarvisSettings,
    voiceState: VoiceEngineState,
    rmsLevel: Float,
    partialTranscript: String,
    voiceStatusMessage: String,
    aiState: AiUiState,
    weatherState: WeatherUiState,
    alarms: List<AlarmEntity>,
    musicState: PlaybackUiState,
    onCoreTap: () -> Unit,
    onStopVoice: () -> Unit,
    onSendPrompt: (String) -> Unit,
    onOpenAiChat: () -> Unit,
    onOpenVoice: () -> Unit,
    onOpenWeather: () -> Unit,
    onOpenMaps: (String) -> Unit,
    onOpenAlarms: () -> Unit,
    onOpenMusic: () -> Unit,
    onOpenCommandHub: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenInstall: () -> Unit = {},
    onRetry: () -> Unit = {},
    userEmail: String? = null,
    modifier: Modifier = Modifier
) {
    var quickInput by remember { mutableStateOf("") }
    var clockStr by remember { mutableStateOf(SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())) }
    var dateStr by remember { mutableStateOf(SimpleDateFormat("EEE, dd MMM", Locale("pt", "BR")).format(Date())) }

    LaunchedEffect(Unit) {
        while (true) {
            val now = Date()
            clockStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(now)
            dateStr = SimpleDateFormat("EEE, dd MMM", Locale("pt", "BR")).format(now).uppercase()
            delay(1000L)
        }
    }

    val quickModules = remember(onOpenAiChat, onOpenVoice, onOpenWeather, onOpenMaps, onOpenAlarms, onOpenMusic, onOpenInstall, onOpenSettings) {
        listOf(
            QuickModuleTile("IA Gemini", Icons.Default.AutoAwesome, "quick_ai", onOpenAiChat),
            QuickModuleTile("Voz", Icons.Default.RecordVoiceOver, "quick_voice", onOpenVoice),
            QuickModuleTile("Clima", Icons.Default.Cloud, "quick_weather", onOpenWeather),
            QuickModuleTile("Mapas", Icons.Default.Map, "quick_maps") { onOpenMaps("maps") },
            QuickModuleTile("Trânsito", Icons.Default.Traffic, "quick_traffic") { onOpenMaps("traffic") },
            QuickModuleTile("Rodovias", Icons.Default.DirectionsCar, "quick_highways") { onOpenMaps("highways") },
            QuickModuleTile("Alarme", Icons.Default.Alarm, "quick_alarms", onOpenAlarms),
            QuickModuleTile("Música", Icons.Default.MusicNote, "quick_music", onOpenMusic),
            QuickModuleTile("Instalar", Icons.Default.InstallMobile, "quick_install", onOpenInstall),
            QuickModuleTile("Ajustes", Icons.Default.Settings, "quick_settings", onOpenSettings)
        )
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(ObsidianPanel.copy(alpha = 0.65f), PitchBlack)
                )
            )
    ) {
        val isTabletExpanded = maxWidth >= 760.dp

        if (isTabletExpanded) {
            // Adaptive Expanded HUD for Samsung Galaxy Tab A9+ 5G & Tablets
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Left Telemetry & Globe Pane
                Column(
                    modifier = Modifier
                        .weight(0.32f)
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    HudClockHeaderCard(clockStr, dateStr, settings, voiceState, userEmail)
                    HoloGlobeTelemetryCard(
                        globeEnabled = settings.globeAnimationEnabled,
                        onOpenMaps = { onOpenMaps("maps") }
                    )
                    WeatherMiniCard(weatherState, onOpenWeather)
                    NextAlarmMiniCard(alarms, onOpenAlarms)
                }

                // Center Reactor Core & Live Transcript
                Column(
                    modifier = Modifier
                        .weight(0.38f)
                        .fillMaxHeight(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STARK HUD // NÚCLEO",
                            style = MaterialTheme.typography.labelLarge,
                            color = JarvisGold
                        )
                        Surface(
                            onClick = onOpenCommandHub,
                            shape = RoundedCornerShape(50),
                            color = ObsidianCard,
                            border = BorderStroke(1.dp, JarvisGoldBorder),
                            modifier = Modifier.testTag("open_command_hub_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Apps, contentDescription = "Painel", tint = JarvisGoldBright, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("PAINEL", style = MaterialTheme.typography.labelSmall, color = JarvisGoldBright)
                            }
                        }
                    }

                    JarvisCircularCore(
                        state = voiceState,
                        rmsLevel = rmsLevel,
                        glowIntensity = settings.hudGlowIntensity,
                        onClick = onCoreTap,
                        modifier = Modifier.size(260.dp)
                    )

                    LiveAssistantResponseCard(
                        voiceState = voiceState,
                        voiceStatus = voiceStatusMessage,
                        partialTranscript = partialTranscript,
                        aiState = aiState,
                        onStopVoice = onStopVoice,
                        onOpenChat = onOpenAiChat,
                        onRetry = onRetry
                    )

                    QuickPromptBar(
                        value = quickInput,
                        onValueChange = { quickInput = it },
                        onSend = {
                            if (quickInput.isNotBlank()) {
                                onSendPrompt(quickInput)
                                quickInput = ""
                            }
                        },
                        onMicTap = onCoreTap
                    )
                }

                // Right Command Matrix & Media Deck
                Column(
                    modifier = Modifier
                        .weight(0.30f)
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MusicMiniCard(musicState, onOpenMusic)
                    HudPanelCard {
                        Text(
                            text = "ACESSO RÁPIDO",
                            style = MaterialTheme.typography.labelLarge,
                            color = JarvisGoldBright
                        )
                        Spacer(Modifier.height(10.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            quickModules.chunked(3).forEach { rowItems ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    rowItems.forEach { item ->
                                        QuickModuleCompactButton(
                                            item = item,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Smartphone Portrait / Medium Layout
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    HudClockHeaderCard(clockStr, dateStr, settings, voiceState, userEmail)
                }

                item {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        JarvisCircularCore(
                            state = voiceState,
                            rmsLevel = rmsLevel,
                            glowIntensity = settings.hudGlowIntensity,
                            onClick = onCoreTap,
                            modifier = Modifier.size(220.dp)
                        )
                    }
                }

                item {
                    LiveAssistantResponseCard(
                        voiceState = voiceState,
                        voiceStatus = voiceStatusMessage,
                        partialTranscript = partialTranscript,
                        aiState = aiState,
                        onStopVoice = onStopVoice,
                        onOpenChat = onOpenAiChat,
                        onRetry = onRetry
                    )
                }

                item {
                    QuickPromptBar(
                        value = quickInput,
                        onValueChange = { quickInput = it },
                        onSend = {
                            if (quickInput.isNotBlank()) {
                                onSendPrompt(quickInput)
                                quickInput = ""
                            }
                        },
                        onMicTap = onCoreTap
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "MÓDULOS DO SISTEMA",
                            style = MaterialTheme.typography.labelLarge,
                            color = JarvisGold
                        )
                        Text(
                            text = "Ver Painel →",
                            style = MaterialTheme.typography.labelMedium,
                            color = JarvisGoldBright,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(onClick = onOpenCommandHub)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .testTag("open_command_hub_link")
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(quickModules) { item ->
                            QuickModuleCompactButton(
                                item = item,
                                modifier = Modifier.width(94.dp)
                            )
                        }
                    }
                }

                item {
                    HoloGlobeTelemetryCard(
                        globeEnabled = settings.globeAnimationEnabled,
                        onOpenMaps = { onOpenMaps("maps") }
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        WeatherMiniCard(weatherState, onOpenWeather, modifier = Modifier.weight(1f))
                        NextAlarmMiniCard(alarms, onOpenAlarms, modifier = Modifier.weight(1f))
                    }
                }

                item {
                    MusicMiniCard(musicState, onOpenMusic)
                }
            }
        }
    }
}

@Composable
private fun HudClockHeaderCard(
    clockStr: String,
    dateStr: String,
    settings: JarvisSettings,
    voiceState: VoiceEngineState,
    userEmail: String? = null
) {
    HudPanelCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = clockStr,
                    style = MaterialTheme.typography.displayMedium,
                    color = JarvisGoldBright
                )
                Text(
                    text = "$dateStr • PALAVRA: ${settings.wakeWord.uppercase()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextGoldSecondary
                )
                if (!userEmail.isNullOrBlank()) {
                    Text(
                        text = "NUVEM: $userEmail",
                        style = MaterialTheme.typography.labelSmall,
                        color = HoloEmerald,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            val (label, color) = when (voiceState) {
                VoiceEngineState.ACTIVE_LISTENING -> "OUVINDO" to HoloCyan
                VoiceEngineState.WAKE_LISTENING -> "ATIVADO" to HoloEmerald
                VoiceEngineState.SPEAKING -> "FALANDO" to JarvisGoldBright
                VoiceEngineState.PROCESSING -> "GEMINI AI" to JarvisAmber
                VoiceEngineState.ERROR -> "ATENÇÃO" to HoloCrimson
                VoiceEngineState.IDLE -> "ONLINE" to HoloEmerald
            }
            HudStatusPill(label = label, color = color)
        }
    }
}

@Composable
private fun HoloGlobeTelemetryCard(
    globeEnabled: Boolean,
    onOpenMaps: () -> Unit
) {
    HudPanelCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenMaps)
            .testTag("holo_globe_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "TELEMETRIA GLOBAL & MAPAS",
                style = MaterialTheme.typography.labelLarge,
                color = JarvisGoldBright
            )
            Text(
                text = "GPS / ROTAS",
                style = MaterialTheme.typography.labelSmall,
                color = HoloCyan
            )
        }
        Spacer(Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(PitchBlack),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_holo_earth_1794765727571),
                contentDescription = "Globo terrestre holográfico JARVIS",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(0.65f)
            )
            HolographicGlobeCanvas(
                animate = globeEnabled,
                modifier = Modifier.size(120.dp)
            )
        }
    }
}

@Composable
private fun LiveAssistantResponseCard(
    voiceState: VoiceEngineState,
    voiceStatus: String,
    partialTranscript: String,
    aiState: AiUiState,
    onStopVoice: () -> Unit,
    onOpenChat: () -> Unit,
    onRetry: () -> Unit = {}
) {
    HudPanelCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenChat)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (aiState is AiUiState.Error) "FALHA NO GEMINI" else voiceStatus.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = if (aiState is AiUiState.Error) HoloCrimson else JarvisGold
            )
            if (voiceState == VoiceEngineState.SPEAKING || voiceState == VoiceEngineState.ACTIVE_LISTENING) {
                Surface(
                    onClick = onStopVoice,
                    shape = RoundedCornerShape(50),
                    color = HoloCrimson.copy(alpha = 0.18f),
                    border = BorderStroke(1.dp, HoloCrimson),
                    modifier = Modifier.testTag("interrupt_voice_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = "Interromper", tint = HoloCrimson, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("INTERROMPER", style = MaterialTheme.typography.labelSmall, color = HoloCrimson)
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        val displayBody = when {
            partialTranscript.isNotBlank() && voiceState == VoiceEngineState.ACTIVE_LISTENING ->
                "“$partialTranscript”"
            aiState is AiUiState.Thinking -> "Processando solicitação com Google Gemini, senhor..."
            aiState is AiUiState.Streaming -> aiState.partialText
            aiState is AiUiState.Success -> aiState.finalText
            aiState is AiUiState.Error -> aiState.message
            else -> "Diga '${"JARVIS"}' ou toque no núcleo circular para conversar, senhor."
        }
        Text(
            text = displayBody,
            style = MaterialTheme.typography.bodyMedium,
            color = if (aiState is AiUiState.Error) HoloCrimson else TextGoldPrimary,
            maxLines = 4,
            overflow = TextOverflow.Ellipsis
        )
        if (aiState is AiUiState.Error && aiState.canRetry) {
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(
                    containerColor = JarvisGold,
                    contentColor = PitchBlack
                ),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("home_retry_button")
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Tentar novamente", modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Tentar novamente", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun QuickPromptBar(
    value: String,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit,
    onMicTap: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = {
                Text("Comando ou pergunta para o JARVIS...", color = TextGoldSecondary, maxLines = 1)
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { onSend() }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = JarvisGoldBright,
                unfocusedBorderColor = JarvisGoldBorder,
                focusedTextColor = TextGoldPrimary,
                unfocusedTextColor = TextGoldPrimary,
                focusedContainerColor = ObsidianCard,
                unfocusedContainerColor = ObsidianCard
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .weight(1f)
                .testTag("home_prompt_input")
        )
        IconButton(
            onClick = onMicTap,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .size(48.dp)
                .clip(CircleShape)
                .background(ObsidianCard)
                .testTag("home_mic_button")
        ) {
            Icon(Icons.Default.Mic, contentDescription = "Falar comando", tint = JarvisGoldBright)
        }
        IconButton(
            onClick = onSend,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .size(48.dp)
                .clip(CircleShape)
                .background(JarvisGold)
                .testTag("home_send_button")
        ) {
            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Enviar comando", tint = PitchBlack)
        }
    }
}

@Composable
private fun QuickModuleCompactButton(
    item: QuickModuleTile,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = item.onClick,
        color = ObsidianCard,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, JarvisGoldBorder),
        modifier = modifier
            .height(82.dp)
            .testTag(item.tag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(item.icon, contentDescription = item.title, tint = JarvisGoldBright, modifier = Modifier.size(24.dp))
            Spacer(Modifier.height(6.dp))
            Text(
                text = item.title,
                style = MaterialTheme.typography.labelSmall,
                color = TextGoldPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun WeatherMiniCard(
    weatherState: WeatherUiState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    HudPanelCard(
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag("weather_mini_card")
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Cloud, contentDescription = "Clima", tint = JarvisGoldBright, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("CLIMA", style = MaterialTheme.typography.labelLarge, color = JarvisGold)
        }
        Spacer(Modifier.height(6.dp))
        when (weatherState) {
            is WeatherUiState.Success -> {
                Text(
                    text = "${weatherState.report.temperatureC.toInt()}°C",
                    style = MaterialTheme.typography.headlineLarge,
                    color = TextGoldPrimary
                )
                Text(
                    text = "${weatherState.report.conditionDescription} • Chuva ${weatherState.report.rainProbabilityPercent}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextGoldSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            is WeatherUiState.Loading -> Text("Atualizando...", style = MaterialTheme.typography.bodyMedium, color = TextGoldSecondary)
            is WeatherUiState.Error -> Text("Toque p/ tentar", style = MaterialTheme.typography.bodyMedium, color = HoloCrimson)
            WeatherUiState.Idle -> Text("Toque para carregar", style = MaterialTheme.typography.bodyMedium, color = TextGoldSecondary)
        }
    }
}

@Composable
private fun NextAlarmMiniCard(
    alarms: List<AlarmEntity>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val next = alarms.firstOrNull { it.enabled }
    HudPanelCard(
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag("alarm_mini_card")
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Alarm, contentDescription = "Alarme", tint = JarvisGoldBright, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("ALARME", style = MaterialTheme.typography.labelLarge, color = JarvisGold)
        }
        Spacer(Modifier.height(6.dp))
        if (next != null) {
            Text(
                text = String.format(Locale.getDefault(), "%02d:%02d", next.hour, next.minute),
                style = MaterialTheme.typography.headlineLarge,
                color = TextGoldPrimary
            )
            Text(
                text = next.label,
                style = MaterialTheme.typography.labelSmall,
                color = TextGoldSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        } else {
            Text("Nenhum ativo", style = MaterialTheme.typography.bodyMedium, color = TextGoldSecondary)
            Text("Criar despertador", style = MaterialTheme.typography.labelSmall, color = JarvisGoldBright)
        }
    }
}

@Composable
private fun MusicMiniCard(
    musicState: PlaybackUiState,
    onClick: () -> Unit
) {
    HudPanelCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("music_mini_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.MusicNote, contentDescription = "Música", tint = JarvisGoldBright)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        text = musicState.currentTrack?.title ?: "Reprodutor de Áudio JARVIS",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextGoldPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = musicState.currentTrack?.artist ?: "Toque para selecionar músicas",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextGoldSecondary,
                        maxLines = 1
                    )
                }
            }
            HudStatusPill(
                label = if (musicState.isPlaying) "TOCANDO" else "PAUSADO",
                color = if (musicState.isPlaying) HoloEmerald else JarvisGold
            )
        }
    }
}
