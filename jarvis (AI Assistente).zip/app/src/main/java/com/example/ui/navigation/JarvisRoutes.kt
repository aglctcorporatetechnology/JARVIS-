package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
data object HudHomeRoute

@Serializable
data object AiChatRoute

@Serializable
data object JarvisVoiceRoute

@Serializable
data object WeatherRoute

@Serializable
data class MapsTrafficRoute(val initialTab: String = "maps")

@Serializable
data object AlarmsRoute

@Serializable
data object MusicPlayerRoute

@Serializable
data object CommandHubRoute

@Serializable
data object SettingsRoute

@Serializable
data object DeviceInstallRoute
