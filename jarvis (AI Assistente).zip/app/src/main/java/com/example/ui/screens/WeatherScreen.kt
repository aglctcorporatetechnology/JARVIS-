package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.ui.WeatherUiState
import com.example.ui.components.HudPanelCard
import com.example.ui.components.HudScreenTopBar
import com.example.ui.theme.HoloCrimson
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianPanel
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextGoldPrimary
import com.example.ui.theme.TextGoldSecondary

@Composable
fun WeatherScreen(
    weatherState: WeatherUiState,
    onBack: () -> Unit,
    onRefreshGps: () -> Unit,
    onSearchCity: (String) -> Unit,
    onAskJarvis: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var cityInput by remember { mutableStateOf("") }

    val locationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        onRefreshGps()
    }

    LaunchedEffect(Unit) {
        if (weatherState is WeatherUiState.Idle) {
            val hasLoc = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (hasLoc) {
                onRefreshGps()
            } else {
                locationLauncher.launch(
                    arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
                )
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PitchBlack)
    ) {
        HudScreenTopBar(
            title = "Clima & Previsão",
            subtitle = "TELEMETRIA METEOROLÓGICA EM TEMPO REAL",
            onBack = onBack,
            trailingAction = {
                IconButton(
                    onClick = {
                        val hasLoc = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        if (hasLoc) onRefreshGps()
                        else locationLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                    },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("weather_gps_button")
                ) {
                    Icon(Icons.Default.MyLocation, contentDescription = "Atualizar por GPS", tint = JarvisGoldBright)
                }
            }
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = cityInput,
                onValueChange = { cityInput = it },
                placeholder = { Text("Buscar cidade (ex: São Paulo, Rio)...", color = TextGoldSecondary) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearchCity(cityInput) }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = JarvisGoldBright,
                    unfocusedBorderColor = JarvisGoldBorder,
                    focusedTextColor = TextGoldPrimary,
                    unfocusedTextColor = TextGoldPrimary,
                    focusedContainerColor = ObsidianPanel,
                    unfocusedContainerColor = ObsidianPanel
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f).testTag("weather_city_input")
            )
            IconButton(
                onClick = { onSearchCity(cityInput) },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("weather_search_button")
            ) {
                Icon(Icons.Default.Search, contentDescription = "Buscar cidade", tint = JarvisGoldBright)
            }
        }

        // Voice quick prompts
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AssistChip(
                onClick = { onAskJarvis("JARVIS, vai chover hoje?") },
                label = { Text("Vai chover hoje?", color = JarvisGoldBright) },
                modifier = Modifier.testTag("weather_ask_rain")
            )
            AssistChip(
                onClick = { onAskJarvis("JARVIS, como estará o tempo amanhã?") },
                label = { Text("Tempo amanhã?", color = JarvisGoldBright) },
                modifier = Modifier.testTag("weather_ask_tomorrow")
            )
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            when (weatherState) {
                WeatherUiState.Idle, WeatherUiState.Loading -> {
                    item {
                        HudPanelCard(modifier = Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                CircularProgressIndicator(color = JarvisGoldBright, modifier = Modifier.size(28.dp))
                                Text("Coletando dados atmosféricos, senhor...", style = MaterialTheme.typography.bodyLarge, color = TextGoldPrimary)
                            }
                        }
                    }
                }
                is WeatherUiState.Error -> {
                    item {
                        HudPanelCard(modifier = Modifier.fillMaxWidth(), accentColor = HoloCrimson) {
                            Text("Falha Meteorológica", style = MaterialTheme.typography.titleMedium, color = HoloCrimson)
                            Spacer(Modifier.height(4.dp))
                            Text(weatherState.message, style = MaterialTheme.typography.bodyMedium, color = TextGoldPrimary)
                        }
                    }
                }
                is WeatherUiState.Success -> {
                    val r = weatherState.report
                    item {
                        HudPanelCard(modifier = Modifier.fillMaxWidth()) {
                            Text(r.locationName.uppercase(), style = MaterialTheme.typography.labelLarge, color = JarvisGold)
                            Spacer(Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("${r.temperatureC.toInt()}°C", style = MaterialTheme.typography.displayLarge, color = JarvisGoldBright)
                                    Text(r.conditionDescription, style = MaterialTheme.typography.titleMedium, color = TextGoldPrimary)
                                    Text("Sensação térmica: ${r.feelsLikeC.toInt()}°C", style = MaterialTheme.typography.bodyMedium, color = TextGoldSecondary)
                                }
                                Icon(Icons.Default.Cloud, contentDescription = r.conditionDescription, tint = JarvisGoldBright, modifier = Modifier.size(56.dp))
                            }
                            Spacer(Modifier.height(14.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                WeatherStatPill(Icons.Default.WaterDrop, "Chuva", "${r.rainProbabilityPercent}%", HoloCyan)
                                WeatherStatPill(Icons.Default.Cloud, "Umidade", "${r.humidityPercent}%", JarvisGoldBright)
                                WeatherStatPill(Icons.Default.Air, "Vento", "${r.windKmh.toInt()} km/h", JarvisGold)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("Fonte: ${r.providerUsed}", style = MaterialTheme.typography.labelSmall, color = TextGoldSecondary)
                        }
                    }

                    item {
                        Text("PREVISÃO PARA HOJE (HORA A HORA)", style = MaterialTheme.typography.labelLarge, color = JarvisGold)
                        Spacer(Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(r.todayHourly) { hour ->
                                Surface(
                                    color = ObsidianCard,
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, JarvisGoldBorder),
                                    modifier = Modifier.width(88.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(10.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(hour.timeLabel, style = MaterialTheme.typography.labelSmall, color = TextGoldSecondary)
                                        Spacer(Modifier.height(4.dp))
                                        Text("${hour.temperatureC}°C", style = MaterialTheme.typography.titleMedium, color = JarvisGoldBright)
                                        Spacer(Modifier.height(2.dp))
                                        Text("${hour.rainProbability}% chuva", style = MaterialTheme.typography.labelSmall, color = HoloCyan)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Text("PRÓXIMOS DIAS", style = MaterialTheme.typography.labelLarge, color = JarvisGold)
                    }

                    items(r.weeklyForecast) { day ->
                        Surface(
                            color = ObsidianCard,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, JarvisGoldBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(day.dateLabel, style = MaterialTheme.typography.titleMedium, color = TextGoldPrimary)
                                    Text(day.conditionLabel, style = MaterialTheme.typography.labelSmall, color = TextGoldSecondary)
                                }
                                Text("${day.rainProbability}% chuva", style = MaterialTheme.typography.labelMedium, color = HoloCyan)
                                Spacer(Modifier.width(12.dp))
                                Text("${day.minTempC}° / ${day.maxTempC}°", style = MaterialTheme.typography.titleMedium, color = JarvisGoldBright)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WeatherStatPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    tint: androidx.compose.ui.graphics.Color
) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(18.dp))
        Column {
            Text(label, style = MaterialTheme.typography.labelSmall, color = TextGoldSecondary)
            Text(value, style = MaterialTheme.typography.titleMedium, color = TextGoldPrimary)
        }
    }
}
