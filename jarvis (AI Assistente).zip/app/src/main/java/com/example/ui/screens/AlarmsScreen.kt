package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimeInput
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.alarm.AlarmScheduler
import com.example.data.local.AlarmEntity
import com.example.data.local.MusicTrackEntity
import com.example.ui.components.HudPanelCard
import com.example.ui.components.HudScreenTopBar
import com.example.ui.theme.HoloCrimson
import com.example.ui.theme.HoloWarning
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianPanel
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextGoldPrimary
import com.example.ui.theme.TextGoldSecondary
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun AlarmsScreen(
    alarms: List<AlarmEntity>,
    musicTracks: List<MusicTrackEntity>,
    defaultAlarmVolume: Float,
    onBack: () -> Unit,
    onSaveAlarm: (AlarmEntity) -> Unit,
    onToggleAlarm: (AlarmEntity, Boolean) -> Unit,
    onDeleteAlarm: (AlarmEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val canExact = remember { AlarmScheduler(context).canScheduleExactAlarms() }
    var showCreateDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = PitchBlack,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = JarvisGold,
                contentColor = PitchBlack,
                modifier = Modifier.testTag("add_alarm_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Novo alarme")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            HudScreenTopBar(
                title = "Despertador Inteligente",
                subtitle = "ALARMES EXATOS • VOZ DO JARVIS + MÚSICA",
                onBack = onBack
            )

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                if (!canExact && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    item {
                        HudPanelCard(accentColor = HoloWarning) {
                            Text("Permissão de Alarmes Exatos Necessária", style = MaterialTheme.typography.titleMedium, color = HoloWarning)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Para garantir que o JARVIS desperte no segundo exato, autorize alarmes exatos nas configurações do sistema.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextGoldPrimary
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    runCatching {
                                        context.startActivity(
                                            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                                data = Uri.parse("package:${context.packageName}")
                                            }
                                        )
                                    }
                                },
                                border = BorderStroke(1.dp, HoloWarning)
                            ) {
                                Text("Autorizar Alarmes Exatos", color = HoloWarning)
                            }
                        }
                    }
                }

                if (alarms.isEmpty()) {
                    item {
                        HudPanelCard(modifier = Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Alarm, contentDescription = null, tint = JarvisGoldBright)
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text("Nenhum despertador programado", style = MaterialTheme.typography.titleMedium, color = TextGoldPrimary)
                                    Text(
                                        "Toque no botão + ou peça ao JARVIS: \"Acorde-me às 07:00\".",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextGoldSecondary
                                    )
                                }
                            }
                        }
                    }
                }

                items(alarms, key = { it.id }) { alarm ->
                    HudPanelCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = String.format(Locale.getDefault(), "%02d:%02d", alarm.hour, alarm.minute),
                                    style = MaterialTheme.typography.displayMedium,
                                    color = if (alarm.enabled) JarvisGoldBright else TextGoldSecondary
                                )
                                Text(alarm.label, style = MaterialTheme.typography.titleMedium, color = TextGoldPrimary)
                                Text(
                                    text = buildString {
                                        append(formatDaysCsv(alarm.daysOfWeekCsv))
                                        append(" • ")
                                        append(alarm.soundTitle)
                                        if (alarm.speakJarvisGreeting) append(" • Voz JARVIS")
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextGoldSecondary
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Switch(
                                    checked = alarm.enabled,
                                    onCheckedChange = { onToggleAlarm(alarm, it) },
                                    colors = SwitchDefaults.colors(checkedThumbColor = PitchBlack, checkedTrackColor = JarvisGold)
                                )
                                IconButton(onClick = { onDeleteAlarm(alarm) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Excluir alarme", tint = HoloCrimson)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateAlarmDialog(
            musicTracks = musicTracks,
            defaultVolume = defaultAlarmVolume,
            onDismiss = { showCreateDialog = false },
            onConfirm = { newAlarm ->
                onSaveAlarm(newAlarm)
                showCreateDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreateAlarmDialog(
    musicTracks: List<MusicTrackEntity>,
    defaultVolume: Float,
    onDismiss: () -> Unit,
    onConfirm: (AlarmEntity) -> Unit
) {
    val context = LocalContext.current
    val timeState = rememberTimePickerState(initialHour = 7, initialMinute = 0, is24Hour = true)
    var label by remember { mutableStateOf("Despertar JARVIS") }
    var selectedDays by remember { mutableStateOf(setOf(1, 2, 3, 4, 5)) }
    var repeatWeekly by remember { mutableStateOf(true) }
    var speakGreeting by remember { mutableStateOf(true) }
    var soundUri by remember { mutableStateOf("") }
    var soundTitle by remember { mutableStateOf("Toque Padrão do Sistema") }
    var volume by remember { mutableFloatStateOf(defaultVolume) }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            soundUri = uri.toString()
            soundTitle = uri.lastPathSegment ?: "Áudio do Dispositivo"
        }
    }

    val dayLabels = listOf(1 to "Seg", 2 to "Ter", 3 to "Qua", 4 to "Qui", 5 to "Sex", 6 to "Sáb", 7 to "Dom")

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ObsidianPanel,
        title = { Text("Novo Despertador Inteligente", color = JarvisGoldBright) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TimeInput(state = timeState)
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Rótulo do alarme") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Dias da semana", style = MaterialTheme.typography.labelLarge, color = JarvisGold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    dayLabels.forEach { (num, name) ->
                        val active = num in selectedDays
                        FilterChip(
                            selected = active,
                            onClick = {
                                selectedDays = if (active) selectedDays - num else selectedDays + num
                            },
                            label = { Text(name, style = MaterialTheme.typography.labelSmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = JarvisGold,
                                selectedLabelColor = PitchBlack
                            )
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Repetir semanalmente", color = TextGoldPrimary)
                    Switch(checked = repeatWeekly, onCheckedChange = { repeatWeekly = it })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Falar: \"Bom dia, senhor...\"", color = TextGoldPrimary)
                    Switch(checked = speakGreeting, onCheckedChange = { speakGreeting = it })
                }
                Text("Som / Música: $soundTitle", style = MaterialTheme.typography.labelMedium, color = JarvisGoldBright)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { audioPicker.launch(arrayOf("audio/*")) },
                        border = BorderStroke(1.dp, JarvisGoldBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = JarvisGoldBright)
                        Spacer(Modifier.width(4.dp))
                        Text("Escolher Áudio", color = JarvisGoldBright)
                    }
                    if (musicTracks.isNotEmpty()) {
                        OutlinedButton(
                            onClick = {
                                val first = musicTracks.first()
                                soundUri = first.uriString
                                soundTitle = first.title
                            },
                            border = BorderStroke(1.dp, JarvisGoldBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Usar Biblioteca", color = TextGoldPrimary)
                        }
                    }
                }
                Text("Volume do alarme: ${(volume * 100).roundToInt()}%", color = TextGoldPrimary)
                Slider(value = volume, onValueChange = { volume = it }, valueRange = 0.2f..1f)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(
                        AlarmEntity(
                            hour = timeState.hour,
                            minute = timeState.minute,
                            label = label.ifBlank { "Despertador JARVIS" },
                            enabled = true,
                            daysOfWeekCsv = selectedDays.sorted().joinToString(","),
                            repeatWeekly = repeatWeekly,
                            speakJarvisGreeting = speakGreeting,
                            soundUri = soundUri,
                            soundTitle = soundTitle,
                            volume = volume
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = JarvisGold, contentColor = PitchBlack),
                modifier = Modifier.testTag("confirm_save_alarm_button")
            ) {
                Text("Ativar Alarme")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TextGoldSecondary)
            }
        }
    )
}

private fun formatDaysCsv(csv: String): String {
    if (csv.isBlank()) return "Uma vez"
    val map = mapOf(1 to "Seg", 2 to "Ter", 3 to "Qua", 4 to "Qui", 5 to "Sex", 6 to "Sáb", 7 to "Dom")
    val days = csv.split(",").mapNotNull { it.trim().toIntOrNull() }.mapNotNull { map[it] }
    return if (days.size == 7) "Todos os dias" else days.joinToString(", ")
}
