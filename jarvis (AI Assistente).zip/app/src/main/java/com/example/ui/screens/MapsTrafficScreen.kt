package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.maps.PlaceSearchResult
import com.example.ui.MapsUiState
import com.example.ui.components.HudPanelCard
import com.example.ui.components.HudScreenTopBar
import com.example.ui.components.InteractiveRouteMapCanvas
import com.example.ui.theme.HoloCrimson
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.HoloEmerald
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianPanel
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextGoldPrimary
import com.example.ui.theme.TextGoldSecondary
import java.util.Locale

@Composable
fun MapsTrafficScreen(
    initialTab: String,
    mapsState: MapsUiState,
    hasGoogleTrafficKey: Boolean,
    onBack: () -> Unit,
    onRefreshLocation: () -> Unit,
    onSearchPlaces: (String) -> Unit,
    onSelectDestination: (PlaceSearchResult) -> Unit,
    onSelectRoute: (Int) -> Unit,
    onAskJarvis: (String) -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var activeTab by remember(initialTab) { mutableStateOf(initialTab) }
    var searchQuery by remember { mutableStateOf("") }

    val locPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        onRefreshLocation()
    }

    LaunchedEffect(Unit) {
        if (mapsState.currentLocation == null) {
            val hasLoc = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (hasLoc) onRefreshLocation()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PitchBlack)
    ) {
        HudScreenTopBar(
            title = when (activeTab) {
                "traffic" -> "Trânsito em Tempo Real"
                "highways" -> "Rodovias & Rotas"
                else -> "Mapas & Navegação"
            },
            subtitle = if (hasGoogleTrafficKey) "GOOGLE ROUTES TRAFFIC + OSRM ATIVO" else "OSRM + NOMINATIM + GOOGLE MAPS INTENT",
            onBack = onBack,
            trailingAction = {
                IconButton(
                    onClick = {
                        val hasLoc = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        if (hasLoc) onRefreshLocation()
                        else locPermissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                    },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("maps_gps_button")
                ) {
                    Icon(Icons.Default.MyLocation, contentDescription = "Minha localização", tint = JarvisGoldBright)
                }
            }
        )

        // Sub-mode tabs (Mapas / Trânsito / Rodovias)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "maps" to ("Mapas" to Icons.Default.Map),
                "traffic" to ("Trânsito" to Icons.Default.Traffic),
                "highways" to ("Rodovias" to Icons.Default.DirectionsCar)
            ).forEach { (key, meta) ->
                FilterChip(
                    selected = activeTab == key,
                    onClick = { activeTab = key },
                    leadingIcon = { Icon(meta.second, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text(meta.first) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = JarvisGold,
                        selectedLabelColor = PitchBlack
                    )
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Buscar endereço, lugar ou rodovia (ex: Rodovia Anhanguera)...", color = TextGoldSecondary) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearchPlaces(searchQuery) }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = JarvisGoldBright,
                    unfocusedBorderColor = JarvisGoldBorder,
                    focusedTextColor = TextGoldPrimary,
                    unfocusedTextColor = TextGoldPrimary,
                    focusedContainerColor = ObsidianPanel,
                    unfocusedContainerColor = ObsidianPanel
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f).testTag("maps_search_input")
            )
            IconButton(
                onClick = { onSearchPlaces(searchQuery) },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("maps_search_button")
            ) {
                Icon(Icons.Default.Search, contentDescription = "Pesquisar endereço", tint = JarvisGoldBright)
            }
        }

        if (mapsState.isLoading) {
            LinearProgressIndicator(
                color = JarvisGoldBright,
                trackColor = ObsidianCard,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Interactive Tactical HUD Map
            item {
                InteractiveRouteMapCanvas(
                    origin = mapsState.currentLocation,
                    destination = mapsState.selectedDestination,
                    routes = mapsState.routes,
                    selectedRouteIndex = mapsState.selectedRouteIndex,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                )
                Spacer(Modifier.height(6.dp))
                mapsState.currentLocation?.let { loc ->
                    Text(
                        text = String.format(Locale.US, "Posição Atual: %.4f, %.4f", loc.latitude, loc.longitude),
                        style = MaterialTheme.typography.labelSmall,
                        color = HoloEmerald
                    )
                }
            }

            // Voice Quick Actions
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(
                        onClick = { onAskJarvis("JARVIS, mostre o trânsito e possíveis congestionamentos na minha região.") },
                        label = { Text("Consultar Trânsito", color = JarvisGoldBright) }
                    )
                    AssistChip(
                        onClick = { onAskJarvis("JARVIS, como está a situação das principais rodovias próximas?") },
                        label = { Text("Status Rodovias", color = JarvisGoldBright) }
                    )
                }
            }

            if (mapsState.errorMessage != null) {
                item {
                    HudPanelCard(accentColor = HoloCrimson) {
                        Text(mapsState.errorMessage, style = MaterialTheme.typography.bodyMedium, color = HoloCrimson)
                    }
                }
            }

            if (!hasGoogleTrafficKey) {
                item {
                    HudPanelCard {
                        Text("DADOS DE CONGESTIONAMENTO AO VIVO", style = MaterialTheme.typography.labelLarge, color = JarvisGoldBright)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Rotas e distâncias funcionam imediatamente via OSRM. Para telemetria ao vivo de congestionamentos no painel, informe sua chave Google Routes API nas Configurações ou abra o Google Maps.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextGoldSecondary
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = onOpenSettings,
                                border = BorderStroke(1.dp, JarvisGoldBorder),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Configurar API", color = JarvisGoldBright)
                            }
                            Button(
                                onClick = {
                                    val dest = mapsState.selectedDestination
                                    val uri = if (dest != null) {
                                        Uri.parse("google.navigation:q=${dest.latitude},${dest.longitude}")
                                    } else {
                                        val cur = mapsState.currentLocation
                                        if (cur != null) Uri.parse("geo:${cur.latitude},${cur.longitude}?z=14")
                                        else Uri.parse("geo:0,0?q=transito")
                                    }
                                    runCatching {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = JarvisGold, contentColor = PitchBlack),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Directions, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Abrir Maps")
                            }
                        }
                    }
                }
            }

            // Place search results
            if (mapsState.searchResults.isNotEmpty()) {
                item {
                    Text("ENDEREÇOS E LOCAIS ENCONTRADOS (TOQUE PARA TRAÇAR ROTA)", style = MaterialTheme.typography.labelLarge, color = JarvisGold)
                }
                items(mapsState.searchResults) { place ->
                    Surface(
                        color = ObsidianCard,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, JarvisGoldBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectDestination(place) }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(place.displayName, style = MaterialTheme.typography.titleMedium, color = TextGoldPrimary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("Categoria: ${place.category}", style = MaterialTheme.typography.labelSmall, color = HoloCyan)
                        }
                    }
                }
            }

            // Calculated Routes & Alternatives
            if (mapsState.routes.isNotEmpty()) {
                item {
                    Text("ROTAS CALCULADAS & ALTERNATIVAS", style = MaterialTheme.typography.labelLarge, color = JarvisGold)
                }
                items(mapsState.routes) { route ->
                    val isSelected = route.index == mapsState.selectedRouteIndex
                    Surface(
                        color = if (isSelected) ObsidianPanel else ObsidianCard,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) HoloCyan else JarvisGoldBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectRoute(route.index) }
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (route.index == 0) "MAIS RÁPIDA: ${route.summary}" else "ALTERNATIVA: ${route.summary}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (isSelected) HoloCyan else JarvisGoldBright,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "${route.durationMinutes} min",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextGoldPrimary
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = String.format(Locale.US, "Distância: %.1f km • %s", route.distanceKm, route.trafficStatus),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextGoldSecondary
                            )
                            if (route.highwayNames.isNotEmpty()) {
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "Rodovias / Vias: ${route.highwayNames.joinToString(", ")}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = JarvisGoldBright
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
