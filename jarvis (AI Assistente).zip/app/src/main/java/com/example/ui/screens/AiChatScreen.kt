package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.ChatMessageEntity
import com.example.ui.AiUiState
import com.example.ui.components.HudScreenTopBar
import com.example.ui.theme.HoloCrimson
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianPanel
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextGoldPrimary
import com.example.ui.theme.TextGoldSecondary

@Composable
fun AiChatScreen(
    messages: List<ChatMessageEntity>,
    aiState: AiUiState,
    modelName: String,
    onBack: () -> Unit,
    onSendMessage: (String, Bitmap?, ByteArray?, String?, String?) -> Unit,
    onSpeakText: (String) -> Unit,
    onMicTap: () -> Unit,
    onClearHistory: () -> Unit,
    onRetry: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var inputText by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    var pendingBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var pendingDocBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pendingDocMime by remember { mutableStateOf<String?>(null) }
    var pendingLabel by remember { mutableStateOf<String?>(null) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val bmp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri))
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                }
                pendingBitmap = bmp
                pendingDocBytes = null
                pendingDocMime = null
                pendingLabel = "Imagem selecionada"
            }
        }
    }

    val documentPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val mime = context.contentResolver.getType(uri) ?: "application/pdf"
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes != null && bytes.size <= 18 * 1024 * 1024) {
                    pendingDocBytes = bytes
                    pendingDocMime = mime
                    pendingBitmap = null
                    val name = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                        ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "Documento"
                    pendingLabel = name
                }
            }
        }
    }

    val filteredMessages = remember(messages, searchQuery) {
        if (searchQuery.isBlank()) messages
        else messages.filter { it.content.contains(searchQuery, ignoreCase = true) }
    }

    val listState = rememberLazyListState()
    LaunchedEffect(filteredMessages.size, aiState) {
        if (filteredMessages.isNotEmpty()) {
            listState.animateScrollToItem(filteredMessages.lastIndex)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PitchBlack)
    ) {
        HudScreenTopBar(
            title = "Inteligência Artificial",
            subtitle = "GEMINI ($modelName) • HISTÓRICO & ANÁLISE",
            onBack = onBack,
            trailingAction = {
                IconButton(
                    onClick = onClearHistory,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("clear_chat_button")
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = "Limpar histórico", tint = HoloCrimson)
                }
            }
        )

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Buscar no histórico de conversas...", color = TextGoldSecondary) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = JarvisGoldBright,
                unfocusedBorderColor = JarvisGoldBorder,
                focusedTextColor = TextGoldPrimary,
                unfocusedTextColor = TextGoldPrimary,
                focusedContainerColor = ObsidianPanel,
                unfocusedContainerColor = ObsidianPanel
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("chat_search_input")
        )

        if (aiState is AiUiState.Thinking || aiState is AiUiState.Streaming) {
            LinearProgressIndicator(
                color = JarvisGoldBright,
                trackColor = ObsidianCard,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }

        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            if (filteredMessages.isEmpty()) {
                item {
                    Surface(
                        color = ObsidianPanel,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, JarvisGoldBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Olá, senhor. Como posso ajudá-lo?", style = MaterialTheme.typography.titleMedium, color = JarvisGoldBright)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Posso responder perguntas, fazer cálculos, resumir textos, analisar imagens ou documentos PDF e executar comandos de voz.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextGoldSecondary
                            )
                        }
                    }
                }
            }

            items(filteredMessages, key = { it.id }) { msg ->
                val isUser = msg.role == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        color = if (isUser) ObsidianCard else ObsidianPanel,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, if (isUser) JarvisGold else JarvisGoldBorder),
                        modifier = Modifier.fillMaxWidth(0.88f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isUser) "SENHOR" else "JARVIS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isUser) HoloCyan else JarvisGoldBright
                                )
                                if (!isUser) {
                                    IconButton(
                                        onClick = { onSpeakText(msg.content) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "Ouvir resposta", tint = JarvisGoldBright, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                            if (!msg.attachmentName.isNullOrBlank()) {
                                Text(
                                    text = "[Anexo: ${msg.attachmentName}]",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = HoloCyan
                                )
                                Spacer(Modifier.height(4.dp))
                            }
                            Text(
                                text = msg.content,
                                style = MaterialTheme.typography.bodyLarge,
                                color = TextGoldPrimary
                            )
                        }
                    }
                }
            }

            if (aiState is AiUiState.Streaming && aiState.partialText.isNotBlank()) {
                item {
                    Surface(
                        color = ObsidianPanel,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, JarvisGoldBright),
                        modifier = Modifier.fillMaxWidth(0.88f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("JARVIS • TRANSMITINDO", style = MaterialTheme.typography.labelSmall, color = JarvisGoldBright)
                            Spacer(Modifier.height(4.dp))
                            Text(aiState.partialText, style = MaterialTheme.typography.bodyLarge, color = TextGoldPrimary)
                        }
                    }
                }
            }

            if (aiState is AiUiState.Error) {
                item {
                    Surface(
                        color = ObsidianPanel,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, HoloCrimson),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("chat_error_card")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ErrorOutline,
                                    contentDescription = "Erro na API Gemini",
                                    tint = HoloCrimson,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "FALHA NA COMUNICAÇÃO COM O GEMINI",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = HoloCrimson
                                )
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = aiState.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextGoldPrimary
                            )
                            if (aiState.canRetry) {
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = onRetry,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = JarvisGold,
                                        contentColor = PitchBlack
                                    ),
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("chat_retry_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Tentar novamente",
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text("Tentar novamente")
                                }
                            }
                        }
                    }
                }
            }
        }

        if (pendingLabel != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianPanel)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Anexo pronto: $pendingLabel", style = MaterialTheme.typography.labelMedium, color = HoloCyan)
                IconButton(
                    onClick = {
                        pendingBitmap = null
                        pendingDocBytes = null
                        pendingDocMime = null
                        pendingLabel = null
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Remover anexo", tint = HoloCrimson)
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(ObsidianPanel)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            IconButton(
                onClick = {
                    imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("attach_image_button")
            ) {
                Icon(Icons.Default.Image, contentDescription = "Anexar imagem", tint = JarvisGoldBright)
            }
            IconButton(
                onClick = {
                    documentPicker.launch(arrayOf("application/pdf", "text/*"))
                },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("attach_doc_button")
            ) {
                Icon(Icons.Default.AttachFile, contentDescription = "Anexar documento", tint = JarvisGoldBright)
            }
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Pergunte ao JARVIS...", color = TextGoldSecondary) },
                maxLines = 3,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = JarvisGoldBright,
                    unfocusedBorderColor = JarvisGoldBorder,
                    focusedTextColor = TextGoldPrimary,
                    unfocusedTextColor = TextGoldPrimary,
                    focusedContainerColor = ObsidianCard,
                    unfocusedContainerColor = ObsidianCard
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_message_input")
            )
            IconButton(
                onClick = onMicTap,
                modifier = Modifier.minimumInteractiveComponentSize().testTag("chat_mic_button")
            ) {
                Icon(Icons.Default.Mic, contentDescription = "Comando de voz", tint = JarvisGoldBright)
            }
            IconButton(
                onClick = {
                    if (inputText.isNotBlank() || pendingBitmap != null || pendingDocBytes != null) {
                        onSendMessage(inputText, pendingBitmap, pendingDocBytes, pendingDocMime, pendingLabel)
                        inputText = ""
                        pendingBitmap = null
                        pendingDocBytes = null
                        pendingDocMime = null
                        pendingLabel = null
                    }
                },
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .clip(CircleShape)
                    .background(JarvisGold)
                    .testTag("chat_send_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Enviar mensagem", tint = PitchBlack)
            }
        }
    }
}
