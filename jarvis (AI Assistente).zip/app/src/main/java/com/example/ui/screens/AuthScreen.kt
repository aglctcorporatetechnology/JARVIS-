package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.auth.attemptAutoSignIn
import com.example.auth.onGoogleSignInClicked
import com.example.ui.components.HudPanelCard
import com.example.ui.components.HudStatusPill
import com.example.ui.components.JarvisCircularCore
import com.example.ui.theme.HoloCrimson
import com.example.ui.theme.HoloEmerald
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.ObsidianPanel
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextGoldPrimary
import com.example.ui.theme.TextGoldSecondary
import com.example.voice.VoiceEngineState

@Composable
fun AuthScreen(
    onAuthSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = {
                isLoading = false
                onAuthSuccess()
            },
            onUnauthenticated = {
                isLoading = false
            },
            scope = coroutineScope
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(ObsidianPanel.copy(alpha = 0.72f), PitchBlack)
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            HudStatusPill(
                label = "CONEXÃO SEGURA // CONTA GOOGLE",
                color = JarvisGoldBright
            )

            JarvisCircularCore(
                state = if (isLoading) VoiceEngineState.PROCESSING else VoiceEngineState.IDLE,
                rmsLevel = 0f,
                glowIntensity = 0.9f,
                onClick = {},
                modifier = Modifier.size(190.dp)
            )

            Text(
                text = "BEM-VINDO AO J.A.R.V.I.S",
                style = MaterialTheme.typography.headlineMedium,
                color = JarvisGoldBright,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Conecte sua conta Google para sincronizar conversas, voz, alarmes e playlists em qualquer smartphone ou tablet Android.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextGoldSecondary,
                textAlign = TextAlign.Center
            )

            HudPanelCard(modifier = Modifier.fillMaxWidth()) {
                SyncFeatureRow(
                    icon = Icons.Default.CloudDone,
                    title = "Nuvem Privada Criptografada",
                    subtitle = "Histórico da IA, palavra de ativação e configurações salvos na sua conta."
                )
                Spacer(Modifier.height(10.dp))
                SyncFeatureRow(
                    icon = Icons.Default.Devices,
                    title = "Multi-Dispositivo Android",
                    subtitle = "Acesse seus alarmes, playlists e contexto do JARVIS em qualquer aparelho."
                )
                Spacer(Modifier.height(10.dp))
                SyncFeatureRow(
                    icon = Icons.Default.Lock,
                    title = "Isolamento por Usuário",
                    subtitle = "Somente sua conta Google autenticada tem acesso aos seus dados."
                )
            }

            if (errorMessage != null) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = HoloCrimson.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, HoloCrimson),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = errorMessage.orEmpty(),
                        style = MaterialTheme.typography.bodySmall,
                        color = HoloCrimson,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            Button(
                onClick = {
                    errorMessage = null
                    isLoading = true
                    onGoogleSignInClicked(
                        context = context,
                        credentialManager = credentialManager,
                        onAuthSuccess = {
                            isLoading = false
                            onAuthSuccess()
                        },
                        onAuthError = { msg ->
                            isLoading = false
                            errorMessage = msg
                        },
                        scope = coroutineScope,
                        onAuthCancelled = {
                            isLoading = false
                        }
                    )
                },
                enabled = !isLoading,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = JarvisGold,
                    contentColor = PitchBlack,
                    disabledContainerColor = JarvisGoldBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .height(54.dp)
                    .testTag("google_sign_in_button")
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = PitchBlack,
                        strokeWidth = 2.5.dp
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = "CONECTANDO...",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text(
                        text = "Entrar com Google",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            HudStatusPill(
                label = "GOOGLE CREDENTIAL MANAGER + CLOUD FIRESTORE",
                color = HoloEmerald
            )
        }
    }
}

@Composable
private fun SyncFeatureRow(
    icon: ImageVector,
    title: String,
    subtitle: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = JarvisGoldBright,
            modifier = Modifier.size(22.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = TextGoldPrimary
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextGoldSecondary
            )
        }
    }
}
