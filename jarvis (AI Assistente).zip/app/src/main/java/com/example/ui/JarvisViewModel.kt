package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.AppContainer
import com.example.JarvisApplication
import com.example.R
import com.example.ai.JarvisAiErrorKind
import com.example.ai.JarvisAiException
import com.example.ai.JarvisCommandAction
import com.example.ai.JarvisGeminiModels
import com.example.ai.ParsedJarvisIntent
import com.example.data.cloud.CloudAlarm
import com.example.data.cloud.CloudChatMessage
import com.example.data.cloud.CloudPlaylist
import com.example.data.cloud.JarvisCloudRepository
import com.example.data.local.AlarmEntity
import com.example.data.local.ChatMessageEntity
import com.example.data.local.MusicTrackEntity
import com.example.data.local.PlaylistEntity
import com.example.data.local.PlaylistTrackCrossRef
import com.example.data.local.PlaylistWithTracks
import com.example.data.preferences.JarvisSettings
import com.example.maps.GeoPoint
import com.example.maps.PlaceSearchResult
import com.example.maps.RouteOption
import com.example.music.PlaybackUiState
import com.example.voice.JarvisVoiceOption
import com.example.voice.VoiceEngineState
import com.example.weather.WeatherReport
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

sealed interface AiUiState {
    data object Idle : AiUiState
    data object Thinking : AiUiState
    data class Streaming(val partialText: String) : AiUiState
    data class Success(val finalText: String) : AiUiState
    data class Error(val message: String, val canRetry: Boolean = true) : AiUiState
}

private data class PendingAiRequest(
    val utterance: String,
    val speakReply: Boolean,
    val imageBitmap: Bitmap?,
    val documentBytes: ByteArray?,
    val documentMimeType: String?,
    val attachmentLabel: String?
)

sealed interface WeatherUiState {
    data object Idle : WeatherUiState
    data object Loading : WeatherUiState
    data class Success(val report: WeatherReport) : WeatherUiState
    data class Error(val message: String) : WeatherUiState
}

data class MapsUiState(
    val currentLocation: GeoPoint? = null,
    val selectedDestination: GeoPoint? = null,
    val searchResults: List<PlaceSearchResult> = emptyList(),
    val routes: List<RouteOption> = emptyList(),
    val selectedRouteIndex: Int = 0,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

sealed interface VoiceNavigationTarget {
    data object Weather : VoiceNavigationTarget
    data class Maps(val tab: String) : VoiceNavigationTarget
    data object Alarms : VoiceNavigationTarget
    data object Music : VoiceNavigationTarget
    data object VoiceSettings : VoiceNavigationTarget
    data object Settings : VoiceNavigationTarget
    data object DeviceInstall : VoiceNavigationTarget
}

class JarvisViewModel(
    private val container: AppContainer,
    private val cloudRepo: JarvisCloudRepository,
    val currentUserId: String,
    val currentUserDisplayName: String?,
    val currentUserEmail: String?,
    private val onToggleVoiceService: (Boolean) -> Unit
) : ViewModel() {

    private val prefs = container.preferences
    private val chatDao = container.database.chatDao()
    private val alarmDao = container.database.alarmDao()
    private val musicDao = container.database.musicDao()
    private val aiRegistry = container.aiRegistry
    private val weatherRepo = container.weatherRepository
    private val mapsRepo = container.mapsRepository
    private val alarmScheduler = container.alarmScheduler
    val voiceManager = container.voiceManager
    val musicController = container.musicController

    private val cloudAlarmIdByLocalId = mutableMapOf<Long, String>()
    private val localSoundUriByCloudAlarmId = mutableMapOf<String, String>()
    private val cloudPlaylistIdByName = mutableMapOf<String, String>()

    private val _cloudSyncError = MutableStateFlow<String?>(null)
    val cloudSyncError: StateFlow<String?> = _cloudSyncError.asStateFlow()

    val settings: StateFlow<JarvisSettings> = prefs.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, JarvisSettings())

    val chatMessages: StateFlow<List<ChatMessageEntity>> = cloudRepo.observeMessages(currentUserId)
        .map { cloudList ->
            _cloudSyncError.value = null
            cloudList.map { msg -> msg.toLocalEntity() }
        }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing cloud messages", rootError)
            _cloudSyncError.value = rootError.localizedMessage
            emit(chatDao.getMessagesSnapshot())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), emptyList())

    val alarms: StateFlow<List<AlarmEntity>> = cloudRepo.observeAlarms(currentUserId)
        .map { cloudList ->
            _cloudSyncError.value = null
            cloudList.map { cloudAlarm ->
                val localId = stableLocalId(cloudAlarm.id)
                cloudAlarmIdByLocalId[localId] = cloudAlarm.id
                cloudAlarm.toLocalEntity(localId, localSoundUriByCloudAlarmId[cloudAlarm.id].orEmpty())
            }
        }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing cloud alarms", rootError)
            _cloudSyncError.value = rootError.localizedMessage
            emit(alarmDao.getEnabledAlarms())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), emptyList())

    val tracks: StateFlow<List<MusicTrackEntity>> = musicDao.getAllTracks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), emptyList())

    val playlists: StateFlow<List<PlaylistWithTracks>> = musicDao.getPlaylistsWithTracks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), emptyList())

    val voiceEngineState: StateFlow<VoiceEngineState> = voiceManager.engineState
    val rmsLevel: StateFlow<Float> = voiceManager.rmsLevel
    val partialTranscript: StateFlow<String> = voiceManager.partialTranscript
    val availableVoices: StateFlow<List<JarvisVoiceOption>> = voiceManager.availableVoices
    val voiceStatusMessage: StateFlow<String> = voiceManager.statusMessage
    val musicState: StateFlow<PlaybackUiState> = musicController.state

    private var activeAiJob: Job? = null
    private var lastPendingRequest: PendingAiRequest? = null

    private val _aiState = MutableStateFlow<AiUiState>(AiUiState.Idle)
    val aiState: StateFlow<AiUiState> = _aiState.asStateFlow()

    private val _weatherState = MutableStateFlow<WeatherUiState>(WeatherUiState.Idle)
    val weatherState: StateFlow<WeatherUiState> = _weatherState.asStateFlow()

    private val _mapsState = MutableStateFlow(MapsUiState())
    val mapsState: StateFlow<MapsUiState> = _mapsState.asStateFlow()

    private val _voiceNavEvents = MutableSharedFlow<VoiceNavigationTarget>(extraBufferCapacity = 8)
    val voiceNavEvents: SharedFlow<VoiceNavigationTarget> = _voiceNavEvents.asSharedFlow()

    private val _uiNotice = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val uiNotice: SharedFlow<String> = _uiNotice.asSharedFlow()

    init {
        viewModelScope.launch {
            val initial = prefs.settings.first()
            cloudRepo.ensureUserProfile(currentUserDisplayName, currentUserEmail, initial)
        }

        // Observe synced cloud profile -> apply to local DataStore settings
        viewModelScope.launch {
            cloudRepo.observeProfile(currentUserId)
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    Log.w(TAG, "Error observing cloud profile", firestoreError ?: error)
                }
                .collect { profile ->
                    if (profile != null) {
                        val current = settings.value
                        val nextRate = profile.speechRate.toFloat()
                        val nextPitch = profile.speechPitch.toFloat()
                        val nextVol = profile.assistantVolume.toFloat()
                        val nextGlow = profile.hudGlowIntensity.toFloat()
                        val nextAlarmVol = profile.alarmVolume.toFloat()
                        val changed = current.wakeWord != profile.wakeWord ||
                            current.languageTag != profile.languageTag ||
                            current.speechRate != nextRate ||
                            current.speechPitch != nextPitch ||
                            current.assistantVolume != nextVol ||
                            current.geminiModelName != profile.geminiModelName ||
                            current.hudGlowIntensity != nextGlow ||
                            current.globeAnimationEnabled != profile.globeAnimationEnabled ||
                            current.defaultSnoozeMinutes != profile.defaultSnoozeMinutes ||
                            current.alarmVolume != nextAlarmVol
                        if (changed) {
                            prefs.applyCloudProfile(
                                wakeWord = profile.wakeWord,
                                languageTag = profile.languageTag,
                                speechRate = nextRate,
                                speechPitch = nextPitch,
                                assistantVolume = nextVol,
                                geminiModelName = profile.geminiModelName,
                                hudGlowIntensity = nextGlow,
                                globeAnimationEnabled = profile.globeAnimationEnabled,
                                defaultSnoozeMinutes = profile.defaultSnoozeMinutes,
                                alarmVolume = nextAlarmVol
                            )
                        }
                    }
                }
        }

        // Keep device AlarmManager synced with cloud alarms across Android devices
        viewModelScope.launch {
            alarms.collect { syncedAlarms ->
                syncedAlarms.forEach { alarm ->
                    if (alarm.enabled) {
                        alarmScheduler.scheduleAlarm(alarm)
                    } else {
                        alarmScheduler.cancelAlarm(alarm.id)
                    }
                }
            }
        }

        // Sync cloud playlists into local Room playlist list
        viewModelScope.launch {
            cloudRepo.observePlaylists(currentUserId)
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    Log.w(TAG, "Error observing cloud playlists", firestoreError ?: error)
                }
                .collect { cloudPlaylists ->
                    syncCloudPlaylistsIntoLocal(cloudPlaylists)
                }
        }

        viewModelScope.launch {
            settings.collect { current ->
                voiceManager.updateSettings(current)
            }
        }
        viewModelScope.launch {
            tracks.collect { list ->
                musicController.updateQueue(list)
            }
        }
        viewModelScope.launch {
            voiceManager.recognizedCommands.collect { utterance ->
                handleUserMessage(utterance = utterance, speakReply = true)
            }
        }
    }

    private suspend fun syncCloudPlaylistsIntoLocal(cloudPlaylists: List<CloudPlaylist>) {
        val localPlaylists = musicDao.getPlaylistsWithTracks().first().map { it.playlist }
        val localByName = localPlaylists.associateBy { it.name.lowercase(Locale.getDefault()) }
        cloudPlaylists.forEach { cp ->
            val key = cp.name.lowercase(Locale.getDefault())
            cloudPlaylistIdByName[key] = cp.id
            if (!localByName.containsKey(key)) {
                musicDao.insertPlaylist(
                    PlaylistEntity(
                        name = cp.name,
                        createdAt = cp.createdAt?.toDate()?.time ?: System.currentTimeMillis()
                    )
                )
            }
        }
    }

    fun handleUserMessage(
        utterance: String,
        speakReply: Boolean = true,
        imageBitmap: Bitmap? = null,
        documentBytes: ByteArray? = null,
        documentMimeType: String? = null,
        attachmentLabel: String? = null,
        isRetry: Boolean = false
    ) {
        val cleanText = utterance.trim()
        if (cleanText.isBlank() && imageBitmap == null && documentBytes == null) return

        lastPendingRequest = PendingAiRequest(
            utterance = cleanText,
            speakReply = speakReply,
            imageBitmap = imageBitmap,
            documentBytes = documentBytes,
            documentMimeType = documentMimeType,
            attachmentLabel = attachmentLabel
        )

        activeAiJob?.cancel()
        activeAiJob = viewModelScope.launch {
            _aiState.value = AiUiState.Thinking
            val userContent = cleanText.ifBlank { "Analise este arquivo anexado, por favor." }

            val historyBefore = if (isRetry) {
                val snapshot = chatMessages.value
                if (snapshot.lastOrNull()?.let { it.role == "user" && it.content.trim() == userContent } == true) {
                    snapshot.dropLast(1)
                } else {
                    snapshot
                }
            } else {
                val snapshot = chatMessages.value
                val userMsg = ChatMessageEntity(
                    role = "user",
                    content = userContent,
                    attachmentName = attachmentLabel
                )
                chatDao.insertMessage(userMsg)
                cloudRepo.addMessage(
                    role = "user",
                    content = userContent,
                    attachmentName = attachmentLabel,
                    messageId = newCloudId("msg")
                )
                snapshot
            }

            val currentSettings = settings.value
            val activeModel = JarvisGeminiModels.normalize(currentSettings.geminiModelName)
            val provider = aiRegistry.getActiveProvider()

            val detectedIntent = if (imageBitmap == null && documentBytes == null && cleanText.isNotBlank()) {
                provider.detectCommandIntent(activeModel, cleanText)
            } else {
                ParsedJarvisIntent()
            }

            val liveContext = executeCommandIntentAndBuildContext(detectedIntent, currentSettings)

            try {
                val promptToSend = cleanText.ifBlank { "Analise o anexo em detalhes e resuma em português." }
                var latestResponse = ""
                provider.streamResponse(
                    modelName = activeModel,
                    history = historyBefore,
                    userPrompt = promptToSend,
                    imageBitmap = imageBitmap,
                    documentBytes = documentBytes,
                    documentMimeType = documentMimeType,
                    contextSummary = liveContext
                ).collect { accumulated ->
                    latestResponse = accumulated
                    if (accumulated.isNotBlank()) {
                        _aiState.value = AiUiState.Streaming(accumulated)
                    }
                }

                if (latestResponse.isBlank()) {
                    val err = "O Google Gemini não retornou resposta para esta solicitação. Tente novamente, senhor."
                    _aiState.value = AiUiState.Error(err, canRetry = true)
                    voiceManager.resetProcessingState()
                } else {
                    chatDao.insertMessage(ChatMessageEntity(role = "model", content = latestResponse))
                    cloudRepo.addMessage(
                        role = "model",
                        content = latestResponse,
                        messageId = newCloudId("msg")
                    )
                    _aiState.value = AiUiState.Success(latestResponse)
                    if (speakReply) {
                        voiceManager.speak(latestResponse)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val aiEx = e as? JarvisAiException
                val msg = aiEx?.message
                    ?: e.localizedMessage
                    ?: "Falha na comunicação com o Google Gemini, senhor."
                val canRetry = aiEx?.retryable ?: (aiEx?.kind != JarvisAiErrorKind.BLOCKED)
                Log.e(TAG, "AI error: $msg", e)
                // Never persist a fake "model" reply when Gemini failed to respond.
                _aiState.value = AiUiState.Error(msg, canRetry = canRetry)
                voiceManager.resetProcessingState()
            }
        }
    }

    fun retryLastMessage() {
        val pending = lastPendingRequest ?: return
        handleUserMessage(
            utterance = pending.utterance,
            speakReply = pending.speakReply,
            imageBitmap = pending.imageBitmap,
            documentBytes = pending.documentBytes,
            documentMimeType = pending.documentMimeType,
            attachmentLabel = pending.attachmentLabel,
            isRetry = true
        )
    }

    private suspend fun executeCommandIntentAndBuildContext(
        intent: ParsedJarvisIntent,
        currentSettings: JarvisSettings
    ): String {
        val sb = StringBuilder()
        when (intent.action) {
            JarvisCommandAction.OPEN_WEATHER -> {
                _voiceNavEvents.tryEmit(VoiceNavigationTarget.Weather)
                runCatching {
                    val report = if (intent.queryParameter.isNotBlank()) {
                        weatherRepo.fetchWeatherByCity(intent.queryParameter, currentSettings.weatherApiKey)
                    } else {
                        val coords = weatherRepo.getCurrentDeviceCoordinates() ?: (-23.5505 to -46.6333)
                        weatherRepo.fetchWeather(coords.first, coords.second, null, currentSettings.weatherApiKey)
                    }
                    _weatherState.value = WeatherUiState.Success(report)
                    val tomorrow = report.weeklyForecast.getOrNull(1)
                    sb.append(
                        "Clima em ${report.locationName}: ${report.temperatureC.toInt()}°C " +
                            "(sensação ${report.feelsLikeC.toInt()}°C), ${report.conditionDescription}, " +
                            "probabilidade de chuva ${report.rainProbabilityPercent}%, " +
                            "umidade ${report.humidityPercent}%, vento ${report.windKmh.toInt()} km/h. "
                    )
                    if (tomorrow != null) {
                        sb.append(
                            "Previsão para amanhã: ${tomorrow.conditionLabel}, mínima ${tomorrow.minTempC}°C, " +
                                "máxima ${tomorrow.maxTempC}°C, chuva ${tomorrow.rainProbability}%."
                        )
                    }
                }.onFailure {
                    sb.append("Tentativa de obter clima falhou: ${it.message}")
                }
            }
            JarvisCommandAction.OPEN_MAPS,
            JarvisCommandAction.OPEN_TRAFFIC,
            JarvisCommandAction.OPEN_HIGHWAYS -> {
                val tab = when (intent.action) {
                    JarvisCommandAction.OPEN_TRAFFIC -> "traffic"
                    JarvisCommandAction.OPEN_HIGHWAYS -> "highways"
                    else -> "maps"
                }
                _voiceNavEvents.tryEmit(VoiceNavigationTarget.Maps(tab))
                val loc = weatherRepo.getCurrentDeviceCoordinates()
                if (loc != null) {
                    val origin = GeoPoint(loc.first, loc.second, "Localização Atual")
                    _mapsState.value = _mapsState.value.copy(currentLocation = origin)
                    sb.append("Coordenadas atuais: ${loc.first}, ${loc.second}. ")
                }
                if (intent.queryParameter.isNotBlank()) {
                    runCatching {
                        val places = mapsRepo.searchPlaces(intent.queryParameter)
                        val destPlace = places.firstOrNull()
                        if (destPlace != null) {
                            val dest = GeoPoint(destPlace.latitude, destPlace.longitude, destPlace.displayName)
                            val origin = _mapsState.value.currentLocation ?: GeoPoint(-23.5505, -46.6333, "São Paulo")
                            val routes = mapsRepo.calculateRoutes(origin, dest, currentSettings.mapsTrafficApiKey)
                            _mapsState.value = _mapsState.value.copy(
                                selectedDestination = dest,
                                searchResults = places,
                                routes = routes,
                                selectedRouteIndex = 0
                            )
                            val primary = routes.firstOrNull()
                            if (primary != null) {
                                sb.append(
                                    "Rota para ${destPlace.displayName}: ${String.format(Locale.US, "%.1f", primary.distanceKm)} km, " +
                                        "tempo estimado ${primary.durationMinutes} min. " +
                                        "Rodovias: ${primary.highwayNames.joinToString(", ").ifBlank { "vias urbanas" }}. " +
                                        "Status de trânsito: ${primary.trafficStatus}."
                                )
                            }
                        }
                    }
                }
            }
            JarvisCommandAction.CREATE_ALARM -> {
                _voiceNavEvents.tryEmit(VoiceNavigationTarget.Alarms)
                val h = intent.alarmHour?.coerceIn(0, 23) ?: 7
                val m = intent.alarmMinute?.coerceIn(0, 59) ?: 0
                val label = intent.queryParameter.ifBlank { "Alarme JARVIS" }
                saveAlarm(
                    AlarmEntity(
                        hour = h,
                        minute = m,
                        label = label,
                        enabled = true,
                        daysOfWeekCsv = "",
                        repeatWeekly = false,
                        speakJarvisGreeting = true,
                        volume = currentSettings.alarmVolume
                    )
                )
                sb.append(String.format(Locale.getDefault(), "Alarme criado e ativado para %02d:%02d (%s).", h, m, label))
            }
            JarvisCommandAction.OPEN_ALARMS -> _voiceNavEvents.tryEmit(VoiceNavigationTarget.Alarms)
            JarvisCommandAction.PLAY_MUSIC -> {
                _voiceNavEvents.tryEmit(VoiceNavigationTarget.Music)
                val allTracks = tracks.value
                val match = if (intent.queryParameter.isNotBlank()) {
                    allTracks.firstOrNull { it.title.contains(intent.queryParameter, ignoreCase = true) }
                } else null
                if (match != null) {
                    musicController.playTrack(match, allTracks)
                    sb.append("Reproduzindo a faixa '${match.title}'.")
                } else if (allTracks.isNotEmpty()) {
                    musicController.playFirstOrResume()
                    sb.append("Reprodução iniciada com '${allTracks.first().title}'.")
                } else {
                    sb.append("A biblioteca de músicas locais está vazia. O senhor pode adicionar faixas no módulo Música.")
                }
            }
            JarvisCommandAction.PAUSE_MUSIC -> {
                musicController.pause()
                sb.append("Reprodução de música pausada.")
            }
            JarvisCommandAction.NEXT_TRACK -> {
                musicController.nextTrack()
                sb.append("Avançando para a próxima faixa.")
            }
            JarvisCommandAction.OPEN_MUSIC -> _voiceNavEvents.tryEmit(VoiceNavigationTarget.Music)
            JarvisCommandAction.OPEN_VOICE_SETTINGS -> _voiceNavEvents.tryEmit(VoiceNavigationTarget.VoiceSettings)
            JarvisCommandAction.OPEN_SETTINGS -> _voiceNavEvents.tryEmit(VoiceNavigationTarget.Settings)
            JarvisCommandAction.OPEN_INSTALL -> {
                _voiceNavEvents.tryEmit(VoiceNavigationTarget.DeviceInstall)
                sb.append("Abrindo a central de instalação sem computador para celular e tablet Android.")
            }
            JarvisCommandAction.NONE -> {
                val w = (_weatherState.value as? WeatherUiState.Success)?.report
                if (w != null) {
                    sb.append("Clima recente (${w.locationName}): ${w.temperatureC.toInt()}°C, ${w.conditionDescription}. ")
                }
            }
        }
        return sb.toString()
    }

    fun triggerVoiceCommand() {
        voiceManager.startSingleCommandListening()
    }

    fun stopSpeakingOrListening() {
        voiceManager.stopSpeaking()
        if (voiceEngineState.value == VoiceEngineState.ACTIVE_LISTENING) {
            voiceManager.stopListening()
        }
    }

    fun toggleContinuousVoiceService(enable: Boolean) {
        viewModelScope.launch {
            prefs.updateContinuousVoice(enable)
            onToggleVoiceService(enable)
        }
    }

    fun clearChatHistory() {
        activeAiJob?.cancel()
        lastPendingRequest = null
        viewModelScope.launch {
            chatDao.clearAll()
            cloudRepo.clearMessages()
            _aiState.value = AiUiState.Idle
            _uiNotice.tryEmit("Histórico de conversas limpo na conta Google, senhor.")
        }
    }

    fun refreshWeatherByLocation() {
        viewModelScope.launch {
            _weatherState.value = WeatherUiState.Loading
            runCatching {
                val coords = weatherRepo.getCurrentDeviceCoordinates() ?: (-23.5505 to -46.6333)
                val report = weatherRepo.fetchWeather(
                    latitude = coords.first,
                    longitude = coords.second,
                    optionalOpenWeatherKey = settings.value.weatherApiKey
                )
                _weatherState.value = WeatherUiState.Success(report)
            }.onFailure {
                _weatherState.value = WeatherUiState.Error(it.localizedMessage ?: "Erro ao obter previsão do tempo.")
            }
        }
    }

    fun searchWeatherByCity(city: String) {
        if (city.isBlank()) return
        viewModelScope.launch {
            _weatherState.value = WeatherUiState.Loading
            runCatching {
                val report = weatherRepo.fetchWeatherByCity(city, settings.value.weatherApiKey)
                _weatherState.value = WeatherUiState.Success(report)
            }.onFailure {
                _weatherState.value = WeatherUiState.Error(it.localizedMessage ?: "Cidade não encontrada.")
            }
        }
    }

    fun refreshCurrentMapLocation() {
        viewModelScope.launch {
            val coords = weatherRepo.getCurrentDeviceCoordinates()
            if (coords != null) {
                _mapsState.value = _mapsState.value.copy(
                    currentLocation = GeoPoint(coords.first, coords.second, "Posição Atual"),
                    errorMessage = null
                )
            } else {
                _mapsState.value = _mapsState.value.copy(
                    errorMessage = "Ative a permissão de localização e o GPS para detectar sua posição atual."
                )
            }
        }
    }

    fun searchMapPlaces(query: String) {
        if (query.isBlank()) return
        viewModelScope.launch {
            _mapsState.value = _mapsState.value.copy(isLoading = true, errorMessage = null)
            runCatching {
                val results = mapsRepo.searchPlaces(query)
                _mapsState.value = _mapsState.value.copy(
                    searchResults = results,
                    isLoading = false,
                    errorMessage = if (results.isEmpty()) "Nenhum endereço encontrado para '$query'." else null
                )
            }.onFailure {
                _mapsState.value = _mapsState.value.copy(
                    isLoading = false,
                    errorMessage = it.localizedMessage ?: "Falha ao pesquisar endereço."
                )
            }
        }
    }

    fun calculateRouteTo(place: PlaceSearchResult) {
        viewModelScope.launch {
            _mapsState.value = _mapsState.value.copy(isLoading = true, errorMessage = null)
            runCatching {
                val origin = _mapsState.value.currentLocation
                    ?: weatherRepo.getCurrentDeviceCoordinates()?.let { GeoPoint(it.first, it.second, "Origem Atual") }
                    ?: GeoPoint(-23.5505, -46.6333, "São Paulo (Centro)")
                val destination = GeoPoint(place.latitude, place.longitude, place.displayName)
                val routes = mapsRepo.calculateRoutes(
                    origin = origin,
                    destination = destination,
                    googleTrafficApiKey = settings.value.mapsTrafficApiKey
                )
                _mapsState.value = _mapsState.value.copy(
                    currentLocation = origin,
                    selectedDestination = destination,
                    routes = routes,
                    selectedRouteIndex = 0,
                    isLoading = false
                )
            }.onFailure {
                _mapsState.value = _mapsState.value.copy(
                    isLoading = false,
                    errorMessage = it.localizedMessage ?: "Não foi possível calcular a rota."
                )
            }
        }
    }

    fun selectRouteOption(index: Int) {
        _mapsState.value = _mapsState.value.copy(selectedRouteIndex = index)
    }

    fun saveAlarm(alarm: AlarmEntity) {
        viewModelScope.launch {
            val cloudId = cloudAlarmIdByLocalId[alarm.id] ?: newCloudId("alarm")
            if (alarm.soundUri.isNotBlank()) {
                localSoundUriByCloudAlarmId[cloudId] = alarm.soundUri
            }
            val localId = stableLocalId(cloudId)
            cloudAlarmIdByLocalId[localId] = cloudId
            val savedLocal = alarm.copy(id = localId)
            alarmDao.insertAlarm(savedLocal)
            if (savedLocal.enabled) {
                alarmScheduler.scheduleAlarm(savedLocal)
            } else {
                alarmScheduler.cancelAlarm(savedLocal.id)
            }
            cloudRepo.upsertAlarm(
                alarmId = cloudId,
                hour = savedLocal.hour,
                minute = savedLocal.minute,
                label = savedLocal.label,
                enabled = savedLocal.enabled,
                daysOfWeekCsv = savedLocal.daysOfWeekCsv,
                repeatWeekly = savedLocal.repeatWeekly,
                speakJarvisGreeting = savedLocal.speakJarvisGreeting,
                soundTitle = savedLocal.soundTitle,
                volume = savedLocal.volume
            )
            _uiNotice.tryEmit(
                String.format(Locale.getDefault(), "Alarme sincronizado para %02d:%02d.", savedLocal.hour, savedLocal.minute)
            )
        }
    }

    fun toggleAlarm(alarm: AlarmEntity, enabled: Boolean) {
        viewModelScope.launch {
            val updated = alarm.copy(enabled = enabled)
            alarmDao.updateAlarm(updated)
            if (enabled) alarmScheduler.scheduleAlarm(updated) else alarmScheduler.cancelAlarm(updated.id)
            val cloudId = cloudAlarmIdByLocalId[alarm.id] ?: newCloudId("alarm")
            cloudRepo.upsertAlarm(
                alarmId = cloudId,
                hour = updated.hour,
                minute = updated.minute,
                label = updated.label,
                enabled = updated.enabled,
                daysOfWeekCsv = updated.daysOfWeekCsv,
                repeatWeekly = updated.repeatWeekly,
                speakJarvisGreeting = updated.speakJarvisGreeting,
                soundTitle = updated.soundTitle,
                volume = updated.volume
            )
        }
    }

    fun deleteAlarm(alarm: AlarmEntity) {
        viewModelScope.launch {
            alarmScheduler.cancelAlarm(alarm.id)
            alarmDao.deleteAlarmById(alarm.id)
            cloudAlarmIdByLocalId.remove(alarm.id)?.let { cloudId ->
                localSoundUriByCloudAlarmId.remove(cloudId)
                cloudRepo.deleteAlarm(cloudId)
            }
        }
    }

    fun importAudioUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            uris.forEach { uri ->
                val track = musicController.extractTrackMetadata(uri)
                musicDao.insertTrack(track)
            }
            _uiNotice.tryEmit("${uris.size} faixa(s) adicionada(s) à biblioteca JARVIS.")
        }
    }

    fun deleteTrack(track: MusicTrackEntity) {
        viewModelScope.launch { musicDao.deleteTrackById(track.id) }
    }

    fun createPlaylist(name: String) {
        val clean = name.trim()
        if (clean.isBlank()) return
        viewModelScope.launch {
            val cloudId = newCloudId("pl")
            cloudPlaylistIdByName[clean.lowercase(Locale.getDefault())] = cloudId
            musicDao.insertPlaylist(PlaylistEntity(name = clean))
            cloudRepo.createPlaylist(name = clean, playlistId = cloudId)
        }
    }

    fun addTrackToPlaylist(playlistId: Long, trackId: Long) {
        viewModelScope.launch {
            musicDao.addTrackToPlaylist(PlaylistTrackCrossRef(playlistId, trackId))
        }
    }

    fun removeTrackFromPlaylist(playlistId: Long, trackId: Long) {
        viewModelScope.launch {
            musicDao.removeTrackFromPlaylist(playlistId, trackId)
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            val existing = playlists.value.firstOrNull { it.playlist.id == playlistId }?.playlist
            musicDao.deletePlaylist(playlistId)
            if (existing != null) {
                val cloudId = cloudPlaylistIdByName.remove(existing.name.lowercase(Locale.getDefault()))
                if (cloudId != null) {
                    cloudRepo.deletePlaylist(cloudId)
                }
            }
        }
    }

    fun createAlarmWithMusic(track: MusicTrackEntity, hour: Int, minute: Int) {
        saveAlarm(
            AlarmEntity(
                hour = hour,
                minute = minute,
                label = "Despertar: ${track.title}",
                enabled = true,
                daysOfWeekCsv = "1,2,3,4,5",
                repeatWeekly = true,
                speakJarvisGreeting = true,
                soundUri = track.uriString,
                soundTitle = track.title,
                volume = settings.value.alarmVolume
            )
        )
    }

    private fun pushSettingsToCloud() {
        viewModelScope.launch {
            val latest = prefs.settings.first()
            cloudRepo.syncSettings(latest)
        }
    }

    fun updateWakeWord(word: String) = viewModelScope.launch {
        prefs.updateWakeWord(word)
        pushSettingsToCloud()
    }

    fun updateLanguage(tag: String) = viewModelScope.launch {
        prefs.updateLanguageTag(tag)
        voiceManager.refreshAvailableVoices()
        pushSettingsToCloud()
    }

    fun updateSelectedVoice(voiceName: String) = viewModelScope.launch { prefs.updateSelectedVoiceName(voiceName) }

    fun updateSpeechRate(rate: Float) = viewModelScope.launch {
        prefs.updateSpeechRate(rate)
        pushSettingsToCloud()
    }

    fun updateSpeechPitch(pitch: Float) = viewModelScope.launch {
        prefs.updateSpeechPitch(pitch)
        pushSettingsToCloud()
    }

    fun updateAssistantVolume(vol: Float) = viewModelScope.launch {
        prefs.updateAssistantVolume(vol)
        voiceManager.setSystemVoiceVolume(vol)
        pushSettingsToCloud()
    }

    fun updateImportedAudio(uri: String, name: String) = viewModelScope.launch { prefs.updateImportedAudio(uri, name) }

    fun updateExternalTts(enabled: Boolean, endpoint: String, apiKey: String, voiceId: String) =
        viewModelScope.launch { prefs.updateExternalTtsConfig(enabled, endpoint, apiKey, voiceId) }

    fun updateGeminiModel(model: String) = viewModelScope.launch {
        prefs.updateGeminiModel(model)
        pushSettingsToCloud()
    }

    fun updateApiKeys(weatherKey: String, mapsKey: String) = viewModelScope.launch { prefs.updateApiKeys(weatherKey, mapsKey) }

    fun updateVisuals(glow: Float, globe: Boolean) = viewModelScope.launch {
        prefs.updateVisualSettings(glow, globe)
        pushSettingsToCloud()
    }

    fun updateAlarmDefaults(snoozeMin: Int, volume: Float) = viewModelScope.launch {
        prefs.updateAlarmDefaults(snoozeMin, volume)
        pushSettingsToCloud()
    }

    fun updateInstallDownloadUrl(url: String) = viewModelScope.launch {
        prefs.updateInstallDownloadUrl(url)
    }

    fun emitNotice(message: String) {
        _uiNotice.tryEmit(message)
    }

    fun testJarvisVoiceSample() {
        voiceManager.speak("Olá, senhor. Todos os sistemas neurais e protocolos de voz estão operando com máxima precisão.")
    }

    private fun CloudChatMessage.toLocalEntity(): ChatMessageEntity =
        ChatMessageEntity(
            id = stableLocalId(id),
            sessionId = sessionId,
            role = role,
            content = content,
            attachmentName = attachmentName,
            timestamp = createdAt?.toDate()?.time ?: System.currentTimeMillis()
        )

    private fun CloudAlarm.toLocalEntity(localId: Long, localSoundUri: String): AlarmEntity =
        AlarmEntity(
            id = localId,
            hour = hour,
            minute = minute,
            label = label,
            enabled = enabled,
            daysOfWeekCsv = daysOfWeekCsv,
            repeatWeekly = repeatWeekly,
            speakJarvisGreeting = speakJarvisGreeting,
            soundUri = localSoundUri,
            soundTitle = soundTitle,
            volume = volume.toFloat()
        )

    private fun stableLocalId(cloudId: String): Long =
        (cloudId.hashCode().toLong() and 0x7FFFFFFFL).coerceAtLeast(1L)

    private fun newCloudId(prefix: String): String =
        "${prefix}_${UUID.randomUUID().toString().replace("-", "").take(20)}"

    companion object {
        private const val TAG = "JarvisVM"
        private const val STOP_TIMEOUT_MILLIS = 5000L

        fun factory(
            currentUserId: String,
            currentUserDisplayName: String?,
            currentUserEmail: String?,
            onToggleVoiceService: (Boolean) -> Unit
        ): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY]) as Application
                val jarvisApp = app as JarvisApplication
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                JarvisViewModel(
                    container = jarvisApp.container,
                    cloudRepo = JarvisCloudRepository(db),
                    currentUserId = currentUserId,
                    currentUserDisplayName = currentUserDisplayName,
                    currentUserEmail = currentUserEmail,
                    onToggleVoiceService = onToggleVoiceService
                )
            }
        }
    }
}
