package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.components.HudScreenTopBar
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextGoldPrimary
import com.example.ui.theme.TextGoldSecondary

private data class CommandModuleEntry(
    val title: String,
    val description: String,
    val icon: ImageVector,
    val tag: String,
    val action: () -> Unit
)

@Composable
fun CommandHubScreen(
    onBack: () -> Unit,
    onOpenAi: () -> Unit,
    onOpenMic: () -> Unit,
    onOpenConversations: () -> Unit,
    onOpenWeather: () -> Unit,
    onOpenMaps: () -> Unit,
    onOpenTraffic: () -> Unit,
    onOpenHighways: () -> Unit,
    onOpenAlarms: () -> Unit,
    onOpenMusic: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenInstall: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val modules = listOf(
        CommandModuleEntry("Inteligência Artificial", "Google Gemini 3.8 Flash", Icons.Default.AutoAwesome, "hub_ai", onOpenAi),
        CommandModuleEntry("Microfone & Voz", "Voz do JARVIS & Ativação", Icons.Default.Mic, "hub_mic", onOpenMic),
        CommandModuleEntry("Conversas", "Diálogos & Histórico", Icons.Default.Forum, "hub_conversations", onOpenConversations),
        CommandModuleEntry("Clima", "Previsão & Chuva", Icons.Default.Cloud, "hub_weather", onOpenWeather),
        CommandModuleEntry("Mapas", "GPS, Locais & Rotas", Icons.Default.Map, "hub_maps", onOpenMaps),
        CommandModuleEntry("Trânsito", "Congestionamentos & Fluxo", Icons.Default.Traffic, "hub_traffic", onOpenTraffic),
        CommandModuleEntry("Rodovias", "Consultas & Rotas Alternativas", Icons.Default.DirectionsCar, "hub_highways", onOpenHighways),
        CommandModuleEntry("Despertador", "Alarmes Exatos & Voz", Icons.Default.Alarm, "hub_alarms", onOpenAlarms),
        CommandModuleEntry("Música", "Reprodutor & Listas", Icons.Default.MusicNote, "hub_music", onOpenMusic),
        CommandModuleEntry("Instalar Sem PC", "Celular, Tablet & QR Code", Icons.Default.InstallMobile, "hub_install", onOpenInstall),
        CommandModuleEntry("Configurações", "APIs, Permissões & HUD", Icons.Default.Settings, "hub_settings", onOpenSettings)
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PitchBlack)
    ) {
        HudScreenTopBar(
            title = "Painel de Comando",
            subtitle = "ACESSO RÁPIDO AOS 11 MÓDULOS DO SISTEMA",
            onBack = onBack
        )

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 165.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(modules) { item ->
                Surface(
                    onClick = item.action,
                    color = ObsidianCard,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, JarvisGoldBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(132.dp)
                        .testTag(item.tag)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.title,
                            tint = JarvisGoldBright,
                            modifier = Modifier.size(28.dp)
                        )
                        Column {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = TextGoldPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = item.description,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextGoldSecondary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}
