package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.ai.configureAppCheck
import com.example.auth.authStateFlow
import com.example.auth.signOutGoogle
import com.example.ui.JarvisViewModel
import com.example.ui.VoiceNavigationTarget
import com.example.ui.navigation.AiChatRoute
import com.example.ui.navigation.AlarmsRoute
import com.example.ui.navigation.CommandHubRoute
import com.example.ui.navigation.DeviceInstallRoute
import com.example.ui.navigation.HudHomeRoute
import com.example.ui.navigation.JarvisVoiceRoute
import com.example.ui.navigation.MapsTrafficRoute
import com.example.ui.navigation.MusicPlayerRoute
import com.example.ui.navigation.SettingsRoute
import com.example.ui.navigation.WeatherRoute
import com.example.ui.screens.AiChatScreen
import com.example.ui.screens.AlarmsScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CommandHubScreen
import com.example.ui.screens.DeviceInstallScreen
import com.example.ui.screens.HudHomeScreen
import com.example.ui.screens.JarvisVoiceScreen
import com.example.ui.screens.MapsTrafficScreen
import com.example.ui.screens.MusicPlayerScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.WeatherScreen
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.JarvisTheme
import com.example.ui.theme.ObsidianPanel
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextGoldSecondary
import com.example.voice.JarvisVoiceService
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth

private data class TopLevelNavItem(
    val label: String,
    val icon: ImageVector,
    val route: Any
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configure Firebase App Check with launch Intent before Compose UI or ViewModels
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            JarvisTheme {
                JarvisAuthGate()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        configureAppCheck(this, intent)
    }
}

@Composable
fun JarvisAuthGate() {
    val auth = Firebase.auth
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        key(user.uid) {
            JarvisAuthenticatedApp(user = user)
        }
    }
}

@Composable
private fun JarvisAuthenticatedApp(user: FirebaseUser) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: JarvisViewModel = viewModel(
        key = user.uid,
        factory = JarvisViewModel.factory(
            currentUserId = user.uid,
            currentUserDisplayName = user.displayName,
            currentUserEmail = user.email,
            onToggleVoiceService = { enable ->
                if (enable) JarvisVoiceService.start(context) else JarvisVoiceService.stop(context)
            }
        )
    )

    JarvisRootApp(
        viewModel = viewModel,
        onSignOut = {
            JarvisVoiceService.stop(context)
            signOutGoogle(
                credentialManager = credentialManager,
                scope = coroutineScope
            )
        }
    )
}

@Composable
fun JarvisRootApp(
    viewModel: JarvisViewModel,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val cloudSyncError by viewModel.cloudSyncError.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val alarms by viewModel.alarms.collectAsStateWithLifecycle()
    val tracks by viewModel.tracks.collectAsStateWithLifecycle()
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()
    val voiceState by viewModel.voiceEngineState.collectAsStateWithLifecycle()
    val rmsLevel by viewModel.rmsLevel.collectAsStateWithLifecycle()
    val partialTranscript by viewModel.partialTranscript.collectAsStateWithLifecycle()
    val voiceStatus by viewModel.voiceStatusMessage.collectAsStateWithLifecycle()
    val availableVoices by viewModel.availableVoices.collectAsStateWithLifecycle()
    val aiState by viewModel.aiState.collectAsStateWithLifecycle()
    val weatherState by viewModel.weatherState.collectAsStateWithLifecycle()
    val mapsState by viewModel.mapsState.collectAsStateWithLifecycle()
    val musicState by viewModel.musicState.collectAsStateWithLifecycle()

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.triggerVoiceCommand()
    }

    val handleCoreTap: () -> Unit = {
        if (voiceState == com.example.voice.VoiceEngineState.SPEAKING ||
            voiceState == com.example.voice.VoiceEngineState.ACTIVE_LISTENING
        ) {
            viewModel.stopSpeakingOrListening()
        } else {
            val hasMic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (hasMic) {
                viewModel.triggerVoiceCommand()
            } else {
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    LaunchedEffect(Unit) {
        viewModel.uiNotice.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    LaunchedEffect(Unit) {
        viewModel.voiceNavEvents.collect { target ->
            when (target) {
                VoiceNavigationTarget.Weather -> navController.navigate(WeatherRoute)
                is VoiceNavigationTarget.Maps -> navController.navigate(MapsTrafficRoute(target.tab))
                VoiceNavigationTarget.Alarms -> navController.navigate(AlarmsRoute)
                VoiceNavigationTarget.Music -> navController.navigate(MusicPlayerRoute)
                VoiceNavigationTarget.VoiceSettings -> navController.navigate(JarvisVoiceRoute)
                VoiceNavigationTarget.Settings -> navController.navigate(SettingsRoute)
                VoiceNavigationTarget.DeviceInstall -> navController.navigate(DeviceInstallRoute)
            }
        }
    }

    val topNavItems = remember {
        listOf(
            TopLevelNavItem("Núcleo", Icons.Default.Hub, HudHomeRoute),
            TopLevelNavItem("IA", Icons.Default.AutoAwesome, AiChatRoute),
            TopLevelNavItem("Clima", Icons.Default.Cloud, WeatherRoute),
            TopLevelNavItem("Mapas", Icons.Default.Map, MapsTrafficRoute("maps")),
            TopLevelNavItem("Painel", Icons.Default.Apps, CommandHubRoute),
            TopLevelNavItem("Ajustes", Icons.Default.Settings, SettingsRoute)
        )
    }

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination

    val navigateTopLevel: (Any) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(PitchBlack)
    ) {
        val useRail = maxWidth >= 760.dp

        Scaffold(
            containerColor = PitchBlack,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = ObsidianPanel,
                        contentColor = JarvisGoldBright
                    ) {
                        topNavItems.take(5).forEach { item ->
                            val selected = currentDestination?.hasRoute(item.route::class) == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopLevel(item.route) },
                                icon = { Icon(item.icon, contentDescription = item.label) },
                                label = { Text(item.label, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = PitchBlack,
                                    selectedTextColor = JarvisGoldBright,
                                    indicatorColor = JarvisGold,
                                    unselectedIconColor = TextGoldSecondary,
                                    unselectedTextColor = TextGoldSecondary
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(
                        containerColor = ObsidianPanel,
                        contentColor = JarvisGoldBright,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        topNavItems.forEach { item ->
                            val selected = currentDestination?.hasRoute(item.route::class) == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopLevel(item.route) },
                                icon = { Icon(item.icon, contentDescription = item.label) },
                                label = { Text(item.label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = PitchBlack,
                                    selectedTextColor = JarvisGoldBright,
                                    indicatorColor = JarvisGold,
                                    unselectedIconColor = TextGoldSecondary,
                                    unselectedTextColor = TextGoldSecondary
                                )
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = HudHomeRoute,
                    modifier = Modifier.weight(1f)
                ) {
                    composable<HudHomeRoute> {
                        HudHomeScreen(
                            settings = settings,
                            voiceState = voiceState,
                            rmsLevel = rmsLevel,
                            partialTranscript = partialTranscript,
                            voiceStatusMessage = voiceStatus,
                            aiState = aiState,
                            weatherState = weatherState,
                            alarms = alarms,
                            musicState = musicState,
                            onCoreTap = handleCoreTap,
                            onStopVoice = viewModel::stopSpeakingOrListening,
                            onSendPrompt = { text -> viewModel.handleUserMessage(text, speakReply = true) },
                            onOpenAiChat = { navController.navigate(AiChatRoute) },
                            onOpenVoice = { navController.navigate(JarvisVoiceRoute) },
                            onOpenWeather = { navController.navigate(WeatherRoute) },
                            onOpenMaps = { tab -> navController.navigate(MapsTrafficRoute(tab)) },
                            onOpenAlarms = { navController.navigate(AlarmsRoute) },
                            onOpenMusic = { navController.navigate(MusicPlayerRoute) },
                            onOpenCommandHub = { navController.navigate(CommandHubRoute) },
                            onOpenSettings = { navController.navigate(SettingsRoute) },
                            onOpenInstall = { navController.navigate(DeviceInstallRoute) },
                            onRetry = viewModel::retryLastMessage,
                            userEmail = viewModel.currentUserEmail
                        )
                    }

                    composable<CommandHubRoute> {
                        CommandHubScreen(
                            onBack = { navController.popBackStack() },
                            onOpenAi = { navController.navigate(AiChatRoute) },
                            onOpenMic = { navController.navigate(JarvisVoiceRoute) },
                            onOpenConversations = { navController.navigate(AiChatRoute) },
                            onOpenWeather = { navController.navigate(WeatherRoute) },
                            onOpenMaps = { navController.navigate(MapsTrafficRoute("maps")) },
                            onOpenTraffic = { navController.navigate(MapsTrafficRoute("traffic")) },
                            onOpenHighways = { navController.navigate(MapsTrafficRoute("highways")) },
                            onOpenAlarms = { navController.navigate(AlarmsRoute) },
                            onOpenMusic = { navController.navigate(MusicPlayerRoute) },
                            onOpenInstall = { navController.navigate(DeviceInstallRoute) },
                            onOpenSettings = { navController.navigate(SettingsRoute) }
                        )
                    }

                    composable<AiChatRoute> {
                        AiChatScreen(
                            messages = chatMessages,
                            aiState = aiState,
                            modelName = settings.geminiModelName,
                            onBack = { navController.popBackStack() },
                            onSendMessage = { text, bmp, docBytes, mime, label ->
                                viewModel.handleUserMessage(
                                    utterance = text,
                                    speakReply = true,
                                    imageBitmap = bmp,
                                    documentBytes = docBytes,
                                    documentMimeType = mime,
                                    attachmentLabel = label
                                )
                            },
                            onSpeakText = { text -> viewModel.voiceManager.speak(text) },
                            onMicTap = handleCoreTap,
                            onClearHistory = viewModel::clearChatHistory,
                            onRetry = viewModel::retryLastMessage
                        )
                    }

                    composable<JarvisVoiceRoute> {
                        JarvisVoiceScreen(
                            settings = settings,
                            availableVoices = availableVoices,
                            voiceStatusMessage = voiceStatus,
                            onBack = { navController.popBackStack() },
                            onUpdateWakeWord = viewModel::updateWakeWord,
                            onToggleContinuousVoice = viewModel::toggleContinuousVoiceService,
                            onUpdateLanguage = viewModel::updateLanguage,
                            onSelectVoice = viewModel::updateSelectedVoice,
                            onUpdateRate = viewModel::updateSpeechRate,
                            onUpdatePitch = viewModel::updateSpeechPitch,
                            onUpdateVolume = viewModel::updateAssistantVolume,
                            onTestSample = viewModel::testJarvisVoiceSample,
                            onImportAudio = viewModel::updateImportedAudio,
                            onPlayImportedAudio = { uri -> viewModel.voiceManager.playImportedAudioSample(uri) },
                            onSaveExternalTts = viewModel::updateExternalTts
                        )
                    }

                    composable<WeatherRoute> {
                        WeatherScreen(
                            weatherState = weatherState,
                            onBack = { navController.popBackStack() },
                            onRefreshGps = viewModel::refreshWeatherByLocation,
                            onSearchCity = viewModel::searchWeatherByCity,
                            onAskJarvis = { prompt ->
                                viewModel.handleUserMessage(prompt, speakReply = true)
                            }
                        )
                    }

                    composable<MapsTrafficRoute> { backEntry ->
                        val args = backEntry.toRoute<MapsTrafficRoute>()
                        MapsTrafficScreen(
                            initialTab = args.initialTab,
                            mapsState = mapsState,
                            hasGoogleTrafficKey = settings.mapsTrafficApiKey.isNotBlank(),
                            onBack = { navController.popBackStack() },
                            onRefreshLocation = viewModel::refreshCurrentMapLocation,
                            onSearchPlaces = viewModel::searchMapPlaces,
                            onSelectDestination = viewModel::calculateRouteTo,
                            onSelectRoute = viewModel::selectRouteOption,
                            onAskJarvis = { prompt ->
                                viewModel.handleUserMessage(prompt, speakReply = true)
                            },
                            onOpenSettings = { navController.navigate(SettingsRoute) }
                        )
                    }

                    composable<AlarmsRoute> {
                        AlarmsScreen(
                            alarms = alarms,
                            musicTracks = tracks,
                            defaultAlarmVolume = settings.alarmVolume,
                            onBack = { navController.popBackStack() },
                            onSaveAlarm = viewModel::saveAlarm,
                            onToggleAlarm = viewModel::toggleAlarm,
                            onDeleteAlarm = viewModel::deleteAlarm
                        )
                    }

                    composable<MusicPlayerRoute> {
                        MusicPlayerScreen(
                            playbackState = musicState,
                            tracks = tracks,
                            playlists = playlists,
                            onBack = { navController.popBackStack() },
                            onImportTracks = viewModel::importAudioUris,
                            onPlayTrack = viewModel.musicController::playTrack,
                            onTogglePlayPause = viewModel.musicController::togglePlayPause,
                            onNext = viewModel.musicController::nextTrack,
                            onPrevious = viewModel.musicController::previousTrack,
                            onSeek = viewModel.musicController::seekTo,
                            onVolumeChange = viewModel.musicController::setVolume,
                            onToggleShuffle = viewModel.musicController::toggleShuffle,
                            onToggleRepeat = viewModel.musicController::toggleRepeat,
                            onDeleteTrack = viewModel::deleteTrack,
                            onCreatePlaylist = viewModel::createPlaylist,
                            onAddTrackToPlaylist = viewModel::addTrackToPlaylist,
                            onDeletePlaylist = viewModel::deletePlaylist,
                            onSetAsAlarm = { track ->
                                viewModel.createAlarmWithMusic(track, 7, 0)
                                navController.navigate(AlarmsRoute)
                            },
                            onOpenExternalApp = viewModel.musicController::openExternalMusicApp
                        )
                    }

                    composable<SettingsRoute> {
                        SettingsScreen(
                            settings = settings,
                            messageCount = chatMessages.size,
                            userDisplayName = viewModel.currentUserDisplayName,
                            userEmail = viewModel.currentUserEmail,
                            cloudSyncError = cloudSyncError,
                            onBack = { navController.popBackStack() },
                            onOpenVoiceScreen = { navController.navigate(JarvisVoiceRoute) },
                            onOpenInstallScreen = { navController.navigate(DeviceInstallRoute) },
                            onSelectGeminiModel = viewModel::updateGeminiModel,
                            onSaveApiKeys = viewModel::updateApiKeys,
                            onUpdateVisuals = viewModel::updateVisuals,
                            onUpdateAlarmDefaults = viewModel::updateAlarmDefaults,
                            onClearHistory = viewModel::clearChatHistory,
                            onSignOut = onSignOut
                        )
                    }

                    composable<DeviceInstallRoute> {
                        DeviceInstallScreen(
                            settings = settings,
                            userEmail = viewModel.currentUserEmail,
                            onBack = { navController.popBackStack() },
                            onSaveDownloadUrl = viewModel::updateInstallDownloadUrl,
                            onNotify = viewModel::emitNotice
                        )
                    }
                }
            }
        }
    }
}
