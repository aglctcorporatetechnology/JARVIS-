const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const DATABASE_ID = "ai-studio-android-jarvis-bb5c38df-cd90-4254-a705-2fd14b9c1a73";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function serverTimestamp(db) {
  const compatFieldValue = db?.app?.firebase_?.firestore?.FieldValue;
  return compatFieldValue ? compatFieldValue.serverTimestamp() : new Date(Date.now() - 2000);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write user profile", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore(DATABASE_ID);
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      wakeWord: "JARVIS",
      languageTag: "pt-BR",
      createdAt: serverTimestamp(unauthDb),
      updatedAt: serverTimestamp(unauthDb),
    })
  );
});

test("Authenticated owner can create and update their JARVIS profile", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  const profileRef = aliceDb.collection("users").doc(ALICE_UID);

  await assertSucceeds(
    profileRef.set({
      userId: ALICE_UID,
      displayName: "Tony Stark",
      email: "tony@stark.com",
      wakeWord: "JARVIS",
      languageTag: "pt-BR",
      speechRate: 1.0,
      speechPitch: 0.94,
      assistantVolume: 0.9,
      geminiModelName: "gemini-3.8-flash",
      hudGlowIntensity: 0.85,
      globeAnimationEnabled: true,
      defaultSnoozeMinutes: 10,
      alarmVolume: 0.95,
      createdAt: serverTimestamp(aliceDb),
      updatedAt: serverTimestamp(aliceDb),
    })
  );

  await assertSucceeds(
    profileRef.update({
      wakeWord: "SEXTA-FEIRA",
      updatedAt: serverTimestamp(aliceDb),
    })
  );
});

test("Shadow update with ghost field on user profile is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  const profileRef = aliceDb.collection("users").doc(ALICE_UID);

  await assertFails(
    profileRef.set({
      userId: ALICE_UID,
      wakeWord: "JARVIS",
      languageTag: "pt-BR",
      isAdmin: true,
      createdAt: serverTimestamp(aliceDb),
      updatedAt: serverTimestamp(aliceDb),
    })
  );
});

test("Cross-user access to profile, messages, alarms, and playlists is denied", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DATABASE_ID);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("alarms").doc("alarm_1").set({
      userId: ALICE_UID,
      hour: 7,
      minute: 0,
      label: "Acordar",
      enabled: true,
      daysOfWeekCsv: "1,2,3,4,5",
      repeatWeekly: true,
      speakJarvisGreeting: true,
      soundTitle: "Voz JARVIS",
      volume: 0.9,
      createdAt: serverTimestamp(aliceDb),
      updatedAt: serverTimestamp(aliceDb),
    })
  );

  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("alarms").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("messages").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("playlists").get());
});

test("Authenticated owner can write and query chat messages and playlists", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("messages").doc("msg_1").set({
      userId: ALICE_UID,
      sessionId: "default",
      role: "user",
      content: "Olá JARVIS",
      createdAt: serverTimestamp(aliceDb),
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("messages").get()
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("playlists").doc("pl_1").set({
      userId: ALICE_UID,
      name: "Oficina Stark",
      createdAt: serverTimestamp(aliceDb),
    })
  );
});
